# Delivery validation — version 0.8.0

Validated on 17 November 2026, Linux x64, Node.js 24.22.1 and npm 11.9.0. Temporal SDK 1.25.0 and TypeScript 5.9.3 are pinned in the lockfile. Native integration service: CLI 1.10.1, Server 1.32.2, UI 2.56.4.

## Verified checks

- Seven-workspace install/build with TypeScript references, workflow sandbox bundle and viewer production assets.
- Formatting, ESLint and folder-aware architecture checks. The architecture fixture first accepts valid internal imports, then rejects domain-to-adapter dependencies, workflow-to-adapter imports, domain IO and production-to-test imports.
- Core domain/application TypeScript check without Node ambient types; business code remains framework independent.
- 24 unit/domain/service/tool/server tests, 4 React DOM tests and 7 integration tests (35 total).
- Domain validation/immutability and rejected simulation controls; stable operation keys and convergence after partial configuration failure.
- Three real Temporal workflows, durable waits, transient retries, lost response after commit, permanent failure with successful sibling branch, applied room settings, bounded concurrency and personal capacity during standard saturation.
- Local supervisor reload/shutdown and native Temporal history persistence across a complete restart.
- Real viewer API exposes running activity input/output, retries and completed history; stable graph topology and viewport behavior are tested independently.
- Real reset creates a new Run ID after local JSON permission repair. Prepare/provision/readiness execute once, configuration twice; reused-node provenance uses the actual reset marker and the original failed history remains accessible.
- React tests verify live input/output updates, refresh pause/recovery/stop, reused badge/dashed styling and source-run link. Canvas geometry is stubbed in these tests.

## Independent release verification

- Clean `build:production` compiles production workspaces without test-support output.
- Workflow-worker, activity-worker and viewer stages were created independently. Staging regression tests assert separate entry points, selected dependency closures, no test implementation/build output, and refusal to overwrite an existing release or write into source.
- The generated selective `npm ci --omit=dev --workspace ...` commands succeeded in isolated workflow/activity release directories, installing 152 runtime packages in each without using the source checkout's node_modules.
- The isolated installed workflow-worker release connected to a real temporary Temporal service and completed a personal mailbox execution against a separate test-backed activity worker.
- The isolated activity-worker release loaded its runtime dependencies and refused unconfigured enterprise adapters before connecting/polling.
- The standalone viewer release served built assets from a separate directory with no node_modules.

## Scope and remaining validation

Full browser/canvas interaction remains unverified in this environment. The previous Chromium launch was blocked by the environment's Unix-socket restriction; a separate browser session could not reach workspace localhost. No restriction was bypassed. Run `npx playwright install chromium` and `npm run test:browser` on a compatible target host. `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` can select an installed compatible browser. UI Reset clicks were not automated; the actual reset API and resulting execution are verified.

Windows/macOS process supervision and VS Code debugging were not executed. The portable Node commands and native SDK dependencies require target-platform validation.

Enterprise providers, authenticated Temporal connections, secrets, production health/telemetry, autoscaling and deployment access policies remain environment-specific work. The JSON simulator is single-process local tooling. Group parallelism is a modeled dependency assumption to validate with provider owners.

The fixed graph is presentation metadata in `packages/mailbox/src/presentation`; workflow changes require matching descriptor review/tests. Unknown workflow types fall back to an optional history-derived trace. Full histories are refetched during active runs, so larger deployments need caching/incremental history handling and capacity sizing. Child-workflow subgraphs, custom codecs and comprehensive per-attempt timelines remain outside this viewer's current scope.

Source attribution and upstream MIT license remain under `apps/workflow-viewer` and are included in viewer release staging.

## v0.8 mTLS gateway scenario

A real two-client mTLS gateway integration demonstrates workflow-type segregation, namespace/queue/execution ownership checks and certificate-derived identity. Missing/untrusted client certificates fail TLS; a trusted certificate absent from policy is rejected as unauthenticated. Clients reject the wrong server name or untrusted server CA. Shared SDK TLS settings are used by request clients and worker hosts. Certificate material is generated in temporary/ignored directories and is not shipped.

The native CLI development server remains a trusted loopback backend without listener TLS/authorization. Enforcement is in the optional gRPC gateway. A local process can bypass it via the backend/admin ports; production must restrict those ports and integrate PKI/policy operations. This is not evidence of native custom Authorizer deployment.

The complete security CLI flow was additionally exercised as separate processes: local PKI setup, gateway executable and client matrix executable. Both allowed SDK workflow executions completed and all expected denials/certificate verification failures passed. The normal no-TLS local stack and prior recovery/isolation scenarios passed the full regression suite.
