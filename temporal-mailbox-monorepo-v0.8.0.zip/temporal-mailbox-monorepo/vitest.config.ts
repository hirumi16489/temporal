import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';
export default defineConfig({
  resolve: {
    alias: { '@': fileURLToPath(new URL('./apps/workflow-viewer/src', import.meta.url)) },
  },
  test: { environment: 'jsdom', include: ['test/viewer/*.ui.test.tsx'], testTimeout: 20_000 },
});
