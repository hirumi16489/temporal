import { workspaces } from './workspaces.mjs';
console.table(
  workspaces().map((item) => ({
    package: item.name,
    path: item.path,
    owner: item.architecture.owner,
    layer: item.architecture.layer,
    production: item.architecture.production,
  })),
);
