import ts from 'typescript';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve, dirname, sep } from 'node:path';
import { isBuiltin } from 'node:module';
import { workspaces } from './workspaces.mjs';
const packages = workspaces().map((item) => ({ ...item, absolute: resolve(item.path) }));
const byName = new Map(packages.map((item) => [item.name, item]));
const errors = [];
const fail = (path, message) => errors.push(path + ': ' + message);
const rules = {
  domain: ['domain'],
  contracts: ['contracts', 'domain'],
  application: ['application', 'contracts', 'domain'],
  'inbound-adapter': ['inbound-adapter', 'application', 'contracts', 'domain'],
  'outbound-adapter': ['outbound-adapter', 'application', 'contracts', 'domain'],
  execution: ['execution', 'task-queues'],
  'worker-config': ['worker-config', 'execution'],
  descriptors: ['descriptors', 'contracts', 'visualization'],
  workflows: ['workflows', 'contracts', 'execution'],
  'task-queues': ['task-queues'],
  'queue-bootstrap': ['queue-bootstrap', 'task-queues'],
  'worker-runtime': ['worker-runtime', 'connection'],
  visualization: ['visualization'],
  connection: ['connection'],
  'gateway-host': ['gateway-host', 'access-policy', 'connection'],
  'access-policy': ['access-policy'],
  'viewer-host': ['viewer-host', 'descriptors', 'visualization'],
};
const pureLayers = new Set([
  'domain',
  'contracts',
  'application',
  'execution',
  'descriptors',
  'workflows',
  'task-queues',
  'visualization',
  'access-policy',
]);
function walk(path) {
  return readdirSync(path, { withFileTypes: true })
    .filter((entry) => !['node_modules', 'dist', '.git'].includes(entry.name))
    .flatMap((entry) =>
      entry.isDirectory() ? walk(path + '/' + entry.name) : [path + '/' + entry.name],
    );
}
function owner(path) {
  return packages.find((item) => path === item.absolute || path.startsWith(item.absolute + sep));
}
function layerAt(source, file) {
  const path = file.replaceAll('\\', '/').slice(source.absolute.replaceAll('\\', '/').length);
  if (source.architecture.layer === 'capability') {
    if (path.startsWith('/src/domain/')) return 'domain';
    if (path.startsWith('/src/application/contracts/')) return 'contracts';
    if (path.startsWith('/src/application/')) return 'application';
    if (path.startsWith('/src/adapters/inbound/')) return 'inbound-adapter';
    if (path.startsWith('/src/adapters/outbound/')) return 'outbound-adapter';
    if (path.startsWith('/src/execution/worker/')) return 'worker-config';
    if (path.startsWith('/src/execution/')) return 'execution';
    if (path.startsWith('/src/presentation/')) return 'descriptors';
  }
  if (source.architecture.layer === 'platform') {
    if (path.startsWith('/src/task-queues/bootstrap')) return 'queue-bootstrap';
    if (path.startsWith('/src/task-queues/')) return 'task-queues';
    if (path.startsWith('/src/access/')) return 'access-policy';
    if (path.startsWith('/src/connection/')) return 'connection';
    if (path.startsWith('/src/worker-runtime/')) return 'worker-runtime';
    if (path.startsWith('/src/visualization/')) return 'visualization';
  }
  if (source.architecture.layer === 'workflow-host' && path.startsWith('/src/workflows/'))
    return 'workflows';
  return source.architecture.layer;
}
function targetEntry(target, specifier) {
  const subpath = specifier === target.name ? '.' : '.' + specifier.slice(target.name.length);
  const entry = target.exports?.[subpath];
  if (!entry) return undefined;
  const value = typeof entry === 'string' ? entry : entry.default;
  return value
    ? resolve(target.absolute, value.replace(/^\.\/dist\//, './src/').replace(/\.js$/, '.ts'))
    : undefined;
}
function checkImport(source, file, specifier) {
  if (specifier.startsWith('@/') && source.architecture.layer === 'viewer-host') return;
  const name = specifier.startsWith('@')
    ? specifier.split('/').slice(0, 2).join('/')
    : specifier.split('/')[0];
  const relative = specifier.startsWith('.');
  const target = relative ? owner(resolve(dirname(file), specifier)) : byName.get(name);
  const layer = layerAt(source, file);
  if (relative && target && target.name !== source.name) {
    fail(
      file,
      'Use the target workspace public API, not a relative cross-workspace import: ' + specifier,
    );
    return;
  }
  if (
    !relative &&
    !isBuiltin(specifier) &&
    !(name in (source.dependencies ?? {})) &&
    !(name in (source.devDependencies ?? {})) &&
    name !== source.name
  )
    fail(file, 'Undeclared dependency ' + name);
  if (
    isBuiltin(specifier) &&
    (pureLayers.has(layer) ||
      (layer === 'viewer-host' && file.replaceAll('\\', '/').includes('/src/')))
  )
    fail(file, 'Node IO is forbidden in ' + layer);
  if (
    [
      'domain',
      'contracts',
      'application',
      'descriptors',
      'visualization',
      'execution',
      'task-queues',
    ].includes(layer) &&
    /^(?:@temporalio\/|react(?:\/|$)|express$)/.test(specifier)
  )
    fail(file, 'Framework dependency in ' + layer + ': ' + specifier);
  if (
    layer === 'workflows' &&
    specifier.startsWith('@temporalio/') &&
    specifier !== '@temporalio/workflow'
  )
    fail(file, 'Workflow sandbox cannot import ' + specifier);
  if (!target) return;
  if (source.architecture.production && !target.architecture.production)
    fail(file, 'Production code cannot depend on test support');
  const destination = relative ? resolve(dirname(file), specifier) : targetEntry(target, specifier);
  if (!destination) {
    fail(file, 'Use a declared public package entry point: ' + specifier);
    return;
  }
  const targetLayer = layerAt(target, destination);
  if (rules[layer] && !rules[layer].includes(targetLayer))
    fail(file, 'Forbidden layer ' + layer + ' -> ' + targetLayer + ' (' + specifier + ')');
  if (
    source.architecture.production &&
    source.architecture.context !== target.architecture.context &&
    target.architecture.context !== 'platform' &&
    targetLayer !== 'contracts' &&
    !(layer === 'viewer-host' && targetLayer === 'descriptors')
  )
    fail(file, 'Cross-context imports must use application contracts');
}
for (const source of packages) {
  if (!source.architecture?.owner || !source.architecture.context || !source.architecture.layer) {
    fail(source.path, 'Missing ownership/layer metadata');
    continue;
  }
  for (const dependency of Object.keys(source.dependencies ?? {})) {
    const target = byName.get(dependency);
    if (source.architecture.production && target && !target.architecture.production)
      fail(source.path, 'Production manifest depends on test support ' + dependency);
  }
  for (const path of walk(source.path).filter(
    (path) => /\.(?:ts|tsx|mjs|mts)$/.test(path) && !path.endsWith('.d.ts'),
  )) {
    const absolute = resolve(path),
      layer = layerAt(source, absolute),
      pure = pureLayers.has(layer);
    const tree = ts.createSourceFile(
      path,
      readFileSync(path, 'utf8'),
      ts.ScriptTarget.Latest,
      true,
    );
    function visit(node) {
      if (
        pure &&
        ts.isCallExpression(node) &&
        ts.isIdentifier(node.expression) &&
        node.expression.text === 'fetch'
      )
        fail(path, 'External IO must go through an application port');
      if (
        pure &&
        ts.isPropertyAccessExpression(node) &&
        ts.isIdentifier(node.expression) &&
        ['process', 'global', 'Buffer'].includes(node.expression.text)
      )
        fail(path, 'Node global in framework-free/sandbox code');
      if (
        (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) &&
        node.moduleSpecifier &&
        ts.isStringLiteral(node.moduleSpecifier)
      )
        checkImport(source, absolute, node.moduleSpecifier.text);
      if (
        ts.isCallExpression(node) &&
        (node.expression.kind === ts.SyntaxKind.ImportKeyword ||
          (ts.isIdentifier(node.expression) && node.expression.text === 'require'))
      ) {
        if (node.arguments[0] && ts.isStringLiteral(node.arguments[0]))
          checkImport(source, absolute, node.arguments[0].text);
        else if (source.architecture.production)
          fail(path, 'Computed module loading bypasses workspace boundaries');
      }
      ts.forEachChild(node, visit);
    }
    visit(tree);
  }
}
if (errors.length) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else
  console.log(
    'Architecture checks passed for ' + packages.length + ' workspaces and their internal layers.',
  );
