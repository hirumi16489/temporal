import { readdirSync, existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
export function workspaces() {
  function scan(parent) {
    if (!existsSync(parent)) return [];
    if (existsSync(join(parent, 'package.json')))
      return [{ path: parent, ...JSON.parse(readFileSync(join(parent, 'package.json'), 'utf8')) }];
    return readdirSync(parent, { withFileTypes: true })
      .filter((entry) => entry.isDirectory())
      .flatMap((entry) => {
        const path = join(parent, entry.name);
        return existsSync(join(path, 'package.json'))
          ? [{ path, ...JSON.parse(readFileSync(join(path, 'package.json'), 'utf8')) }]
          : scan(path);
      });
  }
  return ['apps', 'packages', 'test/support'].flatMap(scan);
}
