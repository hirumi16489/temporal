import { workspaces } from './workspaces.mjs';
import { spawnSync } from 'node:child_process';
import { rmSync } from 'node:fs';
import { join } from 'node:path';
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
function run(command, args) {
  const result = spawnSync(command, args, {
    stdio: 'inherit',
    shell: process.platform === 'win32' && command.endsWith('.cmd'),
  });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}
const action = process.argv[2];
if (action === 'clean') {
  for (const workspace of workspaces()) {
    rmSync(join(workspace.path, 'dist'), { recursive: true, force: true });
    rmSync(join(workspace.path, 'tsconfig.tsbuildinfo'), { force: true });
  }
} else if (['build', 'build-production', 'typecheck', 'pools', 'pools-list'].includes(action)) {
  run(npm, ['exec', '--', 'tsc', '-b', 'packages/temporal-platform']);
  run(process.execPath, ['--import', 'tsx', 'scripts/prepare-pools.ts']);
  if (action === 'build' || action === 'build-production' || action === 'typecheck') {
    if (action === 'build-production')
      run(npm, [
        'exec',
        '--',
        'tsc',
        '-b',
        ...workspaces()
          .filter(
            (workspace) =>
              workspace.architecture.production && workspace.architecture.layer !== 'viewer-host',
          )
          .map((workspace) => workspace.path),
      ]);
    else run(npm, ['exec', '--', 'tsc', '-b']);
    if (action !== 'build-production') {
      run(npm, ['exec', '--', 'tsc', '-p', 'tsconfig.tools.json']);
      run(npm, ['exec', '--', 'tsc', '-p', 'test/tsconfig.ui.json']);
    }
    run(npm, ['exec', '--', 'tsc', '-p', 'packages/mailbox/tsconfig.core.json']);
    run(npm, ['exec', '--workspace', '@platform/workflow-viewer', '--', 'tsc', '--noEmit']);
    if (action === 'build' || action === 'build-production') {
      run(process.execPath, ['scripts/bundle-workflows.mjs']);
      run(npm, ['exec', '--workspace', '@platform/workflow-viewer', '--', 'vite', 'build']);
    }
  }
} else throw new Error('Unknown task: ' + action);
