import { spawn } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { Connection } from '@temporalio/client';

export function localServerOptions(env = process.env) {
  if (
    env.TEMPORAL_TLS_ENABLED === 'true' ||
    env.TEMPORAL_TLS_CA_FILE ||
    env.TEMPORAL_TLS_CLIENT_CERT_FILE ||
    env.TEMPORAL_TLS_CLIENT_KEY_FILE
  )
    throw new Error(
      'Managed native development server has no TLS listener; use dev:external for native TLS, or the separate access gateway demo.',
    );
  const address = env.TEMPORAL_ADDRESS ?? 'localhost:7233';
  const match = /^(localhost|127\.0\.0\.1):(\d+)$/.exec(address);
  if (!match)
    throw new Error(
      'Managed Temporal requires localhost:<port> or 127.0.0.1:<port>. Use npm run dev:external for an existing server.',
    );
  const port = Number(match[2]);
  const uiPort = Number(env.TEMPORAL_UI_PORT ?? 8233);
  for (const value of [port, uiPort])
    if (!Number.isInteger(value) || value < 1 || value > 65535)
      throw new Error('Invalid Temporal port');
  if (port === uiPort) throw new Error('Temporal service and UI ports must differ');
  const database = resolve(env.TEMPORAL_DB_FILE ?? '.data/temporal.db');
  return {
    executable: env.TEMPORAL_CLI_PATH || 'temporal',
    address,
    database,
    args: [
      'server',
      'start-dev',
      '--ip',
      '127.0.0.1',
      '--port',
      String(port),
      '--ui-ip',
      '127.0.0.1',
      '--ui-port',
      String(uiPort),
      '--db-filename',
      database,
      '--namespace',
      env.TEMPORAL_NAMESPACE ?? 'default',
    ],
  };
}

export function spawnTemporal(env = process.env) {
  const options = localServerOptions(env);
  mkdirSync(dirname(options.database), { recursive: true });
  const child = spawn(options.executable, options.args, { env, stdio: ['ignore', 'pipe', 'pipe'] });
  // Attach immediately so a missing executable never becomes an uncaught event.
  child.on('error', (error) =>
    console.error(
      `Cannot start Temporal: ${error.message}. Install the official Temporal CLI on PATH, or set TEMPORAL_CLI_PATH to its executable. See README.md.`,
    ),
  );
  return child;
}

export async function waitForTemporal(child, address, isClosing = () => false) {
  let failure;
  const failed = (error) => {
    failure = error;
  };
  child.on('error', failed);
  try {
    const deadline = Date.now() + 30_000;
    while (!isClosing()) {
      if (failure) throw failure;
      if (child.exitCode !== null || child.signalCode !== null)
        throw new Error(
          'Temporal exited before becoming ready. Check its logs for occupied ports or database errors.',
        );
      try {
        const connection = await Connection.connect({ address, connectTimeout: '1 second' });
        await connection.close();
        // Do not accept another service on an occupied port while our child fails.
        await new Promise((done) => setTimeout(done, 200));
        if (child.exitCode !== null || child.signalCode !== null)
          throw new Error('Managed Temporal failed to start');
        return;
      } catch (error) {
        if (Date.now() >= deadline)
          throw new Error(`Temporal did not become ready at ${address}: ${error.message}`, {
            cause: error,
          });
        await new Promise((done) => setTimeout(done, 100));
      }
    }
  } finally {
    child.off('error', failed);
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const { existsSync } = await import('node:fs');
  if (existsSync('.env')) process.loadEnvFile('.env');
  const child = spawnTemporal();
  child.stdout.pipe(process.stdout);
  child.stderr.pipe(process.stderr);
  child.once('error', () => {
    process.exitCode = 1;
  });
  child.once('exit', (code, signal) => {
    process.exitCode = signal ? 0 : (code ?? 1);
  });
  for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => child.kill('SIGTERM'));
}
