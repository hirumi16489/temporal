import { bundleWorkflowCode } from '@temporalio/worker';
import { writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const bundle = await bundleWorkflowCode({
  workflowsPath: resolve('apps/mailbox-workflow-worker/dist/workflows/index.js'),
});
await writeFile('apps/mailbox-workflow-worker/dist/workflow-bundle.js', bundle.code);
console.log('Built self-contained Temporal workflow sandbox bundle.');
