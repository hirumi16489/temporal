import { existsSync, mkdirSync, cpSync, copyFileSync, writeFileSync, readFileSync } from 'node:fs';
import { resolve, join, relative, sep } from 'node:path';
import { workspaces } from './workspaces.mjs';
const [role, suppliedDestination] = process.argv.slice(2);
const roles = {
  'access-gateway': {
    workspace: '@hosts/temporal-access-gateway',
    entry: 'apps/temporal-access-gateway/dist/main.js',
  },
  'workflow-worker': {
    workspace: '@hosts/mailbox-workflow-worker',
    entry: 'apps/mailbox-workflow-worker/dist/main.js',
  },
  'activity-worker': {
    workspace: '@hosts/mailbox-activity-worker',
    entry: 'apps/mailbox-activity-worker/dist/main.js',
  },
  viewer: { workspace: '@platform/workflow-viewer', entry: 'apps/workflow-viewer/server.mjs' },
};
if (!Object.hasOwn(roles, role) || !suppliedDestination)
  throw new Error(
    'Usage: npm run release:stage -- workflow-worker|activity-worker|viewer|access-gateway <new-directory>',
  );
const root = resolve('.'),
  destination = resolve(suppliedDestination);
if (destination === root || destination.startsWith(root + sep))
  throw new Error('Stage outside the source tree, into a new directory');
if (existsSync(destination))
  throw new Error('Destination must not exist; staging never overwrites an existing release');
const catalog = workspaces(),
  byName = new Map(catalog.map((item) => [item.name, item]));
const selected = roles[role],
  closure = new Set();
function add(name) {
  if (closure.has(name)) return;
  const item = byName.get(name);
  if (!item || !item.architecture.production)
    throw new Error('Release cannot include test support: ' + name);
  closure.add(name);
  for (const dependency of Object.keys(item.dependencies ?? {}))
    if (byName.has(dependency)) add(dependency);
}
add(selected.workspace);
for (const name of closure)
  if (!existsSync(join(byName.get(name).path, 'dist')))
    throw new Error('Run npm run build:production before staging: ' + name);
mkdirSync(destination, { recursive: true });
if (role === 'viewer') {
  const path = byName.get(selected.workspace).path;
  for (const file of ['server.mjs', 'server-lib.mjs', 'UPSTREAM.md', 'UPSTREAM-LICENSE'])
    copyFileSync(join(path, file), join(destination, file));
  cpSync(join(path, 'dist'), join(destination, 'dist'), { recursive: true });
} else {
  for (const file of ['package.json', 'package-lock.json'])
    copyFileSync(file, join(destination, file));
  const runtimeManifest = JSON.parse(readFileSync('package.json', 'utf8'));
  runtimeManifest.scripts = { start: 'node ' + selected.entry };
  writeFileSync(join(destination, 'package.json'), JSON.stringify(runtimeManifest, null, 2) + '\n');
  // Lockfile-consistent workspace manifests only. Nonselected workspaces have no implementation in the release.
  for (const item of catalog) {
    mkdirSync(join(destination, item.path), { recursive: true });
    copyFileSync(join(item.path, 'package.json'), join(destination, item.path, 'package.json'));
  }
  for (const name of closure) {
    const path = byName.get(name).path;
    cpSync(join(path, 'dist'), join(destination, path, 'dist'), { recursive: true });
  }
  cpSync('config', join(destination, 'config'), { recursive: true });
}
const entry = role === 'viewer' ? 'server.mjs' : selected.entry;
const install =
  role === 'viewer'
    ? null
    : 'npm ci --omit=dev ' + [...closure].map((name) => '--workspace ' + name).join(' ');
const metadata = {
  role,
  workspaces: role === 'viewer' ? [selected.workspace] : [...closure],
  entry,
  install,
  exampleStart: 'node ' + entry + (role === 'activity-worker' ? ' personal' : ''),
  ...(role === 'access-gateway'
    ? {
        requiredConfiguration: [
          'GATEWAY_POLICY_FILE',
          'GATEWAY_CLIENT_CA_FILE',
          'GATEWAY_CERT_FILE',
          'GATEWAY_KEY_FILE',
          'TEMPORAL_ADDRESS',
        ],
      }
    : {}),
};
writeFileSync(join(destination, 'release.json'), JSON.stringify(metadata, null, 2) + '\n');
writeFileSync(
  join(destination, 'RELEASE.md'),
  '# ' +
    role +
    ' release\n\n' +
    (install
      ? 'Install runtime dependencies on the target host:\n\n```sh\n' + install + '\n```\n\n'
      : 'No npm installation is required for the bundled viewer.\n\n') +
    'Start from this directory:\n\n```sh\n' +
    metadata.exampleStart +
    (role === 'access-gateway'
      ? '\n```\n\nMount approved PKI/policy files and set GATEWAY_POLICY_FILE, GATEWAY_CLIENT_CA_FILE, GATEWAY_CERT_FILE and GATEWAY_KEY_FILE. Configure the trusted backend with TEMPORAL_ADDRESS and optional native TLS variables. No generated certificates are included. See the source repository docs/MTLS_DEMO.md.\n\n'
      : '\n```\n\n') +
    'Workflow and activity workers require a managed Temporal service. Activity startup refuses unconfigured enterprise adapters. Supply approved credentials/endpoints and a process supervisor in your deployment environment. Do not use local simulator tooling in this release.\n',
);
console.log('Staged ' + role + ' at ' + relative(root, destination));
console.log(JSON.stringify(metadata, null, 2));
