import { spawn } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { createInterface } from 'node:readline';
import { watch } from 'chokidar';
import { workspaces } from './workspaces.mjs';
import { spawnTemporal, waitForTemporal } from './temporal.mjs';
if (existsSync('.env')) process.loadEnvFile('.env');
const watching = !process.argv.includes('--no-watch');
let temporal,
  children = [],
  closing = false,
  restarting = false,
  pending = false,
  timer;
function start(name, args) {
  const child = spawn(process.execPath, args, {
    stdio: ['ignore', 'pipe', 'pipe'],
    env: process.env,
  });
  for (const stream of [child.stdout, child.stderr])
    createInterface({ input: stream }).on('line', (line) => console.log(`[${name}] ${line}`));
  child.on('error', (error) => console.error(`[${name}]`, error));
  child.once('exit', (code) => {
    if (!restarting && !closing) {
      console.error(`${name} exited (${code}); stopping the stack.`);
      process.exitCode = code || 1;
      void stopAll()
        .then(stopTemporal)
        .then(() => process.exit());
    }
  });
  children.push(child);
  return child;
}
async function command(args) {
  const child = spawn(process.execPath, args, { stdio: 'inherit' });
  await new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('exit', (code) =>
      code === 0 ? resolve() : reject(new Error('Command failed: ' + args.join(' '))),
    );
  });
}
async function stopAll() {
  const stopped = children.map(
    (child) =>
      new Promise((resolve) => {
        if (child.exitCode !== null || child.signalCode !== null) return resolve();
        child.once('exit', resolve);
        child.kill('SIGTERM');
        const timeout = setTimeout(() => child.kill('SIGKILL'), 12_000);
        timeout.unref();
        child.once('exit', () => clearTimeout(timeout));
      }),
  );
  children = [];
  await Promise.all(stopped);
}
function startAll() {
  start('viewer', ['apps/workflow-viewer/server.mjs']);
  start('backend', ['test/support/dist/simulator/main.js']);
  start('workflows', ['apps/mailbox-workflow-worker/dist/main.js']);
  const capacities = JSON.parse(
    readFileSync(process.env.CAPACITY_FILE ?? 'config/mailbox/capacity.json', 'utf8'),
  );
  for (const [profile, capacity] of Object.entries(capacities)) {
    if (!Number.isInteger(capacity.replicas) || capacity.replicas < 1)
      throw new Error('Invalid replicas for ' + profile);
    for (let replica = 0; replica < capacity.replicas; replica++)
      start(`${profile}-${replica + 1}`, ['test/support/dist/runtime/activity-worker.js', profile]);
  }
}
async function rebuild() {
  if (restarting) {
    pending = true;
    return;
  }
  restarting = true;
  try {
    await stopAll();
    await command(['scripts/tasks.mjs', 'build']);
    if (!closing) startAll();
  } catch (error) {
    console.error(error.message, watching ? 'Fix the error and save to retry.' : '');
    if (!watching) {
      closing = true;
      process.exitCode = 1;
      await stopAll();
      await stopTemporal();
    }
  } finally {
    restarting = false;
    if (pending && !closing) {
      pending = false;
      void rebuild();
    }
  }
}
let watcher;
if (watching) {
  const paths = [
    process.env.CAPACITY_FILE ?? 'config/mailbox/capacity.json',
    'scripts/prepare-pools.ts',
    'apps/workflow-viewer/server.mjs',
    'apps/workflow-viewer/server-lib.mjs',
    'apps/workflow-viewer/index.html',
    'apps/workflow-viewer/vite.config.ts',
    'apps/workflow-viewer/tailwind.config.js',
  ];
  for (const workspace of workspaces()) paths.push(`${workspace.path}/src`);
  watcher = watch(paths, {
    ignoreInitial: true,
    ignored: (path) => path.endsWith('/generated.ts'),
    awaitWriteFinish: { stabilityThreshold: 200, pollInterval: 50 },
  });
  watcher.on('all', () => {
    clearTimeout(timer);
    timer = setTimeout(() => void rebuild(), 300);
  });
}
for (const signal of ['SIGINT', 'SIGTERM'])
  process.once(signal, async () => {
    closing = true;
    clearTimeout(timer);
    await watcher?.close();
    await stopAll();
    await stopTemporal();
    process.exit(0);
  });
async function stopTemporal() {
  if (!temporal || temporal.exitCode !== null || temporal.signalCode !== null) return;
  const child = temporal;
  await new Promise((done) => {
    child.once('exit', done);
    child.kill('SIGTERM');
    const timeout = setTimeout(() => child.kill('SIGKILL'), 12_000);
    timeout.unref();
    child.once('exit', () => clearTimeout(timeout));
  });
}
try {
  if (!process.argv.includes('--external-temporal')) {
    temporal = spawnTemporal();
    for (const stream of [temporal.stdout, temporal.stderr])
      createInterface({ input: stream }).on('line', (line) => console.log(`[temporal] ${line}`));
    temporal.once('exit', () => {
      if (!closing) {
        closing = true;
        process.exitCode = 1;
        clearTimeout(timer);
        console.error('Temporal exited; stopping the stack.');
        void watcher?.close();
        void stopAll();
      }
    });
    await waitForTemporal(
      temporal,
      process.env.TEMPORAL_ADDRESS ?? 'localhost:7233',
      () => closing,
    );
    console.log('Temporal server ready');
  }
  if (!closing) await rebuild();
} catch (error) {
  closing = true;
  process.exitCode = 1;
  console.error(error.message);
  await watcher?.close();
  await stopAll();
  await stopTemporal();
}
