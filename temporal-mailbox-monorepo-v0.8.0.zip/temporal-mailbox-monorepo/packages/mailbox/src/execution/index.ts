export * from './definitions';
export { resolvedPools } from './generated';
export const WorkflowQueue = 'mailbox.provisioning.workflows.v2';
