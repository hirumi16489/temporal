import { createPoolBuilders } from '@automation/temporal-platform/task-queues';
export const ActivityPools = { MAILBOX: 'mailbox-provisioning' } as const;
export const IsolationKeys = { PERSONAL_MAILBOX: 'personal-mailbox' } as const;
export const { activityPool, dedicatedActivityPool } = createPoolBuilders(
  ActivityPools,
  IsolationKeys,
);
export const PoolProfiles = { PERSONAL: 'personal', STANDARD: 'standard' } as const;
export const poolDefinitions = {
  [PoolProfiles.STANDARD]: activityPool(ActivityPools.MAILBOX),
  [PoolProfiles.PERSONAL]: dedicatedActivityPool(
    ActivityPools.MAILBOX,
    IsolationKeys.PERSONAL_MAILBOX,
  ),
} as const;
export type PoolProfile = keyof typeof poolDefinitions;
