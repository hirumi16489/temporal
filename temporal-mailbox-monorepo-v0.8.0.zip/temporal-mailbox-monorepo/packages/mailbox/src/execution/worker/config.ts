import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { resolvedPools, type PoolProfile } from '../index';
export interface Capacity {
  concurrencyPerWorker: number;
  replicas: number;
  activityRate?: number;
}
export function workerConfig(
  profile: string,
  capacities: Record<string, Capacity>,
  env: NodeJS.ProcessEnv = process.env,
) {
  if (!Object.hasOwn(resolvedPools, profile)) throw new Error('Unknown pool profile: ' + profile);
  const capacity = capacities[profile];
  if (!capacity) throw new Error('Missing capacity for ' + profile);
  const concurrency = Number(env.ACTIVITY_CONCURRENCY ?? capacity.concurrencyPerWorker);
  const rate = env.ACTIVITY_RATE ? Number(env.ACTIVITY_RATE) : capacity.activityRate;
  if (!Number.isInteger(concurrency) || concurrency < 1)
    throw new Error('Activity concurrency must be a positive integer');
  if (!Number.isInteger(capacity.replicas) || capacity.replicas < 1)
    throw new Error('replicas must be a positive integer');
  if (rate !== undefined && (!Number.isFinite(rate) || rate <= 0))
    throw new Error('Activity rate must be positive');
  return {
    profile,
    taskQueue: resolvedPools[profile as PoolProfile],
    concurrency,
    replicas: capacity.replicas,
    rate,
  };
}
export function loadWorkerConfig(profile: string) {
  return workerConfig(
    profile,
    JSON.parse(
      readFileSync(resolve(process.env.CAPACITY_FILE ?? 'config/mailbox/capacity.json'), 'utf8'),
    ),
  );
}
