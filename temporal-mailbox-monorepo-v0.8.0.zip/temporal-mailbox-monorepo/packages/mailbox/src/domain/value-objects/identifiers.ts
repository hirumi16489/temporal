import { InvalidMailboxRequest } from '../errors/provisioning.error';
declare const identityBrand: unique symbol;
declare const requestBrand: unique symbol;
export type MailboxIdentity = string & { readonly [identityBrand]: true };
export type ProvisioningRequestId = string & { readonly [requestBrand]: true };
export function requiredText(value: unknown, field: string): string {
  if (
    typeof value !== 'string' ||
    !value.trim() ||
    value.length > 256 ||
    [...value].some((character) => character.charCodeAt(0) < 32)
  )
    throw new InvalidMailboxRequest(field + ' must be nonempty text (max 256 characters)');
  return value.trim();
}
export const mailboxIdentity = (value: unknown): MailboxIdentity =>
  requiredText(value, 'identity') as MailboxIdentity;
export const provisioningRequestId = (value: unknown): ProvisioningRequestId =>
  requiredText(value, 'requestId') as ProvisioningRequestId;
