export type ProvisioningErrorCode =
  | 'InvalidMailboxRequest'
  | 'IdentityConflict'
  | 'PermissionDenied'
  | 'DependencyUnavailable'
  | 'ExternalAdapterNotConfigured';
export class ProvisioningError extends Error {
  constructor(
    message: string,
    readonly code: ProvisioningErrorCode,
    readonly retryable: boolean,
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.name = code;
  }
}
export class InvalidMailboxRequest extends ProvisioningError {
  constructor(message: string) {
    super(message, 'InvalidMailboxRequest', false);
  }
}
export class IdentityConflict extends ProvisioningError {
  constructor(message: string) {
    super(message, 'IdentityConflict', false);
  }
}
export class PermissionDenied extends ProvisioningError {
  constructor(message: string) {
    super(message, 'PermissionDenied', false);
  }
}
export class DependencyUnavailable extends ProvisioningError {
  constructor(message: string, options?: ErrorOptions) {
    super(message, 'DependencyUnavailable', true, options);
  }
}
export class ExternalAdapterNotConfigured extends ProvisioningError {
  constructor(message: string) {
    super(message, 'ExternalAdapterNotConfigured', false);
  }
}
