import { InvalidMailboxRequest } from '../errors/provisioning.error';
import { mailboxIdentity, provisioningRequestId, requiredText } from '../value-objects/identifiers';
import type { MailboxProvisioningPlan } from '../models/mailbox-provisioning-plan';
function record(
  value: unknown,
  field: string,
  allowed: readonly string[],
): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new InvalidMailboxRequest(field + ' must be an object');
  const result = value as Record<string, unknown>;
  for (const key of Object.keys(result))
    if (!allowed.includes(key))
      throw new InvalidMailboxRequest('Unknown ' + field + ' field: ' + key);
  return result;
}
function textList(value: unknown, field: string): readonly string[] {
  if (!Array.isArray(value)) throw new InvalidMailboxRequest(field + ' must be a list');
  return Object.freeze(value.map((item: unknown) => requiredText(item, field)));
}
export function createProvisioningPlan(value: unknown): MailboxProvisioningPlan {
  const request = record(value, 'mailbox request', [
    'requestId',
    'identity',
    'kind',
    'displayName',
    'configuration',
    'room',
    'group',
  ]);
  if (request.kind !== 'PERSONAL' && request.kind !== 'ROOM' && request.kind !== 'GROUP')
    throw new InvalidMailboxRequest('Unknown mailbox kind');
  const config = record(request.configuration, 'configuration', ['aliases', 'retention', 'owner']);
  const common = {
    requestId: provisioningRequestId(request.requestId),
    identity: mailboxIdentity(request.identity),
    displayName: requiredText(request.displayName, 'displayName'),
    configuration: Object.freeze({
      aliases: textList(config.aliases, 'alias'),
      retention: requiredText(config.retention, 'retention'),
      owner: requiredText(config.owner, 'owner'),
    }),
  };
  if (request.kind !== 'ROOM' && request.room !== undefined)
    throw new InvalidMailboxRequest('Only room mailboxes accept room settings');
  if (request.kind !== 'GROUP' && request.group !== undefined)
    throw new InvalidMailboxRequest('Only group mailboxes accept group settings');
  if (request.kind === 'ROOM') {
    const room = record(request.room, 'room', ['location', 'capacity']);
    if (
      typeof room.capacity !== 'number' ||
      !Number.isSafeInteger(room.capacity) ||
      room.capacity < 1
    )
      throw new InvalidMailboxRequest('Room requires a positive integer capacity');
    return Object.freeze({
      ...common,
      kind: 'ROOM',
      room: Object.freeze({
        location: requiredText(room.location, 'room.location'),
        capacity: room.capacity,
      }),
    });
  }
  if (request.kind === 'GROUP') {
    const group = record(request.group, 'group', ['identity', 'members']);
    return Object.freeze({
      ...common,
      kind: 'GROUP',
      group: Object.freeze({
        identity: requiredText(group.identity, 'group.identity'),
        members: textList(group.members, 'member'),
      }),
    });
  }
  return Object.freeze({ ...common, kind: 'PERSONAL' });
}
