import type { MailboxIdentity, ProvisioningRequestId } from '../value-objects/identifiers';
interface MailboxProvisioningPlanBase {
  readonly requestId: ProvisioningRequestId;
  readonly identity: MailboxIdentity;
  readonly displayName: string;
  readonly configuration: {
    readonly aliases: readonly string[];
    readonly retention: string;
    readonly owner: string;
  };
}
export type MailboxProvisioningPlan = MailboxProvisioningPlanBase &
  (
    | { readonly kind: 'PERSONAL'; readonly room?: never; readonly group?: never }
    | {
        readonly kind: 'ROOM';
        readonly room: { readonly location: string; readonly capacity: number };
        readonly group?: never;
      }
    | {
        readonly kind: 'GROUP';
        readonly group: { readonly identity: string; readonly members: readonly string[] };
        readonly room?: never;
      }
  );
