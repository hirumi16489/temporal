import { WorkflowTypes, MailboxActivityNames } from '../application/contracts/index';
import type { WorkflowDiagram } from '@automation/temporal-platform/visualization';
export type { WorkflowDiagram } from '@automation/temporal-platform/visualization';
// Presentation metadata, not an interpreter: workflow code still owns orchestration.
// Keep these versioned views aligned with the corresponding workflow implementations.
function mailboxDiagram(title: string, group = false, room = false): WorkflowDiagram {
  return {
    version: 2,
    title,
    steps: [
      { id: 'start', label: 'Start', kind: 'start', activityTypes: [], position: { x: 200, y: 0 } },
      {
        id: 'prepare',
        label: 'Prepare provisioning',
        kind: 'activity',
        activityTypes: [MailboxActivityNames.PREPARE],
        position: { x: 200, y: 120 },
      },
      {
        id: 'provision',
        label: 'Provision mailbox',
        kind: 'activity',
        activityTypes: [MailboxActivityNames.PROVISION],
        position: { x: 200, y: 240 },
      },
      {
        id: 'availability',
        label: 'Wait for mailbox availability',
        kind: 'wait',
        completionField: 'ready',
        activityTypes: [MailboxActivityNames.READINESS],
        position: { x: 200, y: 360 },
      },
      {
        id: 'configure',
        label: room ? 'Configure mailbox and room' : 'Configure mailbox',
        kind: 'activity',
        activityTypes: [MailboxActivityNames.CONFIGURE],
        position: { x: group ? 0 : 200, y: 480 },
      },
      ...(group
        ? [
            {
              id: 'group',
              label: 'Provision related group',
              kind: 'activity' as const,
              activityTypes: [MailboxActivityNames.GROUP],
              position: { x: 400, y: 480 },
            },
          ]
        : []),
      {
        id: 'finish',
        label: 'Finish',
        kind: 'end',
        activityTypes: [],
        position: { x: 200, y: 600 },
      },
    ],
    edges: [
      ['start', 'prepare'],
      ['prepare', 'provision'],
      ['provision', 'availability'],
      ['availability', 'configure'],
      ['configure', 'finish'],
      ...(group
        ? ([
            ['availability', 'group'],
            ['group', 'finish'],
          ] as const)
        : []),
    ],
  };
}
export const WorkflowDiagrams: Readonly<
  Record<(typeof WorkflowTypes)[keyof typeof WorkflowTypes], WorkflowDiagram>
> = {
  [WorkflowTypes.PERSONAL]: mailboxDiagram('Personal mailbox'),
  [WorkflowTypes.ROOM]: mailboxDiagram('Room mailbox', false, true),
  [WorkflowTypes.GROUP]: mailboxDiagram('Group mailbox', true),
};
