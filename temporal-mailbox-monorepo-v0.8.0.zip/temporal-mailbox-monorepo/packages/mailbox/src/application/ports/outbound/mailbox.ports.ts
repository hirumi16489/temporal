import type {
  MailboxProvisioningPlan,
  MailboxIdentity,
  ProvisioningRequestId,
} from '../../../domain/index';
export interface OperationContext {
  readonly requestId: string;
  readonly idempotencyKey: string;
  readonly attempt: number;
  readonly signal?: AbortSignal;
}
// Each mutation must converge on desired state when retried with the same idempotency key.
export interface MailboxGateway {
  ensureMailbox(
    plan: MailboxProvisioningPlan,
    context: OperationContext,
  ): Promise<'CREATED' | 'EXISTING'>;
  isReady(
    identity: MailboxIdentity,
    requestId: ProvisioningRequestId,
    context: OperationContext,
  ): Promise<boolean>;
  configureSettings(plan: MailboxProvisioningPlan, context: OperationContext): Promise<void>;
}
export interface DirectoryGateway {
  configureOwner(plan: MailboxProvisioningPlan, context: OperationContext): Promise<void>;
}
export interface DistributionGroupGateway {
  ensureDistributionGroup(plan: MailboxProvisioningPlan, context: OperationContext): Promise<void>;
}
export interface MailboxPorts {
  readonly mailboxes: MailboxGateway;
  readonly directory: DirectoryGateway;
  readonly groups: DistributionGroupGateway;
}
export interface ExecutionContext {
  readonly attempt: number;
  readonly signal?: AbortSignal;
}
export const operationContext = (
  requestId: string,
  operation: string,
  execution: ExecutionContext,
): OperationContext => ({ ...execution, requestId, idempotencyKey: requestId + ':' + operation });
