export interface MailboxProvisionResult {
  readonly identity: string;
  readonly status: 'CREATED' | 'EXISTING';
}
export interface MailboxReadinessResult {
  readonly identity: string;
  readonly ready: boolean;
}
export interface MailboxConfigurationResult {
  readonly identity: string;
  readonly status: 'CONFIGURED';
}
export interface MailboxDistributionGroupResult {
  readonly identity: string;
  readonly groupIdentity: string;
  readonly status: 'CONFIGURED';
}
export interface ProvisioningResult {
  readonly identity: string;
  readonly status: 'READY';
  readonly groupIdentity?: string;
}
export interface ProvisioningStatus {
  phase: string;
  mailboxConfigured: boolean;
  groupProvisioned: boolean;
}
