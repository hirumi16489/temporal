export type MailboxKind = 'PERSONAL' | 'ROOM' | 'GROUP';
export interface MailboxConfiguration {
  readonly aliases: readonly string[];
  readonly retention: string;
  readonly owner: string;
}
interface ProvisioningRequestBase {
  readonly requestId: string;
  readonly identity: string;
  readonly displayName: string;
  readonly configuration: MailboxConfiguration;
}
export interface PersonalMailboxRequest extends ProvisioningRequestBase {
  readonly kind: 'PERSONAL';
  readonly room?: never;
  readonly group?: never;
}
export interface RoomMailboxRequest extends ProvisioningRequestBase {
  readonly kind: 'ROOM';
  readonly room: { readonly location: string; readonly capacity: number };
  readonly group?: never;
}
export interface GroupMailboxRequest extends ProvisioningRequestBase {
  readonly kind: 'GROUP';
  readonly group: { readonly identity: string; readonly members: readonly string[] };
  readonly room?: never;
}
export type ProvisioningRequest = PersonalMailboxRequest | RoomMailboxRequest | GroupMailboxRequest;
export type PreparedMailboxProvisioning = ProvisioningRequest;
export interface MailboxReadinessRequest {
  readonly requestId: string;
  readonly identity: string;
}
