import type {
  ProvisioningRequest,
  PreparedMailboxProvisioning,
  MailboxReadinessRequest,
} from '../requests/mailbox-provisioning.request';
import type {
  MailboxProvisionResult,
  MailboxReadinessResult,
  MailboxConfigurationResult,
  MailboxDistributionGroupResult,
} from '../results/mailbox-provisioning.result';
export interface MailboxActivities {
  prepareMailboxProvisioning(request: ProvisioningRequest): Promise<PreparedMailboxProvisioning>;
  provisionMailbox(command: PreparedMailboxProvisioning): Promise<MailboxProvisionResult>;
  checkMailboxReadiness(request: MailboxReadinessRequest): Promise<MailboxReadinessResult>;
  configureMailbox(command: PreparedMailboxProvisioning): Promise<MailboxConfigurationResult>;
  provisionMailboxDistributionGroup(
    command: PreparedMailboxProvisioning,
  ): Promise<MailboxDistributionGroupResult>;
}
export const MailboxActivityNames = {
  PREPARE: 'prepareMailboxProvisioning',
  PROVISION: 'provisionMailbox',
  READINESS: 'checkMailboxReadiness',
  CONFIGURE: 'configureMailbox',
  GROUP: 'provisionMailboxDistributionGroup',
} as const satisfies Record<string, keyof MailboxActivities>;
