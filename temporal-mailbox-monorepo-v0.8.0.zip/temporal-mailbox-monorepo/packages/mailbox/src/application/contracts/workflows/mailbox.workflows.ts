export const WorkflowTypes = {
  PERSONAL: 'provisionPersonalMailboxWorkflow',
  ROOM: 'provisionRoomMailboxWorkflow',
  GROUP: 'provisionGroupMailboxWorkflow',
} as const;
export const MailboxQueries = { STATUS: 'provisioningStatus' } as const;
export const MailboxContractVersion = 2;
