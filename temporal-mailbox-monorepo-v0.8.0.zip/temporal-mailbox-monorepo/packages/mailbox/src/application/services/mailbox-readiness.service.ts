import type { MailboxReadinessRequest, MailboxReadinessResult } from '../contracts/index';
import { mailboxIdentity, provisioningRequestId } from '../../domain/index';
import {
  operationContext,
  type ExecutionContext,
  type MailboxGateway,
} from '../ports/outbound/mailbox.ports';
export class MailboxReadinessService {
  constructor(private readonly mailboxes: MailboxGateway) {}
  async check(
    request: MailboxReadinessRequest,
    execution: ExecutionContext,
  ): Promise<MailboxReadinessResult> {
    const identity = mailboxIdentity(request.identity),
      requestId = provisioningRequestId(request.requestId);
    return {
      identity,
      ready: await this.mailboxes.isReady(
        identity,
        requestId,
        operationContext(requestId, 'check-readiness', execution),
      ),
    };
  }
}
