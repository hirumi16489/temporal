import type { PreparedMailboxProvisioning, MailboxConfigurationResult } from '../contracts/index';
import { createProvisioningPlan } from '../../domain/index';
import {
  operationContext,
  type ExecutionContext,
  type MailboxGateway,
  type DirectoryGateway,
} from '../ports/outbound/mailbox.ports';
export class MailboxConfigurationService {
  constructor(
    private readonly mailboxes: MailboxGateway,
    private readonly directory: DirectoryGateway,
  ) {}
  async configure(
    command: PreparedMailboxProvisioning,
    execution: ExecutionContext,
  ): Promise<MailboxConfigurationResult> {
    const plan = createProvisioningPlan(command);
    await this.mailboxes.configureSettings(
      plan,
      operationContext(plan.requestId, 'configure-mailbox', execution),
    );
    await this.directory.configureOwner(
      plan,
      operationContext(plan.requestId, 'configure-owner', execution),
    );
    return { identity: plan.identity, status: 'CONFIGURED' };
  }
}
