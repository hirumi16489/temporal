import type { PreparedMailboxProvisioning, MailboxProvisionResult } from '../contracts/index';
import { createProvisioningPlan } from '../../domain/index';
import {
  operationContext,
  type ExecutionContext,
  type MailboxGateway,
} from '../ports/outbound/mailbox.ports';
export class MailboxProvisioningService {
  constructor(private readonly mailboxes: MailboxGateway) {}
  async provision(
    command: PreparedMailboxProvisioning,
    execution: ExecutionContext,
  ): Promise<MailboxProvisionResult> {
    const plan = createProvisioningPlan(command);
    const status = await this.mailboxes.ensureMailbox(
      plan,
      operationContext(plan.requestId, 'provision-mailbox', execution),
    );
    return { identity: plan.identity, status };
  }
}
