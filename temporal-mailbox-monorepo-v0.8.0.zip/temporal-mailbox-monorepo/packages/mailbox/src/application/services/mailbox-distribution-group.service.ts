import type {
  PreparedMailboxProvisioning,
  MailboxDistributionGroupResult,
} from '../contracts/index';
import { createProvisioningPlan, InvalidMailboxRequest } from '../../domain/index';
import {
  operationContext,
  type ExecutionContext,
  type DistributionGroupGateway,
} from '../ports/outbound/mailbox.ports';
export class MailboxDistributionGroupService {
  constructor(private readonly groups: DistributionGroupGateway) {}
  async provision(
    command: PreparedMailboxProvisioning,
    execution: ExecutionContext,
  ): Promise<MailboxDistributionGroupResult> {
    const plan = createProvisioningPlan(command);
    if (!plan.group)
      throw new InvalidMailboxRequest('A distribution group requires a group mailbox request');
    await this.groups.ensureDistributionGroup(
      plan,
      operationContext(plan.requestId, 'provision-distribution-group', execution),
    );
    return { identity: plan.identity, groupIdentity: plan.group.identity, status: 'CONFIGURED' };
  }
}
