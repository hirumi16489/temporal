import type { ProvisioningRequest, PreparedMailboxProvisioning } from '../contracts/index';
import { createProvisioningPlan } from '../../domain/index';
import { toPreparedCommand } from '../mapping/provisioning.mapper';
export class MailboxPreparationService {
  prepare(request: ProvisioningRequest): PreparedMailboxProvisioning {
    return toPreparedCommand(createProvisioningPlan(request));
  }
}
