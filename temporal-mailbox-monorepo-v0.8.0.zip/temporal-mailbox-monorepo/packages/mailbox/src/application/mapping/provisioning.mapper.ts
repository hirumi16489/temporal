import type { PreparedMailboxProvisioning } from '../contracts/index';
import type { MailboxProvisioningPlan } from '../../domain/index';
export function toPreparedCommand(plan: MailboxProvisioningPlan): PreparedMailboxProvisioning {
  const common = {
    requestId: plan.requestId,
    identity: plan.identity,
    displayName: plan.displayName,
    configuration: plan.configuration,
  };
  if (plan.kind === 'ROOM') return { ...common, kind: 'ROOM', room: plan.room };
  if (plan.kind === 'GROUP') return { ...common, kind: 'GROUP', group: plan.group };
  return { ...common, kind: 'PERSONAL' };
}
