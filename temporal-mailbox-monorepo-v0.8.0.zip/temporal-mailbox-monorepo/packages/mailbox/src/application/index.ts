import type { MailboxPorts } from './ports/outbound/mailbox.ports';
import { MailboxPreparationService } from './services/mailbox-preparation.service';
import { MailboxProvisioningService } from './services/mailbox-provisioning.service';
import { MailboxReadinessService } from './services/mailbox-readiness.service';
import { MailboxConfigurationService } from './services/mailbox-configuration.service';
import { MailboxDistributionGroupService } from './services/mailbox-distribution-group.service';
export * from './ports/outbound/mailbox.ports';
export {
  MailboxPreparationService,
  MailboxProvisioningService,
  MailboxReadinessService,
  MailboxConfigurationService,
  MailboxDistributionGroupService,
};
export function createMailboxServices(ports: MailboxPorts) {
  return Object.freeze({
    preparation: new MailboxPreparationService(),
    provisioning: new MailboxProvisioningService(ports.mailboxes),
    readiness: new MailboxReadinessService(ports.mailboxes),
    configuration: new MailboxConfigurationService(ports.mailboxes, ports.directory),
    distributionGroups: new MailboxDistributionGroupService(ports.groups),
  });
}
export type MailboxServices = ReturnType<typeof createMailboxServices>;
export { toPreparedCommand } from './mapping/provisioning.mapper';
