import { activityInfo, cancellationSignal, log } from '@temporalio/activity';
import type { MailboxActivities } from '../../../application/contracts/index';
import type { MailboxServices, ExecutionContext } from '../../../application/index';
import { mapMailboxFailure } from './failure-mapping';
export { mapMailboxFailure };
export function createMailboxActivityHandlers(services: MailboxServices): MailboxActivities {
  async function execute<T>(
    operation: string,
    task: (context: ExecutionContext) => Promise<T> | T,
  ): Promise<T> {
    const context = { attempt: activityInfo().attempt, signal: cancellationSignal() };
    log.info('Mailbox capability executing', { operation, attempt: context.attempt });
    try {
      return await task(context);
    } catch (error) {
      return mapMailboxFailure(error);
    }
  }
  return {
    prepareMailboxProvisioning: (request) =>
      execute('prepareMailboxProvisioning', () => services.preparation.prepare(request)),
    provisionMailbox: (request) =>
      execute('provisionMailbox', (context) => services.provisioning.provision(request, context)),
    checkMailboxReadiness: (request) =>
      execute('checkMailboxReadiness', (context) => services.readiness.check(request, context)),
    configureMailbox: (request) =>
      execute('configureMailbox', (context) => services.configuration.configure(request, context)),
    provisionMailboxDistributionGroup: (request) =>
      execute('provisionMailboxDistributionGroup', (context) =>
        services.distributionGroups.provision(request, context),
      ),
  };
}
