import { ApplicationFailure } from '@temporalio/common';
import { ProvisioningError } from '../../../domain/index';
export function mapMailboxFailure(error: unknown): never {
  if (error instanceof ProvisioningError && !error.retryable)
    throw ApplicationFailure.nonRetryable(error.message, error.code);
  throw error;
}
