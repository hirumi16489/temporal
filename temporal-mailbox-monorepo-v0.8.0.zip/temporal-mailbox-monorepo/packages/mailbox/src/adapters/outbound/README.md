# Enterprise mailbox adapters

This folder owns external implementations of the application ports. `createEnterpriseMailboxPorts()` deliberately throws `ExternalAdapterNotConfigured` today. Provider details are unknown; no endpoint, authentication scheme or successful provider behavior has been invented.

Implement a provider-specific module per real dependency and keep transport DTOs/mapping private to it. Return `MailboxPorts` from the composition factory. Supply endpoint/credentials/clients through validated configuration in the host; never import test fixtures or select the simulator based on a production flag.

| Port                                               | Required behavior                                                                                           |
| -------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| `MailboxGateway.ensureMailbox`                     | Create or reconcile the requested mailbox; distinguish matching existing resource from conflicting identity |
| `MailboxGateway.isReady`                           | One bounded availability check; `false` means propagation pending, failures remain errors                   |
| `MailboxGateway.configureSettings`                 | Reconcile desired settings including room-specific configuration; safe on repeated attempts                 |
| `DirectoryGateway.configureOwner`                  | Reconcile owner independently with a stable operation key                                                   |
| `DistributionGroupGateway.ensureDistributionGroup` | Ensure group/members converge; reject incompatible identity reuse                                           |

Honor the supplied AbortSignal, bound network operations, and propagate stable idempotency keys where supported. If the provider lacks deduplication, check existing state and converge. A lost response may occur after a committed side effect; never assume failure implies nothing happened.

Translate permanent validation/permission/conflict failures to the corresponding domain errors, transient dependency failures to `DependencyUnavailable`. Do not convert provider outages into readiness `false`. Keep credentials and raw provider payloads out of error messages/logs.

Add provider contract/integration tests under `test/integration`, with sanitized fake transport responses under `test/support`. The existing test adapters exercise the application port contract against a simulator; they are not evidence of compatibility with any actual enterprise service.
