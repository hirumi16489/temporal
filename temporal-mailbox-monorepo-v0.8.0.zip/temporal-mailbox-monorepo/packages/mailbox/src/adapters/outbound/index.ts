import type { MailboxPorts } from '../../application/index';
import { ExternalAdapterNotConfigured } from '../../domain/index';
// Intentionally fails at composition time. No test provider can be selected by a production host.
// Implement approved gateway providers here once the external systems/contracts are known.
export function createEnterpriseMailboxPorts(): MailboxPorts {
  throw new ExternalAdapterNotConfigured(
    'External mailbox, directory and distribution-group adapters have not been supplied. Bind approved MailboxPorts in the mailbox activity-worker composition root. Use npm run dev for the separate test-support runtime.',
  );
}
