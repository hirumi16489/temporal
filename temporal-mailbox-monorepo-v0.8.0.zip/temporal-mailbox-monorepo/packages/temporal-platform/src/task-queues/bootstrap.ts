import { randomBytes } from 'node:crypto';
export function resolvePools(
  definitions: Record<string, { capability: string; isolation: string | null }>,
  existing: Record<string, string> = {},
  namespace = 'automation.v2',
) {
  const entries = { ...existing };
  const profiles: Record<string, string> = {};
  for (const [profile, definition] of Object.entries(definitions)) {
    const key = definition.capability + ':' + (definition.isolation ?? 'shared');
    const prefix = `${namespace}.${definition.capability}.${definition.isolation ?? 'shared'}`;
    if (!entries[key])
      entries[key] = definition.isolation ? prefix + '.' + randomBytes(8).toString('hex') : prefix;
    if (
      typeof entries[key] !== 'string' ||
      !entries[key].startsWith(prefix) ||
      (definition.isolation
        ? !/^\.[a-f0-9]{16}$/.test(entries[key].slice(prefix.length))
        : entries[key] !== prefix)
    )
      throw new Error('Invalid stored queue for ' + key);
    profiles[profile] = entries[key];
  }
  const names = Object.values(entries);
  if (new Set(names).size !== names.length)
    throw new Error('Two pool identities resolve to the same queue');
  return { entries, profiles };
}
