export type PoolDefinition = Readonly<{ capability: string; isolation: string | null }>;
export function createPoolBuilders<
  const C extends Record<string, string>,
  const I extends Record<string, string>,
>(capabilities: C, isolations: I) {
  type Capability = C[keyof C];
  type Isolation = I[keyof I];
  function activityPool(capability: Capability): PoolDefinition {
    if (!Object.values(capabilities).includes(capability))
      throw new Error('Undeclared activity pool: ' + capability);
    return Object.freeze({ capability, isolation: null });
  }
  function dedicatedActivityPool(capability: Capability, isolation: Isolation): PoolDefinition {
    activityPool(capability);
    if (!Object.values(isolations).includes(isolation))
      throw new Error('Undeclared isolation key: ' + isolation);
    return Object.freeze({ capability, isolation });
  }
  return { activityPool, dedicatedActivityPool };
}
export const poolKey = (definition: PoolDefinition): string =>
  definition.capability + ':' + (definition.isolation ?? 'shared');
