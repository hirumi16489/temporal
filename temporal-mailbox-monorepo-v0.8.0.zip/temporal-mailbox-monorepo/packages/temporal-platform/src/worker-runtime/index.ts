import { NativeConnection, type Worker } from '@temporalio/worker';
import { temporalConnectionSettings } from '../connection/index';
export const temporalSettings = temporalConnectionSettings;
export async function runWorkerHost(
  factory: (connection: NativeConnection, namespace: string) => Promise<Worker>,
) {
  const settings = temporalSettings();
  const connection = await NativeConnection.connect({
    address: settings.address,
    tls: settings.tls,
  });
  try {
    const worker = await factory(connection, settings.namespace);
    await worker.run();
  } finally {
    await connection.close();
  }
}
