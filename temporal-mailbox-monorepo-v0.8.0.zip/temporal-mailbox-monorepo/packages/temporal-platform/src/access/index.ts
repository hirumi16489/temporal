export interface ClientPrincipal {
  readonly id: string;
  readonly certificateFingerprints: readonly string[];
  readonly workflowTypes: readonly string[];
  readonly workflowIdPrefix: string;
}
export interface WorkflowAccessPolicy {
  readonly namespace: string;
  readonly workflowTaskQueue: string;
  readonly clients: readonly ClientPrincipal[];
}
export interface AccessTarget {
  readonly operation: 'start' | 'read';
  readonly namespace: string;
  readonly workflowId: string;
  readonly workflowType?: string;
  readonly taskQueue?: string;
}
export function fingerprint(value: string): string {
  const normalized = value.replaceAll(':', '').toUpperCase();
  if (!/^[A-F0-9]{64}$/.test(normalized))
    throw new Error('Certificate fingerprint must be SHA-256');
  return normalized;
}
export function validateAccessPolicy(value: unknown): WorkflowAccessPolicy {
  if (!value || typeof value !== 'object') throw new Error('Access policy must be an object');
  const policy = value as WorkflowAccessPolicy;
  if (
    typeof policy.namespace !== 'string' ||
    !policy.namespace.trim() ||
    typeof policy.workflowTaskQueue !== 'string' ||
    !policy.workflowTaskQueue.trim() ||
    !Array.isArray(policy.clients) ||
    !policy.clients.length
  )
    throw new Error('Policy requires a namespace, workflow task queue and clients');
  const ids = new Set<string>(),
    certificates = new Set<string>(),
    prefixes: string[] = [];
  const clients = policy.clients.map((client) => {
    if (
      !client ||
      typeof client.id !== 'string' ||
      !/^[a-z][a-z0-9-]{1,63}$/.test(client.id) ||
      ids.has(client.id)
    )
      throw new Error('Client identities must be unique identifiers');
    ids.add(client.id);
    if (
      !Array.isArray(client.workflowTypes) ||
      !client.workflowTypes.length ||
      client.workflowTypes.some((type: unknown) => typeof type !== 'string' || !type.trim())
    )
      throw new Error('Client must explicitly declare workflow types');
    if (
      typeof client.workflowIdPrefix !== 'string' ||
      !client.workflowIdPrefix ||
      prefixes.some(
        (prefix) =>
          prefix.startsWith(client.workflowIdPrefix) || client.workflowIdPrefix.startsWith(prefix),
      )
    )
      throw new Error('Client workflow ID prefixes must be nonempty and disjoint');
    prefixes.push(client.workflowIdPrefix);
    if (!Array.isArray(client.certificateFingerprints) || !client.certificateFingerprints.length)
      throw new Error('Client must explicitly pin certificates');
    const pins = client.certificateFingerprints.map((pin: unknown) => {
      if (typeof pin !== 'string') throw new Error('Invalid certificate fingerprint');
      const normalized = fingerprint(pin);
      if (certificates.has(normalized))
        throw new Error('Certificate cannot identify multiple clients');
      certificates.add(normalized);
      return normalized;
    });
    return Object.freeze({
      ...client,
      certificateFingerprints: Object.freeze(pins),
      workflowTypes: Object.freeze([...client.workflowTypes]),
    });
  });
  return Object.freeze({
    namespace: policy.namespace,
    workflowTaskQueue: policy.workflowTaskQueue,
    clients: Object.freeze(clients),
  });
}
export function principalForCertificate(
  policy: WorkflowAccessPolicy,
  certificateFingerprint: string | undefined,
): ClientPrincipal | undefined {
  if (!certificateFingerprint) return undefined;
  const pin = fingerprint(certificateFingerprint);
  return policy.clients.find((client) => client.certificateFingerprints.includes(pin));
}
export function authorizeWorkflowAccess(
  policy: WorkflowAccessPolicy,
  principal: ClientPrincipal,
  target: AccessTarget,
): boolean {
  if (
    target.namespace !== policy.namespace ||
    !target.workflowId ||
    !target.workflowId.startsWith(principal.workflowIdPrefix)
  )
    return false;
  if (target.operation === 'start')
    return (
      target.taskQueue === policy.workflowTaskQueue &&
      principal.workflowTypes.includes(target.workflowType ?? '')
    );
  return target.operation === 'read';
}
