export interface WorkflowDiagramStep {
  id: string;
  label: string;
  kind: 'start' | 'activity' | 'wait' | 'end';
  completionField?: string;
  activityTypes: readonly string[];
  position: { x: number; y: number };
}
export interface WorkflowDiagram {
  version: number;
  title: string;
  steps: readonly WorkflowDiagramStep[];
  edges: readonly (readonly [string, string])[];
}

export function createDiagramRegistry(
  ...sources: Readonly<Record<string, WorkflowDiagram>>[]
): Readonly<Record<string, WorkflowDiagram>> {
  const result: Record<string, WorkflowDiagram> = Object.create(null);
  for (const source of sources)
    for (const [name, diagram] of Object.entries(source)) {
      if (Object.hasOwn(result, name)) throw new Error('Duplicate workflow diagram: ' + name);
      const ids = new Set(diagram.steps.map((step) => step.id));
      if (
        ids.size !== diagram.steps.length ||
        diagram.edges.some(([from, to]) => !ids.has(from) || !ids.has(to))
      )
        throw new Error('Invalid workflow diagram: ' + name);
      result[name] = diagram;
    }
  return Object.freeze(result);
}
