import { readFileSync } from 'node:fs';
import { createSecureContext } from 'node:tls';
import type { TLSConfig } from '@temporalio/worker';
export function temporalConnectionSettings(env: NodeJS.ProcessEnv = process.env) {
  const address = env.TEMPORAL_ADDRESS ?? 'localhost:7233',
    namespace = env.TEMPORAL_NAMESPACE ?? 'default';
  if (!address.trim() || !namespace.trim())
    throw new Error('Temporal address and namespace must not be empty');
  if (
    env.TEMPORAL_TLS_ENABLED !== undefined &&
    !['true', 'false'].includes(env.TEMPORAL_TLS_ENABLED)
  )
    throw new Error('TEMPORAL_TLS_ENABLED must be true or false');
  const ca = env.TEMPORAL_TLS_CA_FILE,
    cert = env.TEMPORAL_TLS_CLIENT_CERT_FILE,
    key = env.TEMPORAL_TLS_CLIENT_KEY_FILE,
    serverName = env.TEMPORAL_TLS_SERVER_NAME;
  if (!!cert !== !!key)
    throw new Error('Temporal client certificate and key must be configured together');
  const configured = !!(ca || cert || key || serverName);
  if (configured && env.TEMPORAL_TLS_ENABLED === 'false')
    throw new Error('TLS credentials cannot be configured while TLS is disabled');
  if (!configured && env.TEMPORAL_TLS_ENABLED !== 'true')
    return { address, namespace, tls: undefined };
  const load = (path: string, label: string) => {
    try {
      return readFileSync(path);
    } catch {
      throw new Error('Cannot read ' + label + ' file: ' + path);
    }
  };
  const root = ca ? load(ca, 'Temporal server CA') : undefined;
  const pair =
    cert && key
      ? { crt: load(cert, 'Temporal client certificate'), key: load(key, 'Temporal client key') }
      : undefined;
  // Validate PEM material and matching certificate/private key before any network call.
  createSecureContext({ ca: root, cert: pair?.crt, key: pair?.key, minVersion: 'TLSv1.2' });
  const tls: TLSConfig = {
    ...(root ? { serverRootCACertificate: root } : {}),
    ...(pair ? { clientCertPair: pair } : {}),
    ...(serverName ? { serverNameOverride: serverName } : {}),
  };
  return { address, namespace, tls };
}
