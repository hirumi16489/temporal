import { createViewerServer } from './server-lib.mjs';
const port = Number(process.env.VIEWER_PORT ?? 7531);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid VIEWER_PORT');
const host = process.env.VIEWER_HOST ?? '127.0.0.1';
const server = createViewerServer({
  endpoint: process.env.TEMPORAL_UI_URL ?? 'http://localhost:8233',
  namespace: process.env.TEMPORAL_NAMESPACE ?? 'default',
});
server.on('error', (error) => {
  console.error('Viewer startup failed:', error.message);
  process.exitCode = 1;
});
server.listen(port, host, () => console.log(`Browser viewer ready at http://${host}:${port}`));
for (const signal of ['SIGTERM', 'SIGINT'])
  process.once(signal, () => {
    server.close();
    server.closeAllConnections();
  });
