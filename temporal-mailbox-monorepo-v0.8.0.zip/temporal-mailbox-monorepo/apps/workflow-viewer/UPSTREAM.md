# Upstream attribution

Adapted browser UI from https://github.com/nguyenanhtuan21/temporal-web-visualize
Commit: 23cee674ad4037477907d424ce654eeeffafd4bb

The upstream MIT license is preserved in UPSTREAM-LICENSE (copyright 2025 itaisoudry as supplied by that repository). The desktop Temporal Flow application is not included.

Local changes: one-origin Node server, server deployment configuration, read-only HTTP API, live refresh and terminal stopping, payload decoding, pending activity states, paginated history, workflow-task-based graph edges, live selection and tests.

Version 0.5 adds typed fixed workflow definitions, in-place state/attempt overlays, grouped availability waiting, status colors/spinners and viewport preservation. The original history-derived diagram remains as the optional execution trace.
