import type { ListWorkflowExecutionsResponse, WorkflowSnapshot } from '../types/schema';

export const viewerConfig = { namespace: 'default', pollIntervalMs: 2000 };
export async function loadConfig() {
  const config = await getJson('/api/config');
  viewerConfig.namespace = config.namespace;
  viewerConfig.pollIntervalMs = config.pollIntervalMs;
}
async function getJson(path: string, signal?: AbortSignal) {
  const response = await fetch(path, { signal, cache: 'no-store' });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `Viewer API returned ${response.status}`);
  }
  return response.json();
}
export function searchWorkflows(
  query: string,
  namespace: string,
  nextPageToken = '',
  signal?: AbortSignal,
): Promise<ListWorkflowExecutionsResponse> {
  return getJson('/api/search?' + new URLSearchParams({ query, namespace, nextPageToken }), signal);
}
export function getWorkflowSnapshot(
  id: string,
  runId: string,
  namespace: string,
  signal?: AbortSignal,
): Promise<WorkflowSnapshot> {
  return getJson('/api/workflow?' + new URLSearchParams({ id, runId, namespace }), signal);
}
