import { WorkflowDiagrams as mailboxDiagrams } from '@automation/mailbox/diagrams';
import { createDiagramRegistry } from '@automation/temporal-platform/visualization';
// Viewer composition point: teams publish their descriptors; no workflow implementation imports.
export const WorkflowDiagrams = createDiagramRegistry(mailboxDiagrams);
