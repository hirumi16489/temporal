import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { searchWorkflows, viewerConfig } from '../api/client';
import { SearchBar } from '../components/workflow/SearchBar';
import { WorkflowTable } from '../components/workflow/WorkflowTable';
export default function Dashboard() {
  const [searchParams, setSearchParams] = useState({
    query: "WorkflowId STARTS_WITH 'mailbox-'",
    namespace: viewerConfig.namespace,
  });
  const [pageToken, setPageToken] = useState('');
  const query = useQuery({
    queryKey: ['workflows', searchParams, pageToken],
    queryFn: ({ signal }) =>
      searchWorkflows(searchParams.query, searchParams.namespace, pageToken, signal),
    refetchInterval: 5000,
    retry: false,
  });
  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-2xl font-bold">Workflow executions</h1>
        <p className="text-sm text-slate-500">
          Live list · refreshes every 5 seconds. Select an execution to inspect its graph and
          activity payloads.
        </p>
      </div>
      <SearchBar
        initialNamespace={viewerConfig.namespace}
        initialQuery={searchParams.query}
        onSearch={(q, namespace) => {
          setPageToken('');
          setSearchParams({ query: q, namespace });
          void query.refetch();
        }}
      />
      {query.isLoading && <div>Loading…</div>}
      {query.error && (
        <div role="alert" className="text-red-700">
          {query.error.message}
        </div>
      )}
      {query.data && (
        <WorkflowTable workflows={query.data.executions || []} namespace={searchParams.namespace} />
      )}
      <div className="flex gap-2">
        <button
          className="border rounded px-3 py-2"
          onClick={() => {
            setPageToken('');
            void query.refetch();
          }}
        >
          First page / refresh
        </button>
        {query.data?.nextPageToken && (
          <button
            className="border rounded px-3 py-2"
            onClick={() => setPageToken(query.data.nextPageToken!)}
          >
            Next page
          </button>
        )}
      </div>
    </div>
  );
}
