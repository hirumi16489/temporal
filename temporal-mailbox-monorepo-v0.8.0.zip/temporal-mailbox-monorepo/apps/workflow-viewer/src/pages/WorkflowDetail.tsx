import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getWorkflowSnapshot, viewerConfig } from '../api/client';
import { buildFixedGraph } from '../lib/fixed-graph';
import { transformEventsToGraph } from '../lib/graph-transformer';
import { liveInterval, workflowStatus } from '../lib/live';
import { inspectPayloads } from '../lib/payloads';
import { WorkflowGraph } from '../components/workflow/WorkflowGraph';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '../components/ui/sheet';

function Json({ value, empty }: { value: unknown; empty: string }) {
  return (
    <pre className="whitespace-pre-wrap break-all bg-slate-50 border rounded p-3 text-xs">
      {value === undefined ? empty : JSON.stringify(value, null, 2)}
    </pre>
  );
}
export default function WorkflowDetail() {
  const { workflowId, runId, namespace } = useParams();
  const [live, setLive] = useState(true),
    [selectedId, setSelectedId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'graph' | 'trace' | 'history'>('graph');
  const query = useQuery({
    queryKey: ['workflow-events', workflowId, runId, namespace],
    queryFn: ({ signal }) =>
      getWorkflowSnapshot(workflowId!, runId!, namespace || viewerConfig.namespace, signal),
    enabled: !!workflowId && !!runId,
    refetchInterval: (current) =>
      liveInterval(current.state.data, live, viewerConfig.pollIntervalMs),
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: false,
    retry: false,
  });
  const { data, error, isLoading, dataUpdatedAt } = query;
  const fixed = useMemo(() => buildFixedGraph(data), [data]);
  const trace = useMemo(
    () =>
      viewMode === 'trace' || !fixed
        ? transformEventsToGraph(data?.events ?? [], data?.description.pendingActivities ?? [])
        : { nodes: [], edges: [] },
    [data, viewMode, fixed],
  );
  const graph = viewMode === 'graph' && fixed ? fixed : trace;
  const selected = graph.nodes.find((node) => node.id === selectedId);
  const details = inspectPayloads(selected?.data.rawEvents ?? []);
  const active = liveInterval(data) !== false;
  if (isLoading) return <div>Loading execution…</div>;
  return (
    <div className="flex flex-col gap-4">
      <Link to="/" className="underline text-sm">
        ← Executions
      </Link>
      <div className="flex flex-wrap justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold break-all">{workflowId}</h1>
          <div className="text-xs text-slate-500 break-all">
            Namespace {namespace} · Run {runId}
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <span data-testid="workflow-status" className="font-semibold text-sm">
            {workflowStatus(data)}
          </span>
          <button
            className="border rounded px-3 py-2 text-sm"
            onClick={() => setLive(!live)}
            disabled={!active}
          >
            {!active ? 'Finished · refresh stopped' : live ? 'Pause live' : 'Resume live'}
          </button>
          <button
            className="border rounded px-3 py-2 text-sm"
            onClick={() => void query.refetch()}
            disabled={query.isFetching}
          >
            Refresh
          </button>
        </div>
      </div>
      <div className="text-xs text-slate-500" role="status">
        {active && live
          ? 'Live · refreshes every 2 seconds'
          : active
            ? 'Live refresh paused'
            : 'Execution closed'}{' '}
        · Last updated {dataUpdatedAt ? new Date(dataUpdatedAt).toLocaleTimeString() : 'never'}
      </div>
      {error && (
        <div role="alert" className="rounded border border-red-300 bg-red-50 p-3 text-red-700">
          Refresh failed: {error.message}.{' '}
          {data ? 'Showing the last successful snapshot.' : 'Check the Temporal UI connection.'}
        </div>
      )}
      <div className="flex gap-2">
        <button
          className="border rounded px-3 py-1"
          aria-pressed={viewMode === 'graph'}
          onClick={() => {
            setSelectedId(null);
            setViewMode('graph');
          }}
        >
          Workflow
        </button>
        <button
          className="border rounded px-3 py-1"
          aria-pressed={viewMode === 'trace'}
          onClick={() => {
            setSelectedId(null);
            setViewMode('trace');
          }}
        >
          Execution trace
        </button>
        <button
          className="border rounded px-3 py-1"
          aria-pressed={viewMode === 'history'}
          onClick={() => setViewMode('history')}
        >
          History
        </button>
      </div>
      <p className="text-xs text-slate-500">
        {viewMode === 'graph' && fixed
          ? `${fixed.diagram.title} · fixed definition v${fixed.diagram.version}. Blue: running · Amber: waiting · Orange: retrying · Green: succeeded · Dashed green + Reused: result from before reset · Red: failed · Gray: not started.`
          : 'Observed execution trace; nodes appear as events are recorded.'}
      </p>
      {viewMode === 'graph' && !fixed && (
        <p role="note" className="text-sm text-amber-800">
          No fixed definition is registered for this workflow type. Showing its execution trace.
        </p>
      )}
      {fixed && fixed.unmapped.length > 0 && (
        <p role="alert" className="text-sm text-amber-800">
          Definition mismatch: unmapped activities {fixed.unmapped.join(', ')}. Inspect the
          execution trace and update the workflow diagram.
        </p>
      )}
      {viewMode !== 'history' ? (
        <WorkflowGraph
          key={`${workflowId}-${runId}-${viewMode}`}
          nodes={graph.nodes}
          edges={graph.edges}
          onNodeClick={(_, node) => setSelectedId(node.id)}
        />
      ) : (
        <div className="border rounded overflow-auto max-h-[650px]">
          {data?.events.map((event) => (
            <details className="border-b p-3 text-xs" key={event.eventId}>
              <summary>
                {event.eventId} · {event.eventType} ·{' '}
                {new Date(event.eventTime).toLocaleTimeString()}
              </summary>
              <Json value={event} empty="" />
            </details>
          ))}
        </div>
      )}
      <Sheet
        open={!!selected}
        onOpenChange={(open) => {
          if (!open) setSelectedId(null);
        }}
      >
        <SheetContent className="w-full sm:max-w-xl overflow-auto">
          <SheetHeader>
            <SheetTitle>{selected?.data.label}</SheetTitle>
            <SheetDescription>
              {selected?.data.status} · {selected?.data.queueName || 'Workflow orchestration'}
            </SheetDescription>
          </SheetHeader>
          <div className="flex flex-col gap-3 mt-5" data-testid="node-details">
            {selected?.data.reused && (
              <div
                className="rounded border border-dashed border-green-500 bg-green-50 p-3 text-sm text-green-900"
                data-testid="reused-result"
              >
                <p className="font-semibold">Reused from previous run</p>
                <p>
                  This recorded result was preserved at reset. The activity did not execute again in
                  this run.
                </p>
                {selected.data.reused.sourceRunId && (
                  <p className="break-all">
                    Source Run ID:{' '}
                    <Link
                      className="underline"
                      to={`/workflow/${encodeURIComponent(namespace || viewerConfig.namespace)}/${encodeURIComponent(workflowId!)}/${encodeURIComponent(selected.data.reused.sourceRunId)}`}
                    >
                      {selected.data.reused.sourceRunId}
                    </Link>
                  </p>
                )}
                <p>Reset boundary event: {selected.data.reused.resetEventId}</p>
              </div>
            )}
            {selected?.data.checkCount !== undefined && (
              <p className="text-sm">
                {selected.data.checkCount} availability checks. Input is from the latest check;
                output is from the latest completed check. Expand raw events for all checks and
                durable timers.
              </p>
            )}
            {selected?.data.attempt !== undefined && (
              <p className="text-sm">Attempt {selected.data.attempt}</p>
            )}
            <h2 className="font-semibold">Input</h2>
            <Json value={details.input} empty="No input payload for this event." />
            <h2 className="font-semibold">Output</h2>
            <Json
              value={details.output}
              empty={
                ['running', 'scheduled', 'waiting', 'retrying'].includes(
                  selected?.data.status ?? '',
                )
                  ? 'Waiting for completion…'
                  : 'No output payload.'
              }
            />
            {(details.failure || selected?.data.lastFailure) && (
              <>
                <h2 className="font-semibold">Failure / last retry failure</h2>
                <Json value={details.failure ?? selected?.data.lastFailure} empty="" />
              </>
            )}
            <details>
              <summary className="cursor-pointer font-semibold">Raw Temporal events</summary>
              <Json value={selected?.data.rawEvents} empty="No events" />
            </details>
            <p className="text-xs text-slate-500">
              Default json/plain payloads are decoded. Custom codecs and encrypted payloads remain
              in their original encoding.
            </p>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
