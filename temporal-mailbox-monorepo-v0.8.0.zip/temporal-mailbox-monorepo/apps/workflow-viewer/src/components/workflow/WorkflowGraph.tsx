import { useEffect, useState } from 'react';
import ReactFlow, { Background, Controls, MiniMap } from 'reactflow';
import type { Node, Edge, NodeTypes, ReactFlowInstance } from 'reactflow';
import 'reactflow/dist/style.css';
import { WorkflowNode } from './WorkflowNode';

interface WorkflowGraphProps {
  nodes: Node[];
  edges: Edge[];
  onNodeClick: (event: React.MouseEvent, node: Node) => void;
}

const nodeTypes: NodeTypes = {
  workflowNode: WorkflowNode,
};

export function WorkflowGraph({ nodes, edges, onNodeClick }: WorkflowGraphProps) {
  const [instance, setInstance] = useState<ReactFlowInstance | null>(null);
  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      void instance?.fitView({ padding: 0.15, duration: 150 });
    });
    return () => cancelAnimationFrame(frame);
  }, [instance]);
  return (
    <div className="h-[min(68vh,760px)] min-h-[420px] w-full border rounded-md bg-slate-50">
      <ReactFlow
        onInit={setInstance}
        nodes={nodes}
        edges={edges}
        onNodeClick={onNodeClick}
        nodeTypes={nodeTypes}
        nodesDraggable={false}
        nodesConnectable={false}
        minZoom={0.15}
        fitView
      >
        <Background gap={16} size={1} />
        <Controls />
        <MiniMap />
      </ReactFlow>
    </div>
  );
}
