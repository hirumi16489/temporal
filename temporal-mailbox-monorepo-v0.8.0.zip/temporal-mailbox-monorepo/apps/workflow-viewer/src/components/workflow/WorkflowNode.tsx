import { Handle, Position } from 'reactflow';
import type { NodeProps } from 'reactflow';
import {
  Activity,
  Play,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  RotateCw,
  Circle,
  MinusCircle,
} from 'lucide-react';
import type { HistoryEvent } from '../../types/schema';

export interface LogicalNodeData {
  label: string;
  type: 'workflow' | 'activity' | 'timer' | 'signal' | 'other';
  status:
    | 'idle'
    | 'not-run'
    | 'completed'
    | 'failed'
    | 'running'
    | 'waiting'
    | 'retrying'
    | 'canceled'
    | 'scheduled';
  reused?: { sourceRunId?: string; resetEventId: string };
  activityName?: string;
  checkCount?: number;
  attempt?: number;
  lastFailure?: unknown;
  duration?: number;
  startTime: string;
  queueName?: string;
  id: string;
  rawEvents: HistoryEvent[];
}
export const stepPresentation = {
  idle: {
    label: 'Not started',
    classes: 'border-slate-200 bg-slate-50 text-slate-500',
    icon: Circle,
  },
  'not-run': {
    label: 'Not reached',
    classes: 'border-slate-200 bg-slate-50 text-slate-400',
    icon: MinusCircle,
  },
  scheduled: { label: 'Queued', classes: 'border-blue-300 bg-blue-50 text-blue-700', icon: Clock },
  running: { label: 'Running', classes: 'border-blue-500 bg-blue-50 text-blue-800', icon: Loader2 },
  waiting: {
    label: 'Waiting',
    classes: 'border-amber-400 bg-amber-50 text-amber-800',
    icon: Loader2,
  },
  retrying: {
    label: 'Retrying',
    classes: 'border-orange-400 bg-orange-50 text-orange-800',
    icon: RotateCw,
  },
  completed: {
    label: 'Succeeded',
    classes: 'border-green-500 bg-green-50 text-green-800',
    icon: CheckCircle2,
  },
  failed: { label: 'Failed', classes: 'border-red-500 bg-red-50 text-red-800', icon: XCircle },
  canceled: {
    label: 'Canceled',
    classes: 'border-slate-400 bg-slate-100 text-slate-600',
    icon: MinusCircle,
  },
};
export function WorkflowNode({ data, selected }: NodeProps<LogicalNodeData>) {
  const presentation = stepPresentation[data.status];
  const Icon = presentation.icon;
  const active = ['running', 'waiting', 'retrying'].includes(data.status);
  const KindIcon = data.type === 'workflow' ? Play : data.type === 'timer' ? Clock : Activity;
  return (
    <div
      className="w-[340px]"
      data-step-status={data.status}
      data-execution-origin={data.reused ? 'reused' : 'current'}
    >
      <Handle type="target" position={Position.Top} className="!bg-slate-400" />
      <div
        className={`h-[104px] rounded-xl border-2 shadow-sm px-4 py-3 transition-colors ${presentation.classes} ${data.reused ? 'border-dashed' : ''} ${selected ? 'ring-2 ring-slate-400 ring-offset-2' : ''}`}
      >
        <div className="flex items-center justify-between gap-2 text-xs font-semibold">
          <span className="flex items-center gap-2">
            <Icon
              aria-hidden="true"
              className={`h-5 w-5 ${active ? 'animate-spin motion-reduce:animate-none' : ''}`}
            />
            {presentation.label}
          </span>
          {data.attempt !== undefined && <span>Attempt {data.attempt}</span>}
          {data.checkCount !== undefined && <span>{data.checkCount} checks</span>}
        </div>
        <div className="flex items-center gap-2 mt-2">
          <KindIcon className="h-4 w-4 shrink-0" />
          <div className="font-semibold text-sm truncate" title={data.label}>
            {data.label}
          </div>
        </div>
        <div
          className="mt-1 text-[10px] font-mono truncate opacity-70"
          title={data.queueName || data.activityName}
        >
          {data.reused ? (
            <span
              className="rounded bg-green-100 px-1.5 py-0.5 font-sans font-semibold text-green-800"
              title="Recorded result reused during reset replay; this activity did not execute again in this run."
            >
              Reused from previous run
            </span>
          ) : (
            data.activityName || data.queueName || data.id
          )}
        </div>
      </div>
      <Handle type="source" position={Position.Bottom} className="!bg-slate-400" />
    </div>
  );
}
