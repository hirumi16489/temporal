import type { Node, Edge } from 'reactflow';
import type { HistoryEvent } from '../types/schema';
import type { LogicalNodeData } from '../components/workflow/WorkflowNode';
import dagre from 'dagre';

// Edges follow observed workflow-task command batches, not guessed timestamp order.
// They express execution causality; arbitrary business dependencies aren't recoverable from history.
export function transformEventsToGraph(
  events: HistoryEvent[],
  pendingActivities: any[] = [],
): { nodes: Node<LogicalNodeData>[]; edges: Edge[] } {
  const nodes: Node<LogicalNodeData>[] = [],
    edges: Edge[] = [];
  const operations: { node: Node<LogicalNodeData>; command: string; end?: HistoryEvent }[] = [];
  const index = new Map(events.map((event, i) => [String(event.eventId), i]));
  const type = (event: HistoryEvent) => event.eventType.replace(/^EVENT_TYPE_/, '');
  const start = events.find((event) => type(event) === 'WORKFLOW_EXECUTION_STARTED');
  const close = events.find((event) =>
    /^WORKFLOW_EXECUTION_(COMPLETED|FAILED|CANCELED|TERMINATED|TIMED_OUT|CONTINUED_AS_NEW)$/.test(
      type(event),
    ),
  );
  const status = (event?: HistoryEvent): LogicalNodeData['status'] =>
    !event
      ? 'running'
      : type(event).endsWith('COMPLETED') || type(event).endsWith('FIRED')
        ? 'completed'
        : type(event).endsWith('CANCELED')
          ? 'canceled'
          : 'failed';
  const make = (id: string, data: LogicalNodeData) => {
    const node = { id, type: 'workflowNode', data, position: { x: 0, y: 0 } };
    nodes.push(node);
    return node;
  };
  if (start)
    make('workflow', {
      id: 'start',
      label:
        'Start: ' +
        (start.workflowExecutionStartedEventAttributes?.workflowType?.name ?? 'Workflow'),
      type: 'workflow',
      status: 'completed',
      startTime: start.eventTime,
      rawEvents: [start],
    });
  for (const event of events) {
    const activity = type(event) === 'ACTIVITY_TASK_SCHEDULED',
      timer = type(event) === 'TIMER_STARTED';
    if (!activity && !timer) continue;
    const attrs = activity
      ? event.activityTaskScheduledEventAttributes
      : event.timerStartedEventAttributes;
    const terminal = events.find((other) => {
      if (activity && /^ACTIVITY_TASK_(COMPLETED|FAILED|TIMED_OUT|CANCELED)$/.test(type(other))) {
        const a =
          other.activityTaskCompletedEventAttributes ??
          other.activityTaskFailedEventAttributes ??
          other.activityTaskTimedOutEventAttributes ??
          other.activityTaskCanceledEventAttributes;
        return String(a?.scheduledEventId) === String(event.eventId);
      }
      return (
        timer &&
        /^TIMER_(FIRED|CANCELED)$/.test(type(other)) &&
        String(
          (other.timerFiredEventAttributes ?? other.timerCanceledEventAttributes)?.startedEventId,
        ) === String(event.eventId)
      );
    });
    const started = activity
      ? events.find(
          (other) =>
            type(other) === 'ACTIVITY_TASK_STARTED' &&
            String(other.activityTaskStartedEventAttributes?.scheduledEventId) ===
              String(event.eventId),
        )
      : undefined;
    const pending = activity
      ? pendingActivities.find((item) => String(item.activityId) === String(attrs?.activityId))
      : undefined;
    const running =
      timer || started || String(pending?.state).endsWith('STARTED') || pending?.state === 2;
    const node = make((activity ? 'activity-' : 'timer-') + event.eventId, {
      id: String(attrs?.activityId ?? attrs?.timerId ?? event.eventId),
      label: activity
        ? (attrs?.activityType?.name ?? 'Activity')
        : `Wait ${attrs?.startToFireTimeout ?? ''}`,
      type: activity ? 'activity' : 'timer',
      status: terminal ? status(terminal) : running ? 'running' : 'scheduled',
      startTime: started?.eventTime ?? event.eventTime,
      duration: terminal
        ? Math.max(
            0,
            Date.parse(terminal.eventTime) - Date.parse(started?.eventTime ?? event.eventTime),
          )
        : undefined,
      queueName: attrs?.taskQueue?.name,
      attempt: pending?.attempt ?? started?.activityTaskStartedEventAttributes?.attempt,
      lastFailure: pending?.lastFailure,
      rawEvents: [event, started, terminal].filter(Boolean) as HistoryEvent[],
    });
    operations.push({
      node,
      command: String(attrs?.workflowTaskCompletedEventId ?? ''),
      end: terminal,
    });
  }
  const batches = new Map<string, typeof operations>();
  for (const operation of operations) {
    const batch = batches.get(operation.command) ?? [];
    batch.push(operation);
    batches.set(operation.command, batch);
  }
  const link = (source: string, target: string) => {
    if (source === target) return;
    edges.push({
      id: `e-${source}-${target}`,
      source,
      target,
      type: 'smoothstep',
      animated: nodes.find((node) => node.id === target)?.data.status === 'running',
      style: { stroke: '#94a3b8', strokeWidth: 2 },
    });
  };
  for (const [command, batch] of batches) {
    const commandIndex = index.get(command) ?? -1;
    const completedTask = events[commandIndex];
    const startedIndex =
      index.get(String(completedTask?.workflowTaskCompletedEventAttributes?.startedEventId)) ??
      commandIndex;
    let previousStarted = -1;
    for (let i = startedIndex - 1; i >= 0; i--)
      if (type(events[i]) === 'WORKFLOW_TASK_STARTED') {
        previousStarted = i;
        break;
      }
    const causes = operations.filter(
      (operation) =>
        operation.end &&
        (index.get(String(operation.end.eventId)) ?? -1) > previousStarted &&
        (index.get(String(operation.end.eventId)) ?? Infinity) < startedIndex,
    );
    for (const operation of batch) {
      if (causes.length) for (const cause of causes) link(cause.node.id, operation.node.id);
      else if (start) link('workflow', operation.node.id);
    }
  }
  if (close) {
    const closeStatus = type(close).endsWith('CONTINUED_AS_NEW') ? 'completed' : status(close);
    make('workflow-end', {
      id: 'end',
      label: type(close).replace('WORKFLOW_EXECUTION_', '').replaceAll('_', ' '),
      type: 'workflow',
      status: closeStatus,
      startTime: close.eventTime,
      rawEvents: [close],
    });
    const sinks = operations.filter(
      (operation) => !edges.some((edge) => edge.source === operation.node.id),
    );
    for (const operation of sinks) link(operation.node.id, 'workflow-end');
    if (!operations.length && start) link('workflow', 'workflow-end');
  }
  const graph = new dagre.graphlib.Graph();
  graph.setGraph({ rankdir: 'TB', ranksep: 65, nodesep: 35 });
  graph.setDefaultEdgeLabel(() => ({}));
  for (const node of nodes) graph.setNode(node.id, { width: 340, height: 130 });
  for (const edge of edges) graph.setEdge(edge.source, edge.target);
  dagre.layout(graph);
  return {
    nodes: nodes.map((node) => ({
      ...node,
      position: { x: graph.node(node.id).x - 170, y: graph.node(node.id).y - 65 },
    })),
    edges,
  };
}
