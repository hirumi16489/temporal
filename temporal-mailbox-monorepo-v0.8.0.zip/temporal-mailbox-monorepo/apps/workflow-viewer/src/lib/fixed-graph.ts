import { WorkflowDiagrams } from '../registry';
import type { WorkflowDiagram } from '@automation/temporal-platform/visualization';
import type { Node, Edge } from 'reactflow';
import type { LogicalNodeData } from '../components/workflow/WorkflowNode';
import type { WorkflowSnapshot, HistoryEvent } from '../types/schema';
import { decodePayload } from './payloads';
import { workflowStatus } from './live';

const type = (event: HistoryEvent) => event.eventType.replace(/^EVENT_TYPE_/, '');
const attrs = (event?: HistoryEvent): any =>
  event ? (Object.entries(event).find(([key]) => key.endsWith('EventAttributes'))?.[1] ?? {}) : {};
export function executionType(snapshot?: WorkflowSnapshot): string {
  return (
    snapshot?.description.workflowExecutionInfo?.type?.name ??
    snapshot?.description.executionInfo?.type?.name ??
    snapshot?.events.find((event) => type(event) === 'WORKFLOW_EXECUTION_STARTED')
      ?.workflowExecutionStartedEventAttributes?.workflowType?.name ??
    ''
  );
}
interface Operation {
  scheduled: HistoryEvent;
  started?: HistoryEvent;
  end?: HistoryEvent;
  pending?: any;
  name: string;
  id: string;
}
export function buildFixedGraph(
  snapshot?: WorkflowSnapshot,
):
  | { nodes: Node<LogicalNodeData>[]; edges: Edge[]; diagram: WorkflowDiagram; unmapped: string[] }
  | undefined {
  const name = executionType(snapshot);
  const diagram = Object.hasOwn(WorkflowDiagrams, name)
    ? (WorkflowDiagrams as Record<string, WorkflowDiagram>)[name]
    : undefined;
  if (!diagram) return undefined;
  const events = snapshot?.events ?? [];
  // Reset inserts a WorkflowTaskFailed marker at the fork boundary. Do not infer
  // reuse from run IDs/timestamps: ordinary retries and continue-as-new also create runs.
  const reset = events
    .filter(
      (event) =>
        type(event) === 'WORKFLOW_TASK_FAILED' &&
        ['WORKFLOW_TASK_FAILED_CAUSE_RESET_WORKFLOW', 'RESET_WORKFLOW', '20'].includes(
          String(attrs(event).cause),
        ),
    )
    .at(-1);
  const resetBoundary = reset ? BigInt(reset.eventId) : undefined;
  const started = events.find((event) => type(event) === 'WORKFLOW_EXECUTION_STARTED');
  const closed = events.find((event) =>
    /^WORKFLOW_EXECUTION_(COMPLETED|FAILED|CANCELED|TERMINATED|TIMED_OUT|CONTINUED_AS_NEW)$/.test(
      type(event),
    ),
  );
  const runStatus = workflowStatus(snapshot);
  const finished = !!closed || !['RUNNING', 'UNKNOWN'].includes(runStatus);
  const canceled = ['CANCELED', 'TERMINATED'].includes(runStatus);
  const activityEvents = new Map<string, { started?: HistoryEvent; end?: HistoryEvent }>();
  for (const event of events) {
    if (!/^ACTIVITY_TASK_(STARTED|COMPLETED|FAILED|TIMED_OUT|CANCELED)$/.test(type(event)))
      continue;
    const ref = String(attrs(event).scheduledEventId);
    const entry = activityEvents.get(ref) ?? {};
    if (type(event).endsWith('STARTED')) entry.started = event;
    else entry.end = event;
    activityEvents.set(ref, entry);
  }
  const operations: Operation[] = events
    .filter((event) => type(event) === 'ACTIVITY_TASK_SCHEDULED')
    .map((scheduled) => {
      const data = attrs(scheduled),
        id = String(data.activityId);
      return {
        scheduled,
        ...activityEvents.get(String(scheduled.eventId)),
        id,
        name: data.activityType?.name ?? '',
        pending: snapshot?.description.pendingActivities?.find(
          (pending) => String(pending.activityId) === id,
        ),
      };
    });
  const mapped = new Set(diagram.steps.flatMap((step) => [...step.activityTypes]));
  const unmapped = [
    ...new Set(
      operations
        .filter((operation) => !mapped.has(operation.name as any))
        .map((operation) => operation.name),
    ),
  ];
  const lastResult = (operation?: Operation) =>
    attrs(operation?.end).result?.payloads?.map(decodePayload)?.[0];
  function activityStatus(operation?: Operation): LogicalNodeData['status'] {
    if (!operation) return finished ? 'not-run' : 'idle';
    if (operation.end) {
      if (type(operation.end).endsWith('COMPLETED')) return 'completed';
      return type(operation.end).endsWith('CANCELED') ? 'canceled' : 'failed';
    }
    if (finished) return canceled ? 'canceled' : 'failed';
    const state = String(operation.pending?.state ?? '');
    const running = !!operation.started || state.endsWith('STARTED') || state === '2';
    if (operation.pending?.lastFailure && !running) return 'retrying';
    return running ? 'running' : 'scheduled';
  }
  const nodes = diagram.steps.map((step): Node<LogicalNodeData> => {
    const matches = operations.filter((operation) =>
      step.activityTypes.some((name) => name === operation.name),
    );
    const latest = matches.at(-1);
    let status: LogicalNodeData['status'] = activityStatus(latest);
    let rawEvents = matches.flatMap((operation) =>
      [operation.scheduled, operation.started, operation.end].filter(Boolean),
    ) as HistoryEvent[];
    if (step.kind === 'start') {
      status = started ? 'completed' : 'idle';
      rawEvents = started ? [started] : [];
    }
    if (step.kind === 'end') {
      status = finished
        ? runStatus === 'COMPLETED'
          ? 'completed'
          : canceled
            ? 'canceled'
            : 'failed'
        : 'idle';
      rawEvents = closed ? [closed] : [];
    }
    if (step.kind === 'wait' && latest) {
      const firstId = BigInt(matches[0].scheduled.eventId);
      // Availability checks and their durable pauses form one business step.
      const downstream = operations.find(
        (operation) =>
          BigInt(operation.scheduled.eventId) > firstId &&
          !step.activityTypes.some((name) => name === operation.name),
      );
      const endId = downstream ? BigInt(downstream.scheduled.eventId) : undefined;
      const timers = events.filter(
        (event) =>
          /^TIMER_(STARTED|FIRED|CANCELED)$/.test(type(event)) &&
          BigInt(event.eventId) > firstId &&
          (endId === undefined || BigInt(event.eventId) < endId),
      );
      rawEvents.push(...timers);
      if (
        status === 'completed' &&
        (step.completionField ? lastResult(latest)?.[step.completionField] : lastResult(latest)) !==
          true
      )
        status = finished ? (canceled ? 'canceled' : 'failed') : 'waiting';
      if (status === 'running' || status === 'scheduled') status = 'waiting';
      if (
        (step.completionField ? lastResult(latest)?.[step.completionField] : lastResult(latest)) ===
          true ||
        downstream
      )
        status = 'completed';
      if (
        (status === 'failed' || status === 'canceled') &&
        closed &&
        !latest.end?.activityTaskFailedEventAttributes
      )
        rawEvents.push(closed);
    }
    const attempt = latest?.pending?.attempt ?? attrs(latest?.started).attempt;
    rawEvents.sort((a, b) =>
      BigInt(a.eventId) < BigInt(b.eventId) ? -1 : BigInt(a.eventId) > BigInt(b.eventId) ? 1 : 0,
    );
    return {
      id: step.id,
      type: 'workflowNode',
      position: { ...step.position },
      data: {
        id: step.id,
        label: step.label,
        type: step.kind === 'wait' ? 'timer' : step.kind === 'activity' ? 'activity' : 'workflow',
        status,
        reused:
          status === 'completed' &&
          resetBoundary !== undefined &&
          matches.length > 0 &&
          matches.every(
            (operation) =>
              operation.end &&
              type(operation.end) === 'ACTIVITY_TASK_COMPLETED' &&
              BigInt(operation.end.eventId) < resetBoundary,
          )
            ? { sourceRunId: attrs(reset).baseRunId || undefined, resetEventId: reset!.eventId }
            : undefined,
        activityName: step.activityTypes.join(', '),
        attempt,
        lastFailure: latest?.pending?.lastFailure,
        checkCount: step.kind === 'wait' ? matches.length : undefined,
        queueName: attrs(latest?.scheduled).taskQueue?.name,
        startTime: rawEvents[0]?.eventTime ?? '',
        rawEvents,
      },
    };
  });
  const edges = diagram.edges.map(([source, target]): Edge => {
    const status = nodes.find((node) => node.id === target)!.data.status;
    const color =
      status === 'completed'
        ? '#16a34a'
        : status === 'failed'
          ? '#dc2626'
          : status === 'retrying'
            ? '#ea580c'
            : status === 'running' || status === 'waiting'
              ? '#2563eb'
              : '#cbd5e1';
    return {
      id: `e-${source}-${target}`,
      source,
      target,
      type: 'smoothstep',
      animated: ['running', 'waiting', 'retrying'].includes(status),
      style: { stroke: color, strokeWidth: 2.5 },
    };
  });
  return { nodes, edges, diagram, unmapped };
}
