function text(base64: string) {
  return new TextDecoder('utf-8', { fatal: true }).decode(
    Uint8Array.from(atob(base64), (c) => c.charCodeAt(0)),
  );
}
export function decodePayload(payload: any): unknown {
  let encoding = payload?.metadata?.encoding ?? '';
  try {
    encoding = text(encoding);
  } catch {
    /* Already readable encoding or custom metadata. */
  }
  try {
    if (encoding === 'json/plain') return JSON.parse(text(payload.data));
    if (encoding === 'binary/null') return null;
  } catch {
    /* Keep malformed/unsupported payloads inspectable. */
  }
  return {
    encoding: encoding || 'unknown',
    base64: payload?.data ?? '',
    note: 'Custom, binary or encrypted payload; original data retained.',
  };
}
export function inspectPayloads(events: any[]) {
  const attributes = events.flatMap((event) =>
    Object.entries(event)
      .filter(([key]) => key.endsWith('EventAttributes'))
      .map(([, value]) => value),
  ) as any[];
  const latest = [...attributes].reverse();
  const input = latest.find((item) => item?.input)?.input;
  const result = latest.find((item) => item?.result)?.result;
  const failure = latest.find((item) => item?.failure)?.failure;
  return {
    input: input?.payloads?.map(decodePayload),
    output: result?.payloads?.map(decodePayload),
    failure,
  };
}
