import type { WorkflowSnapshot } from '../types/schema';
export function workflowStatus(snapshot?: WorkflowSnapshot): string {
  // History can close between Describe and History HTTP requests. Its terminal event wins.
  const terminal = snapshot?.events.find((event) =>
    /^WORKFLOW_EXECUTION_(COMPLETED|FAILED|CANCELED|TERMINATED|TIMED_OUT|CONTINUED_AS_NEW)$/.test(
      event.eventType.replace(/^EVENT_TYPE_/, ''),
    ),
  );
  if (terminal)
    return terminal.eventType.replace(/^EVENT_TYPE_/, '').replace('WORKFLOW_EXECUTION_', '');
  const status =
    snapshot?.description.workflowExecutionInfo?.status ??
    snapshot?.description.executionInfo?.status;
  if (typeof status === 'number')
    return (
      [
        'UNKNOWN',
        'RUNNING',
        'COMPLETED',
        'FAILED',
        'CANCELED',
        'TERMINATED',
        'CONTINUED_AS_NEW',
        'TIMED_OUT',
      ][status] ?? 'UNKNOWN'
    );
  return String(status ?? 'UNKNOWN')
    .replace('WORKFLOW_EXECUTION_STATUS_', '')
    .toUpperCase();
}
export function liveInterval(
  snapshot?: WorkflowSnapshot,
  enabled = true,
  interval = 2000,
): number | false {
  if (!enabled) return false;
  const status = workflowStatus(snapshot);
  if (status !== 'RUNNING' && status !== 'UNKNOWN') return false;
  const closed = snapshot?.events.some((event) =>
    /^WORKFLOW_EXECUTION_(COMPLETED|FAILED|CANCELED|TERMINATED|TIMED_OUT|CONTINUED_AS_NEW)$/.test(
      event.eventType.replace(/^EVENT_TYPE_/, ''),
    ),
  );
  return closed ? false : interval;
}
