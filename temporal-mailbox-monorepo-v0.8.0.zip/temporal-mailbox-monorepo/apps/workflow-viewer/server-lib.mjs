import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css',
  '.svg': 'image/svg+xml',
  '.json': 'application/json',
  '.map': 'application/json',
};
export function createViewerServer({
  endpoint = 'http://localhost:8233',
  namespace = 'default',
  assets = fileURLToPath(new URL('./dist/', import.meta.url)),
  request = fetch,
} = {}) {
  const upstream = new URL(endpoint);
  if (!['http:', 'https:'].includes(upstream.protocol))
    throw new Error('Temporal UI endpoint must be HTTP(S)');
  const root = resolve(assets);
  return createServer(async (req, res) => {
    const send = (code, body) => {
      res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify(body));
    };
    const abort = new AbortController();
    res.once('close', () => abort.abort());
    async function upstreamJson(path, params = {}) {
      const url = new URL(upstream.href);
      url.pathname = upstream.pathname.replace(/\/$/, '') + path;
      url.search = new URLSearchParams(params).toString();
      const response = await request(url, {
        signal: AbortSignal.any([abort.signal, AbortSignal.timeout(15_000)]),
      });
      if (!response.ok) {
        const error = new Error(`Temporal API returned ${response.status}`);
        error.status = response.status;
        throw error;
      }
      return response.json();
    }
    try {
      if (req.method !== 'GET' && req.method !== 'HEAD')
        return send(405, { error: 'Read-only viewer' });
      const url = new URL(req.url, 'http://viewer');
      if (url.pathname === '/health') return send(200, { status: 'ok' });
      if (url.pathname === '/api/config') return send(200, { namespace, pollIntervalMs: 2000 });
      if (url.pathname.startsWith('/api/')) {
        const ns = url.searchParams.get('namespace') || namespace;
        const nsPath = `/api/v1/namespaces/${encodeURIComponent(ns)}/workflows`;
        if (url.pathname === '/api/search') {
          const data = await upstreamJson(nsPath, {
            query: url.searchParams.get('query') || '',
            nextPageToken: url.searchParams.get('nextPageToken') || '',
            pageSize: '50',
          });
          return send(200, data);
        }
        if (url.pathname === '/api/workflow') {
          const id = url.searchParams.get('id'),
            runId = url.searchParams.get('runId');
          if (!id || !runId) return send(400, { error: 'id and runId are required' });
          const path = `${nsPath}/${encodeURIComponent(id)}`;
          // Describe first. If closed, the following history fetch includes its terminal event.
          const description = await upstreamJson(path, { 'execution.runId': runId });
          const events = [];
          let nextPageToken = '';
          let pages = 0;
          do {
            if (++pages > 1000)
              return send(413, {
                error: 'History exceeds viewer page limit; inspect it in Temporal UI',
              });
            const data = await upstreamJson(`${path}/history`, {
              'execution.runId': runId,
              nextPageToken,
              maximumPageSize: '1000',
            });
            events.push(...(data.history?.events ?? []));
            nextPageToken = data.nextPageToken || '';
          } while (nextPageToken);
          return send(200, { events, description });
        }
        return send(404, { error: 'Unknown API route' });
      }
      let path = resolve(root, '.' + decodeURIComponent(url.pathname));
      if (path !== root && !path.startsWith(root + sep))
        return send(403, { error: 'Forbidden path' });
      if (path === root || !extname(path)) path = resolve(root, 'index.html');
      let content;
      try {
        content = await readFile(path);
      } catch {
        return send(404, { error: 'Asset not found. Run npm run build.' });
      }
      res.writeHead(200, {
        'Content-Type': mime[extname(path)] || 'application/octet-stream',
        'Cache-Control': path.endsWith('index.html') ? 'no-cache' : 'public, max-age=3600',
        'X-Content-Type-Options': 'nosniff',
      });
      res.end(req.method === 'HEAD' ? undefined : content);
    } catch (error) {
      if (!res.destroyed) send(error.status === 404 ? 404 : 502, { error: error.message });
    }
  });
}
