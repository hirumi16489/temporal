import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';
export default defineConfig({
  plugins: [react()],
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
  build: {
    sourcemap: true,
    target: 'es2022',
    commonjsOptions: { include: [/node_modules/, /packages[\\/].*[\\/]dist/] },
  },
});
