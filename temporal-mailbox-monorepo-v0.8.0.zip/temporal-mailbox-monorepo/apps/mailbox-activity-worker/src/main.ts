import { runWorkerHost } from '@automation/temporal-platform/worker-runtime';
import { createEnterpriseMailboxPorts } from '@automation/mailbox/adapters/outbound';
import { createMailboxServices } from '@automation/mailbox/application';
import { createMailboxActivityHandlers } from '@automation/mailbox/adapters/inbound/temporal';
import { createMailboxActivityWorker } from './bootstrap';
async function main() {
  // Resolve dependencies before connecting/polling; missing real adapters fail immediately.
  const activities = createMailboxActivityHandlers(
    createMailboxServices(createEnterpriseMailboxPorts()),
  );
  await runWorkerHost((connection, namespace) =>
    createMailboxActivityWorker(connection, namespace, activities, process.argv[2] ?? 'standard'),
  );
}
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
