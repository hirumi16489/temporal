import { Worker, type NativeConnection } from '@temporalio/worker';
import type { MailboxActivities } from '@automation/mailbox/contracts';
import { loadWorkerConfig } from '@automation/mailbox/execution/worker';
export async function createMailboxActivityWorker(
  connection: NativeConnection,
  namespace: string,
  activities: MailboxActivities,
  profile: string,
) {
  const config = loadWorkerConfig(profile);
  const worker = await Worker.create({
    connection,
    namespace,
    taskQueue: config.taskQueue,
    activities,
    maxConcurrentActivityTaskExecutions: config.concurrency,
    maxTaskQueueActivitiesPerSecond: config.rate,
  });
  console.log('Activity worker ready', config);
  return worker;
}
