import { Worker } from '@temporalio/worker';
import { join } from 'node:path';
import { WorkflowQueue } from '@automation/mailbox/execution';
import { runWorkerHost } from '@automation/temporal-platform/worker-runtime';
runWorkerHost(async (connection, namespace) => {
  const worker = await Worker.create({
    connection,
    namespace,
    taskQueue: WorkflowQueue,
    workflowBundle: { codePath: join(__dirname, 'workflow-bundle.js') },
  });
  console.log('Workflow worker ready:', WorkflowQueue);
  return worker;
}).catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
