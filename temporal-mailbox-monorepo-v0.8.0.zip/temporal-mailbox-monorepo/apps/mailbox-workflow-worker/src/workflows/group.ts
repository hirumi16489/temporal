import type { GroupMailboxRequest, ProvisioningResult } from '@automation/mailbox/contracts';
import { PoolProfiles, mailboxActivities, trackStatus, assertKind, waitForMailbox } from './shared';
const activities = mailboxActivities(PoolProfiles.STANDARD);
export async function provisionGroupMailboxWorkflow(
  input: GroupMailboxRequest,
): Promise<ProvisioningResult> {
  const status = trackStatus();
  try {
    assertKind(input, 'GROUP');
    const context = await activities.prepareMailboxProvisioning(input);
    status.phase = 'PROVISIONING';
    await activities.provisionMailbox(context);
    status.phase = 'WAITING_FOR_AVAILABILITY';
    await waitForMailbox({ identity: context.identity, requestId: context.requestId }, activities);
    status.phase = 'CONFIGURING';
    // Business dependency assumption to validate with the provider owners: both capabilities are independent.
    const results = await Promise.allSettled([
      (async () => {
        await activities.configureMailbox(context);
        status.mailboxConfigured = true;
      })(),
      (async () => {
        await activities.provisionMailboxDistributionGroup(context);
        status.groupProvisioned = true;
      })(),
    ]);
    const failure = results.find((r): r is PromiseRejectedResult => r.status === 'rejected');
    if (failure) throw failure.reason;
    status.phase = 'READY';
    if (context.kind !== 'GROUP')
      throw new Error('Prepared mailbox kind does not match group workflow');
    return { identity: context.identity, status: 'READY', groupIdentity: context.group.identity };
  } catch (error) {
    status.phase = 'FAILED';
    throw error;
  }
}
