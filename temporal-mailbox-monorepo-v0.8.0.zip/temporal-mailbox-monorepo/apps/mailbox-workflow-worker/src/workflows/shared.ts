import { MailboxQueries } from '@automation/mailbox/contracts';
import {
  defineQuery,
  setHandler,
  proxyActivities,
  sleep,
  ApplicationFailure,
} from '@temporalio/workflow';
import type {
  MailboxActivities,
  ProvisioningStatus,
  ProvisioningRequest,
  MailboxKind,
} from '@automation/mailbox/contracts';
import { resolvedPools, type PoolProfile } from '@automation/mailbox/execution';
export const provisioningStatus = defineQuery<ProvisioningStatus>(MailboxQueries.STATUS);
export function trackStatus() {
  const status: ProvisioningStatus = {
    phase: 'PREPARING',
    mailboxConfigured: false,
    groupProvisioned: false,
  };
  setHandler(provisioningStatus, () => ({ ...status }));
  return status;
}
export function mailboxActivities(profile: PoolProfile) {
  return proxyActivities<MailboxActivities>({
    taskQueue: resolvedPools[profile],
    startToCloseTimeout: '15 seconds',
    scheduleToCloseTimeout: '2 minutes',
    retry: {
      initialInterval: '1 second',
      backoffCoefficient: 2,
      maximumInterval: '5 seconds',
      maximumAttempts: 4,
    },
  });
}
export function assertKind(input: ProvisioningRequest, kind: MailboxKind) {
  if (!input || input.kind !== kind)
    throw ApplicationFailure.nonRetryable('Input kind does not match workflow', 'InvalidInput');
}
export async function waitForMailbox(
  request: { identity: string; requestId: string },
  activities: Pick<MailboxActivities, 'checkMailboxReadiness'>,
) {
  for (let attempt = 0; attempt < 30; attempt++) {
    if ((await activities.checkMailboxReadiness(request)).ready) return;
    if (attempt < 29) await sleep('2 seconds');
  }
  throw ApplicationFailure.nonRetryable(
    'Mailbox availability checks exhausted',
    'AvailabilityTimeout',
  );
}

export { PoolProfiles } from '@automation/mailbox/execution';
