import type { PersonalMailboxRequest, ProvisioningResult } from '@automation/mailbox/contracts';
import { PoolProfiles, mailboxActivities, trackStatus, assertKind, waitForMailbox } from './shared';
const activities = mailboxActivities(PoolProfiles.PERSONAL);
export async function provisionPersonalMailboxWorkflow(
  input: PersonalMailboxRequest,
): Promise<ProvisioningResult> {
  const status = trackStatus();
  try {
    assertKind(input, 'PERSONAL');
    const context = await activities.prepareMailboxProvisioning(input);
    status.phase = 'PROVISIONING';
    await activities.provisionMailbox(context);
    status.phase = 'WAITING_FOR_AVAILABILITY';
    await waitForMailbox({ identity: context.identity, requestId: context.requestId }, activities);
    status.phase = 'CONFIGURING';
    await activities.configureMailbox(context);
    status.mailboxConfigured = true;
    status.phase = 'READY';
    return { identity: context.identity, status: 'READY' };
  } catch (error) {
    status.phase = 'FAILED';
    throw error;
  }
}
