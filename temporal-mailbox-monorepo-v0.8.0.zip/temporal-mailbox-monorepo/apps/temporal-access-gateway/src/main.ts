import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { Connection } from '@temporalio/client';
import { temporalConnectionSettings } from '@automation/temporal-platform/connection';
import { startAccessGateway } from './server';
async function main() {
  const settings = temporalConnectionSettings();
  if (!settings.tls && !/^(localhost|127\.0\.0\.1|\[::1\]):\d+$/.test(settings.address))
    throw new Error('A non-loopback backend must use verified TLS');
  const directory = resolve(process.env.SECURITY_DEMO_DIR ?? '.data/security');
  const backend = await Connection.connect({ address: settings.address, tls: settings.tls });
  let gateway: Awaited<ReturnType<typeof startAccessGateway>> | undefined;
  try {
    gateway = await startAccessGateway({
      address: process.env.GATEWAY_ADDRESS ?? '127.0.0.1:7443',
      backend,
      policy: JSON.parse(
        readFileSync(process.env.GATEWAY_POLICY_FILE ?? resolve(directory, 'policy.json'), 'utf8'),
      ),
      caFile: process.env.GATEWAY_CLIENT_CA_FILE ?? resolve(directory, 'ca.crt'),
      certificateFile: process.env.GATEWAY_CERT_FILE ?? resolve(directory, 'server.crt'),
      privateKeyFile: process.env.GATEWAY_KEY_FILE ?? resolve(directory, 'server.key'),
      audit: (event) => console.log(JSON.stringify({ at: new Date().toISOString(), ...event })),
    });
    console.log(
      'mTLS Temporal access gateway ready on port ' +
        gateway.port +
        '; backend ' +
        settings.address,
    );
  } catch (error) {
    await backend.close();
    throw error;
  }
  let closing = false;
  for (const signal of ['SIGINT', 'SIGTERM'])
    process.once(signal, async () => {
      if (closing) return;
      closing = true;
      await gateway?.close();
      await backend.close();
    });
}
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
