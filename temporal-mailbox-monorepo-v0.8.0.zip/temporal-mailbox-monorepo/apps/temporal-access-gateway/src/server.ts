import {
  Server,
  ServerCredentials,
  status,
  type ServerUnaryCall,
  type sendUnaryData,
  type ServiceDefinition,
} from '@grpc/grpc-js';
import { temporal } from '@temporalio/proto';
import { Connection } from '@temporalio/client';
import { readFileSync } from 'node:fs';
import {
  authorizeWorkflowAccess,
  principalForCertificate,
  validateAccessPolicy,
  type WorkflowAccessPolicy,
} from '@automation/temporal-platform/access';
const api = temporal.api.workflowservice.v1;
const methods = {
  GetSystemInfo: ['getSystemInfo', api.GetSystemInfoRequest, api.GetSystemInfoResponse],
  StartWorkflowExecution: [
    'startWorkflowExecution',
    api.StartWorkflowExecutionRequest,
    api.StartWorkflowExecutionResponse,
  ],
  GetWorkflowExecutionHistory: [
    'getWorkflowExecutionHistory',
    api.GetWorkflowExecutionHistoryRequest,
    api.GetWorkflowExecutionHistoryResponse,
  ],
  DescribeWorkflowExecution: [
    'describeWorkflowExecution',
    api.DescribeWorkflowExecutionRequest,
    api.DescribeWorkflowExecutionResponse,
  ],
  QueryWorkflow: ['queryWorkflow', api.QueryWorkflowRequest, api.QueryWorkflowResponse],
} as const;
export interface AccessAudit {
  principal: string;
  method: string;
  decision: 'ALLOW' | 'DENY';
  namespace?: string;
  workflowType?: string;
  workflowId?: string;
}
export interface GatewayOptions {
  address: string;
  backend: Connection;
  policy: WorkflowAccessPolicy;
  caFile: string;
  certificateFile: string;
  privateKeyFile: string;
  audit?: (event: AccessAudit) => void;
}
export async function startAccessGateway(options: GatewayOptions) {
  const policy = validateAccessPolicy(options.policy);
  const server = new Server({
    'grpc.max_receive_message_length': 4 * 1024 * 1024,
    'grpc.max_send_message_length': 4 * 1024 * 1024,
  });
  const definition: Record<string, ServiceDefinition[string]> = {},
    handlers: Record<string, any> = {};
  for (const [method, [backendMethod, requestType, responseType]] of Object.entries(methods)) {
    definition[method] = {
      path: '/temporal.api.workflowservice.v1.WorkflowService/' + method,
      requestStream: false,
      responseStream: false,
      requestSerialize: (value: any) => Buffer.from(requestType.encode(value).finish()),
      requestDeserialize: (value: Buffer) => requestType.decode(value),
      responseSerialize: (value: any) => Buffer.from(responseType.encode(value).finish()),
      responseDeserialize: (value: Buffer) => responseType.decode(value),
    };
    handlers[method] = async (call: ServerUnaryCall<any, any>, callback: sendUnaryData<any>) => {
      const principal = principalForCertificate(
        policy,
        call.getAuthContext().sslPeerCertificate?.fingerprint256,
      );
      const reject = (code: number, message: string) =>
        callback(Object.assign(new Error(message), { code, details: message }));
      if (!principal) {
        options.audit?.({ principal: 'unrecognized-certificate', method, decision: 'DENY' });
        reject(status.UNAUTHENTICATED, 'Client certificate is not registered in the access policy');
        return;
      }
      const request = call.request;
      const target = {
        operation: method === 'StartWorkflowExecution' ? ('start' as const) : ('read' as const),
        namespace: request.namespace ?? '',
        workflowId: request.workflowId ?? request.execution?.workflowId ?? '',
        workflowType: request.workflowType?.name,
        taskQueue: request.taskQueue?.name,
      };
      const allowed =
        method === 'GetSystemInfo' || authorizeWorkflowAccess(policy, principal, target);
      options.audit?.({
        principal: principal.id,
        method,
        decision: allowed ? 'ALLOW' : 'DENY',
        namespace: target.namespace,
        workflowId: target.workflowId,
        workflowType: target.workflowType,
      });
      if (!allowed) {
        reject(status.PERMISSION_DENIED, 'Client is not authorized for this workflow operation');
        return;
      }
      const abort = new AbortController();
      call.once('cancelled', () => abort.abort());
      const deadline = Math.min(Number(call.getDeadline()), Date.now() + 30_000);
      try {
        const result = await options.backend.withDeadline(deadline, () =>
          options.backend.withAbortSignal(abort.signal, () =>
            (options.backend.workflowService[backendMethod] as (request: any) => Promise<any>)(
              request,
            ),
          ),
        );
        if (!call.cancelled) callback(null, result);
      } catch (error) {
        if (!call.cancelled) callback(error as Error);
      }
    };
  }
  server.addService(definition, handlers);
  const credentials = ServerCredentials.createSsl(
    readFileSync(options.caFile),
    [
      {
        cert_chain: readFileSync(options.certificateFile),
        private_key: readFileSync(options.privateKeyFile),
      },
    ],
    true,
  );
  const port = await new Promise<number>((resolve, reject) =>
    server.bindAsync(options.address, credentials, (error, port) =>
      error ? reject(error) : resolve(port),
    ),
  );
  return {
    port,
    close: () =>
      new Promise<void>((resolve) => {
        const timeout = setTimeout(() => {
          server.forceShutdown();
          resolve();
        }, 5000);
        timeout.unref();
        server.tryShutdown(() => {
          clearTimeout(timeout);
          resolve();
        });
      }),
  };
}
