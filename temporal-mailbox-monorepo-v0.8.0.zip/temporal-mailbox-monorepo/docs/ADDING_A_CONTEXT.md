# Adding another business context or team

1. Add one capability library at `packages/<context>` with `domain`, `application/contracts`, `application/services`, `application/ports/outbound`, `adapters/inbound` and `adapters/outbound` as ordinary folders. Add only layers actually needed. Record context/owner/production metadata in its manifest.
2. Publish deliberate public subpaths, not every internal file. Contracts describe capabilities and serializable DTOs; domain models/rules remain internal where possible. Do not import another context's services/adapters directly.
3. Add workflow and activity hosts under `apps` when independent deployment, ownership, permissions or scaling warrants them. Hosts are small composition roots; an activity host can register multiple related handlers. Multiple queues can reuse its artifact with different profiles.
4. Define the context's routing constants and register its definitions/lock/generated file under `config/queue-catalog.json` with a distinct namespace. Run `pools:prepare` and commit identities. Declare capacity/consumers before submitting work.
5. Add build references and explicit manifest dependencies. Extend the folder-aware architecture policy for the new context's internal layers. Assign actual code-review team ownership in your repository; logical owner labels are not access control.
6. Add fixtures/test outbound adapters under test support. If a genuinely independent team toolbox emerges, give it its own workspace; otherwise use ordinary folders. Production cannot import test support.
7. If required, publish diagram metadata and compose it into the viewer registry. Update topology tests with orchestration changes. Keep presentation independent of service implementations.
8. Add the desired hosts to local composition, release staging roles and deployment automation explicitly. The current local supervisor/staging role list owns mailbox processes; platform libraries should not accumulate business-specific switches.

Adding a package is a reuse/build ownership decision; adding a host is a deployment decision; adding a folder is code organization. They are not interchangeable. Start with an owned context and meaningful hosts, rather than one workspace per architectural layer or per activity.
