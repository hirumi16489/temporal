# v0.6.2 → v0.7.0

This release changes source/package organization and tooling. Activity wire names, workflow types, DTO serialization and committed queue identities remain unchanged. No new workflow queue is introduced. Replay/versioning review still applies to future orchestration changes.

| Previous                      | New                                                                   |
| ----------------------------- | --------------------------------------------------------------------- |
| Eight mailbox layer packages  | One `packages/mailbox` library with ordinary internal folders         |
| Separate contracts package    | `mailbox/src/application/contracts`, exported through `/contracts`    |
| `temporal-activities` package | `mailbox/src/adapters/inbound/temporal`                               |
| Adapters package              | `mailbox/src/adapters/outbound`                                       |
| Workflow library              | Definitions hosted under `apps/mailbox-workflow-worker/src/workflows` |
| Three platform packages       | One `packages/temporal-platform` library with public subpaths         |
| Four test-support packages    | One `test/support` workspace with one src/dist pair                   |
| Separate CLI application      | Request/status clients under `test/support/src/client`                |
| Nineteen workspaces           | Six workspaces                                                        |

Imports change to `@automation/mailbox/...`, `@automation/temporal-platform/...` and `@test/mailbox-support/...`. Within a library, imports are ordinary relative modules. The activity-handler factory is named `createMailboxActivityHandlers`; the inbound interface is `MailboxActivities`. These TypeScript names are not Temporal activity wire names.

Root dev/demo commands remain supported. Old compiled output directories are removed from the archive. Extract into a new checkout/directory, run `npm ci`, then build; do not overlay this archive over an old node_modules/dist tree. `.data` is not packaged: retain your local Temporal DB and test state if you want existing executions. Queue locks/config retain their identities.

The v0.6 transition from older create-prefixed workflow names remains documented in MIGRATION_v0.6.md. This release does not undo that earlier wire migration.
