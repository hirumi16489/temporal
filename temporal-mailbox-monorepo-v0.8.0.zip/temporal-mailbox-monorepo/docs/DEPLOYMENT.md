# Deployment and release boundaries

## Applications

| Deployable      | Entry point                                           | Runtime role                                                  |
| --------------- | ----------------------------------------------------- | ------------------------------------------------------------- |
| Workflow worker | `apps/mailbox-workflow-worker/dist/main.js`           | Load the bundled workflow definitions and poll workflow tasks |
| Activity worker | `apps/mailbox-activity-worker/dist/main.js <profile>` | Compose adapters/services/handlers and poll one selected pool |
| Viewer          | `apps/workflow-viewer/server.mjs`                     | Serve built browser assets and a read-only Temporal UI proxy  |

Libraries are imported code, not services. Separate servers do not require different implementations: personal and standard activity deployments run the same artifact with different profiles. Test clients/simulator are not production applications in this repository.

## Build and stage a release

From a source checkout with dependencies installed:

```sh
npm run build:production
npm run release:stage -- workflow-worker /absolute/new/workflow-release
npm run release:stage -- activity-worker /absolute/new/activity-release
npm run release:stage -- viewer /absolute/new/viewer-release
```

Staging requires an unused directory outside the source tree. It never replaces a release. Each staged directory records selected workspaces, install command and entry point in `release.json`/`RELEASE.md`.

A worker release contains its app's compiled code, compiled shared-library dependency closure, config, root lockfile and all workspace manifests so npm can interpret the original lock. Nonselected/test workspace directories contain manifests only, with no test implementation or build output. Install selected production workspace dependencies on the target host using the generated `npm ci --omit=dev --workspace ...` command. The target needs a supported Node/Temporal SDK platform and access to your dependency registry. Native Temporal SDK components are installed for that host; do not copy another OS's node_modules.

The workflow release currently includes the whole mailbox library as a compiled dependency, but its sandbox bundle only imports orchestration/contracts/routing. This is a source/build grouping choice, not a shared process. More granular artifacts are possible later if footprint or release ownership justifies them.

The viewer stage is standalone: built assets, two server modules and upstream attribution/license. It needs Node.js and no npm install. Bind it through your approved reverse proxy and authentication boundary; the supplied server is read-only but displays execution payloads.

## Configure and run

For worker hosts, configure `TEMPORAL_ADDRESS`, `TEMPORAL_NAMESPACE` and the approved authentication/TLS mechanism. The shared connection helper now loads verified TLS/mTLS configuration from process-specific certificate/CA file settings. Native server authorization and PKI lifecycle still require deployment integration. Keep runtime config, secret delivery, telemetry and process supervisor policy outside workflow code.

```sh
node apps/mailbox-workflow-worker/dist/main.js
node apps/mailbox-activity-worker/dist/main.js personal
node apps/mailbox-activity-worker/dist/main.js standard
```

The enterprise activity host currently fails with `ExternalAdapterNotConfigured`. Implement approved outbound ports in `packages/mailbox/src/adapters/outbound` and compose them before deploying real activity consumers. No environment flag activates mock adapters in production.

For local demonstrations, `npm run dev` uses `test/support/dist/runtime/activity-worker.js` to bind test outbound adapters to the same production handlers/services. The simulator runs from `test/support/dist/simulator/main.js`. `npm start` disables watching. Native Temporal development data persists under `.data`; this development server is not a production deployment.

## Capacity and deployment isolation

`config/mailbox/capacity.json` provides concurrency/rate settings per profile. Personal defaults to four activity slots per process; standard defaults to two. Three personal processes provide up to twelve personal slots. The local supervisor reads the JSON replica count; production replicas belong to your scheduler/supervisor. Restart workers to apply startup settings. Queue-wide rate limits are not multiplied by replicas and should be consistent across consumers.

Personal and standard queues reserve separate worker capacity, while sharing implementations. They do not isolate shared provider quotas or host CPU/memory automatically. Use separate host resources and provider budgets when those matter. Queue declarations supply routing names, not compute.

Declare new pool/isolation constants in mailbox execution definitions, add a capacity profile, run `pools:prepare`, review/commit the generated identities, deploy consumers, then route executions. Random suffixes are persisted once, never regenerated per worker replica. Another context registers its own queue-catalog entry.

## Independent changes and compatibility

| Change                                                      | Deploy                                                                                 |
| ----------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| Add a workflow using already-supported activities/contracts | Workflow worker; existing activity fleets can remain running                           |
| Fix adapter/service behavior with compatible contracts      | Activity worker; workflow host need not change                                         |
| Increase personal capacity                                  | More personal consumers / capacity config                                              |
| Introduce a new activity or incompatible DTO                | Compatible consumers first, then workflow producers; version names/contracts as needed |
| Change orchestration for running workflows                  | Workflow replay/versioning plan, not a blind binary replacement                        |

Retain old consumers while histories still target their queues. Preserve committed queue identities. Workflow versioning/worker version routing, rollback, graceful shutdown deadlines and production artifact publication must match your Temporal and hosting policies. The provided package boundaries make independent releases possible; they do not remove runtime compatibility obligations.

## Optional mTLS access gateway

Stage `access-gateway` with the same `release:stage` command. Mount its TLS key/certificate, client CA and validated policy; generated local PKI is not staged. Its backend uses common native Temporal TLS settings and requires TLS for non-loopback upstreams. Worker releases can also load verified TLS/mTLS through the common connection helper. See MTLS_DEMO.md for endpoint/API restrictions and the required network boundary; the plain native development server has not acquired native authorization by running this gateway.
