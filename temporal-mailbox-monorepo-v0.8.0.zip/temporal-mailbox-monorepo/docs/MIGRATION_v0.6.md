# v0.5 → v0.6 migration

This is a source layout and wire-contract migration, not an in-place replay-compatible refactor.

| Old                                                        | New                                                         |
| ---------------------------------------------------------- | ----------------------------------------------------------- |
| Flat mailbox packages and business code inside worker apps | `packages/mailbox/*` layers and thin `apps/mailbox-*` hosts |
| `createPersonalMailboxWorkflow`                            | `provisionPersonalMailboxWorkflow`                          |
| `createRoomMailboxWorkflow`                                | `provisionRoomMailboxWorkflow`                              |
| `createGroupMailboxWorkflow`                               | `provisionGroupMailboxWorkflow`                             |
| `prepareProvisioning` / `checkMailboxAvailability`         | `prepareMailboxProvisioning` / `checkMailboxReadiness`      |
| `provisionRelatedGroup`                                    | `provisionMailboxDistributionGroup`                         |
| Boolean readiness result                                   | `{identity, ready}`                                         |
| Demo fields in request DTO                                 | Separate test-scenario controls                             |
| Default mock-backed activity host                          | Enterprise host fails closed; separate test runtime         |
| Previous workflow queue                                    | `mailbox.provisioning.workflows.v2`                         |

Activity contracts are version 2. Queue locks for v2 use a separate namespace and are committed. New submissions target v2 workflow/activities; no old queue is renamed in the server. Keep old workers and source available until old runs/tasks drain. Do not register the new implementation against old workflow histories without a deliberate tested Temporal versioning/replay strategy.

Existing Temporal development data remains on disk. The viewer uses fixed descriptors for known new workflow types and falls back to history graphs for unknown types. Old records are not converted. Configuration and test-state paths changed; reset local test state when you want a clean simulated environment rather than treating it as a data migration.

If work has not yet been deployed beyond local experimentation, extract into a new directory, install and run. For a populated environment, release compatible clients/workers as separate deployments, verify queue consumers and decide the old-run retention period before removing v0.5.

## v0.6.1 patch

v0.6.1 adds test-only permission state, local repair tooling and a native reset demonstration. Production workflow source, activity names, contracts and queue identities are unchanged from v0.6.0; no new routing migration is required between those two versions.

## v0.6.2 patch

v0.6.2 adds reset provenance to the fixed viewer graph and a source-run link. It does not change workflow code, activity contracts or queue identities. Both old and new runs remain independently viewable by Run ID while retained in Temporal.
