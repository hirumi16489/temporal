# v0.7 → v0.8

v0.8 adds one optional deployable application: `apps/temporal-access-gateway`. There are now seven workspaces. Existing workflow types, activity names, mailbox DTOs and queue identities are unchanged.

The shared platform library adds `/access` for generic workflow access policy and `/connection` for verified native SDK TLS settings. Worker hosts and request clients consume the common connection configuration; defaults remain unchanged for the ordinary local stack. Configured client certificate/key pairs must be complete. Explicit TLS disablement with supplied credentials fails rather than falling back to plaintext.

The native managed development launcher refuses TLS variables it cannot serve. Use an existing native TLS Temporal endpoint with the external launcher, or leave backend TLS settings unset and use the separate gateway security scenario. `demo:security:setup`, `start:gateway` and `demo:security` are opt-in and do not change the default dev stack.

The new scenario enforces certificate identity and workflow policy in a gRPC gateway. It does not install a native Temporal Authorizer and does not make the development backend secure against trusted local processes. Read MTLS_DEMO.md before presenting it.

OpenSSL is required for certificate-generation/security integration tests. Local credentials are generated under ignored `.data/security` or a chosen directory, never shipped in source/staged releases. Install a portable OpenSSL executable or set OPENSSL_PATH if it is not on PATH. All existing build/dev/recovery commands remain available.
