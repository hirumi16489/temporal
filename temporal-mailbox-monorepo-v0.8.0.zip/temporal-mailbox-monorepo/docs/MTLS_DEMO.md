# Two certificate identities and workflow segregation

This scenario uses **real mTLS, real Temporal TypeScript SDK requests, and real Temporal executions**. Client A may start personal mailbox workflows; Client B may start room workflows. Both use one secure endpoint and the same Temporal namespace.

## Enforcement boundary

The native CLI development server does not expose listener TLS/custom-authorizer options. This no-Docker scenario therefore runs a small **gRPC access gateway** in front of it. Certificate authentication and workflow authorization are enforced by that gateway, not by a custom authorizer installed inside Temporal.

```mermaid
flowchart TD
 A["Client A certificate"] -->|"mTLS gRPC"| G["Access gateway :7443"]
 B["Client B certificate"] -->|"mTLS gRPC"| G
 G -->|"Trusted loopback"| T["Temporal :7233"]
 W["Workflow worker"] <-->|"Workflow tasks"| T
 H["Activity workers"] <-->|"Activity tasks"| T
```

Temporal, workers, simulator and the admin UIs remain on the trusted local side. **A local process can still bypass the gateway by connecting directly to the development server.** In deployment, clients must only reach the gateway; protect the Temporal backend and admin UI through network controls and separate credentials. This is not a claim that the development Temporal server has been hardened or that mTLS itself supplies workflow permissions.

The gateway accepts a restricted Temporal gRPC API surface, not every Temporal operation. Workflow start, describe, history and query are supported. Other APIs—including alternate starts, schedules, reset, termination, listing and worker polling—are unimplemented at this ingress. The normal local admin UI still supports its usual operations on the trusted backend.

## Run it

Prerequisites: Node/npm, native Temporal CLI, and OpenSSL 1.1.1+ on PATH. A portable executable can be selected with `OPENSSL_PATH`; no Docker or Go build is required. Run from the repository root.

**Terminal 1 — the existing local stack:**

```sh
npm ci
npm run dev
```

**Terminal 2 — generate local PKI, then run the secure ingress:**

```sh
npm run demo:security:setup
npm run start:gateway
```

The setup command generates a seven-day local CA, server certificate, separate client A/B certificates and negative-test certificates under `.data/security`. Server/client EKUs and server SANs are set explicitly. Private keys are generated locally, permission-restricted where supported, ignored by git, and excluded from release staging. No private key is shipped in the source archive.

Setup reuses an existing valid directory rather than silently rotating a running demo's identities. Expired/incomplete material requires choosing a new `SECURITY_DEMO_DIR` or intentionally replacing your local demo directory before setup. Never use this local CA for production.

**Terminal 3 — execute the complete matrix:**

```sh
npm run demo:security
```

Expected results:

| Attempt                                       | Result                                                |
| --------------------------------------------- | ----------------------------------------------------- |
| Client A → personal workflow                  | Allowed; completes READY                              |
| Client B → room workflow                      | Allowed; completes READY                              |
| Client A → room workflow                      | gRPC PermissionDenied                                 |
| Client B → personal workflow                  | gRPC PermissionDenied                                 |
| Client A → Client B history                   | PermissionDenied                                      |
| Wrong namespace or task queue                 | PermissionDenied                                      |
| Client A using Client B's execution-ID prefix | PermissionDenied                                      |
| Client B sending an A identity header         | PermissionDenied; identity comes from its certificate |
| Mutation API outside the exposed surface      | Unimplemented; nothing forwarded                      |
| Missing or untrusted client certificate       | TLS connection rejected                               |
| Trusted client certificate absent from policy | Unauthenticated                                       |
| Wrong server name or untrusted server CA      | Client rejects the server certificate                 |

The matrix prints PASS lines for expected rejections and exits successfully only if every check behaves correctly. An unexpected allow or failed positive execution is an error. Only the two allowed executions are created; authorization denials happen before workflow execution and therefore do not appear as failed workflow runs.

For separate interactive attempts:

```sh
npm run demo:security -- client-a personal
npm run demo:security -- client-a room
npm run demo:security -- client-b room
npm run demo:security -- client-b personal
```

The denied individual commands exit nonzero. Watch gateway JSON logs for certificate-derived principal, API, workflow type/ID and allow/deny decisions. Payloads and private keys are not logged.

Open the [graph viewer](http://localhost:7531) to inspect the allowed personal/room runs; their IDs begin with `mailbox-client-a-` and `mailbox-client-b-`. Denied starts are visible in gateway logs and command output, not in workflow history.

## Policy and ownership

The generated `.data/security/policy.json` contains pinned certificate SHA-256 fingerprints and allowed workflow types. `config/security/policy.example.json` documents the shape with deliberately invalid placeholders. A missing/invalid policy never enables a permissive fallback.

mTLS verifies that the peer possesses the private key for a CA-trusted certificate. The policy then maps that verified certificate fingerprint to a logical client and constrains workflow type, namespace, queue and execution-ID prefix. Unverified metadata such as `x-client-id` is ignored. Prefixes are nonempty and disjoint so one client cannot start, query or read another client's executions through the gateway. Each principal can have multiple pins for explicit certificate rotation.

This is authorization to invoke workflow types and access their executions. It does not replace business authorization on mailbox resources or validate every business input; those remain application responsibilities.

Policy is validated and frozen at gateway startup. To demonstrate a permission change, edit the generated policy, restart only the gateway, and repeat the client command. Changing policy does not cancel an already-accepted workflow. Protect policy and certificate files as deployment configuration.

## Configuring native Temporal TLS clients/workers

The common `@automation/temporal-platform/connection` helper is used by CLI/demo clients and worker hosts. It accepts:

| Variable                        | Meaning                                                        |
| ------------------------------- | -------------------------------------------------------------- |
| `TEMPORAL_TLS_ENABLED`          | Strict `true`/`false`; TLS file configuration also enables TLS |
| `TEMPORAL_TLS_CA_FILE`          | CA used to verify the Temporal server                          |
| `TEMPORAL_TLS_CLIENT_CERT_FILE` | Calling process's client certificate                           |
| `TEMPORAL_TLS_CLIENT_KEY_FILE`  | Matching private key                                           |
| `TEMPORAL_TLS_SERVER_NAME`      | Verified server name/SNI override                              |

Certificate/key pairs must be complete, readable and valid. Supplying TLS material while explicitly disabling TLS is rejected; no silent plaintext fallback exists. Server verification is not disabled.

For an actual native mTLS Temporal service, configure these variables per process and use `dev:external` / dedicated host entry points. The managed local development launcher refuses TLS configuration because it cannot create a matching secure listener. Do not point workers at this restricted gateway: worker APIs are intentionally not exposed there.

A native self-hosted deployment can enforce mTLS on Temporal's Frontend and implement fine-grained authorization through `ClaimMapper`/`Authorizer`. The policy semantics demonstrated here would need to be implemented and tested there, covering every applicable API path; this repository does not ship that custom server plugin. See the official [server TLS configuration](https://docs.temporal.io/references/service-configuration) and [self-hosted security extension documentation](https://github.com/temporalio/documentation/blob/main/docs/production-deployment/self-hosted-guide/security.mdx).

## Gateway configuration and deployment

| Variable                 | Default                   |
| ------------------------ | ------------------------- |
| `GATEWAY_ADDRESS`        | `127.0.0.1:7443`          |
| `SECURITY_DEMO_DIR`      | `.data/security`          |
| `GATEWAY_POLICY_FILE`    | `<directory>/policy.json` |
| `GATEWAY_CLIENT_CA_FILE` | `<directory>/ca.crt`      |
| `GATEWAY_CERT_FILE`      | `<directory>/server.crt`  |
| `GATEWAY_KEY_FILE`       | `<directory>/server.key`  |

`TEMPORAL_ADDRESS`/namespace/TLS settings configure the gateway's upstream connection. A non-loopback upstream without TLS is refused. Client credentials are not forwarded as trusted identity metadata to the backend; the gateway has its own upstream connection identity. Production CA issuance, credential rotation, policy distribution, audit retention, network isolation, quotas and admin access require deployment integration.

```sh
npm run build:production
npm run release:stage -- access-gateway /absolute/new/access-gateway-release
```

The release contains the gateway and platform library, with no mailbox business implementation, simulator or generated certificate material. Mount approved PKI/policy files at deployment. The source repository now has seven workspaces because the ingress is an additional deployable process; no new package was introduced per code layer.

## Automated evidence

`test/integration/mtls-segregation.test.ts` starts real Temporal and mailbox workers, issues temporary certificates and runs the same matrix using the actual SDK. It checks that denied starts created no executions or mailbox side effects and that audit principals came from verified certificates. It also connects using the native worker SDK's TLS transport, without claiming the gateway exposes worker APIs.

```sh
npm run build
node --import tsx --test test/integration/mtls-segregation.test.ts
```

The standard integration/CI commands include this test. The browser need not possess the client certificates; it remains a separate trusted admin presentation surface.
