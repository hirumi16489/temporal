# Browser execution viewer

The viewer is a server-hosted web application, adapted from `nguyenanhtuan21/temporal-web-visualize`. See `apps/workflow-viewer/UPSTREAM.md` for the pinned upstream revision and preserved MIT license. The proprietary desktop application is not included.

## Local use

1. Install dependencies with `npm ci`.
2. Run `npm run dev` to start native Temporal, the workers, mock backend and viewer.
3. Open http://localhost:7531. The default search lists POC executions with Workflow IDs beginning `mailbox-`. Clear that query to list other executions, or enter Temporal's List Filter syntax and a namespace.
4. Run `npm run demo:viewer` in another terminal. Select the printed Workflow ID.
5. Follow the activity/timer graph and click activity nodes to inspect Input, Output and failure information. Outputs arrive automatically after completion.

The list refreshes every five seconds. An open running execution refreshes every two seconds. Pause/resume and manual refresh controls are available. When an execution closes, automatic refresh stops; failures keep the last good snapshot visible. A selected node is resolved against each fresh snapshot, so the details panel updates too.

The default **Workflow** view shows a fixed diagram with all steps present immediately. Layout and node identity do not depend on history length. React Flow fits the diagram when you enter that execution/view, then preserves your viewport during live updates. Use the canvas controls to zoom, pan or fit manually.

| Appearance            | Meaning                                     |
| --------------------- | ------------------------------------------- |
| Gray hollow icon      | Not started, or not reached after a failure |
| Blue spinner          | Running                                     |
| Blue clock            | Queued for an activity worker               |
| Amber spinner         | Waiting for mailbox availability            |
| Orange rotating arrow | Retrying after an activity failure          |
| Green check           | Succeeded                                   |
| Red cross             | Failed                                      |
| Gray minus            | Canceled                                    |

Attempt numbers are taken from Temporal history/pending activity metadata. Availability checks are counted separately from Activity retries. A false availability result keeps the logical wait step amber; it becomes green after a true result. Durable timers and repeated checks never add nodes to the default view. Individual events remain accessible in the raw history and optional **Execution trace** view.

## Deploy on a server

Build from the repository root:

```sh
npm ci
npm run build
```

Deploy `apps/workflow-viewer/server.mjs`, `apps/workflow-viewer/server-lib.mjs`, and the **contents of `apps/workflow-viewer/dist`** together, preserving that directory structure. The built viewer server uses Node.js built-ins; it does not need workspace packages, React, Vite or npm dependencies at runtime. Keep its upstream license/attribution alongside the distribution. Frontend libraries are bundled into `dist/assets`.

On the server, configure environment variables through your process manager:

| Variable             | Meaning                                                                  | Default                 |
| -------------------- | ------------------------------------------------------------------------ | ----------------------- |
| `VIEWER_HOST`        | Server listen interface                                                  | `127.0.0.1`             |
| `VIEWER_PORT`        | UI and API listen port                                                   | `7531`                  |
| `TEMPORAL_UI_URL`    | Temporal UI HTTP service reachable **from the viewer server**            | `http://localhost:8233` |
| `TEMPORAL_NAMESPACE` | Initial namespace in the browser search                                  | `default`               |
| `VIEWER_URL`         | Optional URL printed by demo CLI commands; does not configure the server | `http://localhost:7531` |

Start it with:

```sh
node apps/workflow-viewer/server.mjs
```

Or, when retaining the full monorepo and its `.env`, use `npm run start:viewer` from the root. Do not simultaneously start the viewer through the full dev launcher on the same port.

For a shared server, either bind `VIEWER_HOST=0.0.0.0` on the intended internal interface or keep loopback and place your existing reverse proxy in front. Serve the app at the root of a dedicated host, for example `https://workflows.example.internal/`, with all paths forwarded to the viewer; this version does not implement hosting beneath a URL subpath. UI and `/api/*` use the same origin, so each user's browser does not need direct access to Temporal's ports or a hardcoded localhost API address.

Use your existing TLS/SSO access policy at the reverse proxy. The viewer has no built-in authentication and displays workflow payloads. It makes read-only requests to the configured Temporal UI service and does not forward browser credentials; authenticated upstream services need a server-side authentication adapter appropriate to your environment. No mutation endpoints are exposed by this viewer.

## Source ownership

| Change                                                    | Files                                               |
| --------------------------------------------------------- | --------------------------------------------------- |
| Backend endpoint, static hosting, HTTP history pagination | `apps/workflow-viewer/server-lib.mjs`               |
| Process binding and lifecycle                             | `apps/workflow-viewer/server.mjs`                   |
| Live refresh, pause/resume, selected-node details         | `apps/workflow-viewer/src/pages/WorkflowDetail.tsx` |
| Polling completion rules                                  | `apps/workflow-viewer/src/lib/live.ts`              |
| Graph grouping and layout                                 | `apps/workflow-viewer/src/lib/graph-transformer.ts` |
| Default payload decoding                                  | `apps/workflow-viewer/src/lib/payloads.ts`          |
| Search and list pagination                                | `apps/workflow-viewer/src/pages/Dashboard.tsx`      |
| Global browser configuration and API calls                | `apps/workflow-viewer/src/api/client.ts`            |

The workflow code and activity implementations are unchanged by the viewer. No visualization annotations or custom events are required from these three workflows.

## Fixed definitions and execution overlays

The three POC workflow types have explicit, typed diagram definitions in the shared contracts package. Each definition declares stable step IDs, labels, positions, activity-name bindings and edges. Group provisioning declares its configuration/group split and join from the start. These definitions are bundled into the browser; the standalone Node server still requires only its files and built assets.

Workflow code remains the source of execution behavior. The diagrams are presentation metadata, not a DSL interpreter or a replacement for workflow code. When adding a workflow or changing its steps/branching, update its definition and increment the definition version for review. The version is displayed in the viewer; it is not currently pinned into execution history. Serving multiple incompatible historical diagram versions requires an explicit version-selection strategy before such a migration.

`fixed-graph.ts` overlays observed activity state on the declared nodes. The availability step groups all `checkMailboxReadiness` calls and their intervening durable timers. Clicking it shows input from the latest check, output from the latest completed check and all grouped raw events. Retrying activities use the same node and show their current attempt. The finish node reflects the actual workflow result, including failure, cancellation and timeout. Terminal history takes precedence when it is newer than the Describe snapshot.

Unregistered workflow types explicitly fall back to the history-derived trace. Unexpected activity names trigger a mismatch notice rather than silently being presented as mapped steps. The fallback trace links events by workflow-task causality and is an observed execution, not an exhaustive design diagram. Future unexecuted paths in arbitrary TypeScript cannot be derived from history alone. Child workflow graphs, signals/updates and comprehensive individual retry-attempt timelines remain outside this implementation.

History pagination is followed; the server rejects histories beyond 1,000 pages rather than silently drawing an incomplete graph. Refresh currently refetches the full history and description, so very long histories or many concurrent viewers need a caching/incremental-history strategy before broad deployment. The API uses request timeouts and cancels upstream requests when the browser request closes.

JSON payloads using Temporal's default `json/plain` encoding are decoded for Input and Output. Unsupported/custom/encrypted payloads retain their encoding and original Base64 data. No custom codec execution is performed.

## Domain-owned descriptors

Fixed mailbox topology now lives in `packages/mailbox/src/presentation`; generic diagram contracts/registry validation live in `packages/temporal-platform/src/visualization`. The viewer imports them only through `src/registry.ts`. Additional contexts publish descriptors and register them there without importing their workflow implementations or services. Diagram activity names bind to mailbox contract constants. The graph is presentation metadata and must be reviewed alongside workflow changes.

## Results reused after reset

Completed activities whose results precede the most recent Temporal reset marker remain green with a dashed border and a **Reused from previous run** badge. Their details explain that no new activity ran, preserve the recorded input/output, and link to the source Run ID when Temporal provides it. Newly executed activities retain the normal spinner/success/failure styling. Reuse is distinct from idempotency: an idempotent activity still executes.

Classification uses the `WORKFLOW_TASK_FAILED` reset cause and event IDs in the current run’s history, not timestamps or merely a changed Run ID. A grouped availability step is reused only when all its checks completed before the reset boundary. An activity scheduled before reset but completed afterward is not classified as reused. Missing reset metadata means no badge; ordinary retry/continue-as-new runs are not guessed to be resets. This provenance overlay is provided in the fixed Workflow view, not the optional raw execution trace.

Reset creates a separate Run ID under the same Workflow ID. Both runs can be selected from the execution table, and their detail routes include the Run ID. The source-run link offers direct access to the preceding run. Histories remain available until the namespace retention policy removes them; reset does not overwrite the original run.
