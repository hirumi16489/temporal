# Architecture: capability code, execution adapters and hosts

## Package boundaries reflect reuse and deployment

Seven npm workspaces represent workflow/activity/viewer applications, an optional access gateway, two shared libraries and one test-support toolbox. Domain/application/adapters are ordinary folders in `packages/mailbox`, not package or deployment units. A future business context gets its own capability library; it does not need a new workspace for every layer.

| Boundary                       | Reason                                                                      |
| ------------------------------ | --------------------------------------------------------------------------- |
| Workflow host vs activity host | Independent deployment, permissions, runtime dependencies and capacity      |
| Mailbox library vs hosts       | Reusable business capability code without embedding deployment decisions    |
| Temporal platform vs mailbox   | Domain-independent queue/runtime/visualization mechanisms                   |
| Viewer vs workers              | Read-only presentation with its own release and access boundary             |
| Test support vs production     | Simulator/fault controls cannot accidentally become production dependencies |

Each manifest records logical context, layer, owner and production status. Map logical owners to actual team handles in your repository review rules; no fictional organizational identities are provided.

## Hexagonal boundary

```mermaid
flowchart TD
 H["Activity worker host"] --> I["Inbound Temporal handlers"]
 H --> O["Outbound provider adapters"]
 I --> A["Application services"]
 A --> D["Domain models and rules"]
 A --> P["Outbound port interfaces"]
 O --> P
 O --> X["External dependencies"]
```

The host is a process entry point. It assembles dependencies and registers handlers, then polls a task queue. The handler is the inbound adapter: receives activity input, calls a service, supplies cancellation/attempt context and maps non-retryable errors. Services execute meaningful business capabilities and know nothing about Temporal.

Application contracts are the inbound port/signatures and serializable input/output DTOs. Outbound ports express what services need from dependencies. Implementations belong under `adapters/outbound`. Domain code contains rules, immutable plans and internal identifiers. Transport-specific DTOs and credentials belong to adapter configuration, not domain models.

## Actual locations

| Responsibility                  | Location                                                   |
| ------------------------------- | ---------------------------------------------------------- |
| Input/output interfaces, names  | `packages/mailbox/src/application/contracts`               |
| Capability behavior             | `packages/mailbox/src/application/services`                |
| Dependency interfaces           | `packages/mailbox/src/application/ports/outbound`          |
| Activity entry handlers         | `packages/mailbox/src/adapters/inbound/temporal`           |
| Provider implementations        | `packages/mailbox/src/adapters/outbound`                   |
| Workflow orchestration          | `apps/mailbox-workflow-worker/src/workflows`               |
| Worker composition              | `apps/mailbox-activity-worker/src/main.ts`, `bootstrap.ts` |
| Queue routing / capacity reader | `packages/mailbox/src/execution`, `execution/worker`       |
| Graph topology                  | `packages/mailbox/src/presentation`                        |

Inside the library, imports are relative modules. Outside it, callers use public subpaths such as `@automation/mailbox/contracts`, `/application` or `/adapters/inbound/temporal`. The package deliberately has no root barrel exporting everything. A type-only workflow import does not pull business implementations into the sandbox.

The five activity boundaries represent preparation, provisioning, one readiness check, configuration, and related-group provisioning. Setting addresses, retention and owner can remain normal service calls inside configuration. Split only when independent retry, ownership, waiting, parallelism or failure handling merits another activity. Configuration is not a cross-system transaction: every constituent mutation must converge safely after partial success. Stable operation keys support this; they do not automatically provide exactly-once effects.

## Workflow code and server responsibilities

A client or Temporal Schedule starts an execution through the Temporal service. A workflow worker polls workflow tasks, runs deterministic orchestration and returns commands. Activity workers poll activity tasks and invoke locally registered handlers. Code is deployed to workers, not uploaded into the server. One process can host multiple types; replicas polling the same queue need compatible registrations.

Personal activity fleets and standard fleets use the same implementation but different queues/slots. The workflow host is a separate release. Its workflow queue currently serves all three process types; a future orchestration-isolation requirement can introduce separate workflow queues without rewriting capabilities.

## Enforcement within folders

The AST checker resolves each import to an internal layer or public subpath. Domain cannot import application/adapters; application cannot import adapters; workflow definitions can import contracts/execution only. It rejects production-to-test imports, cross-workspace relative paths, undeclared dependencies, Node IO in pure layers and worker-only code in sandbox-safe modules. The core TypeScript check excludes Node ambient types for domain/application. Package exports restrict public entry points.

These are maintainability checks, not a security sandbox or a proof of determinism. TypeScript interfaces are erased; request validation happens in the domain preparation path. Across contexts, public application contracts are the integration boundary; do not reach into another team's services through a deep import.

## Test composition and production gap

`test/support/src/adapters` implements the same outbound ports against the simulator. Its runtime assembles production services and inbound handlers with those test adapters. Simulation latency, propagation, fault injection and JSON repair remain outside production contracts. The simulator is single-process local tooling.

Enterprise adapter composition fails before polling until provider implementations/configuration are supplied. Production connection security, secrets, health probes, telemetry and deployment policy must be supplied for your environment. Existing release staging proves packaging boundaries, not provider compatibility or operational readiness in a real infrastructure.

## Optional client access boundary

`apps/temporal-access-gateway` is a deployable inbound gRPC adapter. It terminates real client-certificate TLS, maps verified certificate fingerprints to principals, authorizes a restricted workflow API surface, and forwards allowed requests to Temporal. Generic policy is in `packages/temporal-platform/src/access`; shared native SDK TLS loading is in `connection`. Neither depends on mailbox business implementation. Local PKI and matrix clients remain in test support. This demonstrates gateway authorization, not an installed native Temporal Authorizer. See MTLS_DEMO.md.
