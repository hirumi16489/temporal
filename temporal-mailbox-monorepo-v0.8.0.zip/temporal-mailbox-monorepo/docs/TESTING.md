# Development checks and tests

All commands run from the repository root. Use `npm ci` first.

## Fast loop

- `npm run dev`: start the native Temporal server and app processes; rebuild/restart the apps on source or capacity changes.
- `npm run format`: format source/config/docs.
- `npm run lint`: ESLint and source import-boundary guardrails.
- `npm test`: compile first, then unit and React DOM tests without Temporal.
- `npm run check`: formatting check, lint, build/typechecks and unit/DOM tests.

TypeScript project references compile dependencies in order. `tsconfig.tools.json` also checks TypeScript tooling and tests, including intentionally rejected undeclared pool identifiers marked with `@ts-expect-error`.

The folder-aware boundary script prevents domain/application importing adapters, workflow definitions importing implementation/worker/Node modules, and production code importing test support. Test support deliberately reuses the activity-host bootstrap factory to exercise the same worker options as production. It is an architectural guardrail, not a security sandbox; Temporal's bundler/runtime enforces its own workflow environment.

## Real Temporal integration tests

```sh
npm run test:integration
```

The command builds the same sandbox bundle used by the app and runs temporary real Temporal servers, actual Workflow/Activity Workers, and the HTTP mock backend. It requires the SDK-supported test-server binary, downloaded on first use, and available local ports. Your manual development stack is not required or modified.

The main suite checks:

- Personal, room and group workflows complete.
- Room settings are actually recorded in mock resource state.
- Transient provisioning errors retry exactly as expected.
- Configuration can be retried after its side effect was committed.
- A permanent configuration failure is not retried and the independent group branch settles successfully.
- Both standard slots can remain blocked while a personal request completes on its dedicated queue.
- A burst of ten personal executions stays within the personal worker's four-slot limit.

The reserved-capacity check uses a controllable test hook at the backend boundary. It makes the two standard calls wait on a gate, waits until both have arrived, then completes the personal workflow before opening that gate. This proves routing/capacity separation without a fragile "must finish within N milliseconds" assertion.

A native-stack suite also runs the normal managed launcher against a native CLI, executes a workflow, stops the complete stack and restarts it against the same database to verify preserved history. The separate external-server launcher suite verifies capacity reloads and application shutdown without owning its server. Missing-CLI errors and portable-path configuration are covered by tooling tests.

The viewer integration suite starts a real Temporal UI server, runs a group workflow and checks that the deployed web server exposes pending activity state, activity input/output and terminal history. Server tests cover read-only routes, identifier escaping, paginated history and SPA routes. Graph tests verify all three predeclared topologies, fixed positions/IDs across repeated polling and retry/failure states, collapsed availability checks/timers, parallel branches and timeout/pending-state handling.

`npm run test:ui` runs the actual React detail page in jsdom with a drawing stub for the canvas. It verifies that an open activity panel receives decoded output, live refresh can be paused/resumed and fetching stops when the execution closes. The graph transformation is separately tested. A viewport test verifies that state updates do not repeatedly fit or move the canvas. The real viewer API test also observes a transient Activity retry as orange/retrying on the original fixed node and verifies unchanged topology and all-green states at completion. These DOM tests run within `npm test`, `npm run check` and `npm run ci`.

For full browser testing, build first, install a browser once using `npx playwright install chromium`, then run `npm run test:browser`. Set `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` to an existing compatible Chrome/Chromium executable if downloading a browser is unsuitable. The Playwright test starts its own real Temporal/UI/workers and checks graph selection, payload updates, live refresh and completion. `.github/workflows/ci.yml` includes its browser-install and test steps. Browser execution depends on the host allowing Chromium to start; see VALIDATION.md for what was actually verified in this delivery.

## CI

`npm run ci` runs quality gates and integration suites. `.github/workflows/ci.yml` provides a Node 24 Linux job with npm caching.

If an integration test fails, inspect the Activity/Workflow errors in test output. Unit tests do not need a running Temporal server or network. Integrations need network only if the cached Temporal test server must be downloaded. Platform-native dependencies may require a supported SDK platform.

After changing only documentation, run formatting checks. After changing routing, activities, contracts or workflow code, run the relevant unit tests and the Temporal integration suite. Workflow restart/replay compatibility and production autoscaling require further environment-specific checks.

## Architectural regression checks

Tests verify domain validation, immutable plans, rejected simulation DTO fields, stable per-operation idempotency keys after partial failure, typed readiness results, descriptor bindings and fail-closed enterprise startup. The architecture regression fixture intentionally introduces a production dependency on a test package and direct domain IO; the checker must reject both. A clean `build:production` selects production workspaces only. See ARCHITECTURE.md for the enforced dependency policy.

## Failed execution recovery

The real Temporal reset test runs `demo:repair` as a subprocess to change persisted permission JSON, asserts the execution remains closed as Failed, then resets at the Workflow Task that scheduled configuration. It proves only configuration executes again by counting actual activity invocations, and checks the only new provider calls are settings and owner updates. See RECOVERY_DEMO.md for the UI walkthrough.

## Release stages

The staging regression test checks independent entry points/dependency closures, absence of simulator implementations, standalone viewer contents and refusal to overwrite releases or stage into source directories. Target-host runtime installation and a real execution through the isolated workflow release were additionally verified for this delivery; see VALIDATION.md.

## mTLS and segregation

The two-client integration test uses real TLS certificates, the actual Temporal SDK and real workflow/activity workers. It checks permitted starts, rejected workflow/namespace/queue/ID changes, cross-client history isolation, identity-header spoofing, unexposed mutation APIs, absent/untrusted/unregistered client certificates, and server identity verification. The gateway's policy and shared TLS loader also have unit coverage. OpenSSL is required; set OPENSSL_PATH to a portable executable when needed. No test skips security checks when certificate generation is unavailable.
