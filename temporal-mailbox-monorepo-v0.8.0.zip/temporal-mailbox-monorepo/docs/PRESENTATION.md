# Presenting industrialisation

The objective is to show how teams maintain, deploy, operate and recover automation, using real Temporal behavior and honest provider boundaries. The simulator controls external conditions; production services/handlers and orchestration remain the execution path.

## Start with ownership and deployment

Show the workspace table in README and one inbound handler next to its service and outbound port. Point out that they are folders/modules in the mailbox library, while worker hosts are applications. The workflow imports an application contract, not the implementation. Show the enterprise host refusing unconfigured providers: it cannot accidentally operate against local mocks.

Build and stage workflow-worker, activity-worker and viewer releases using `build:production` / `release:stage`. Open their `release.json` files: each has a separate entry point and dependency closure. Explain that the same activity artifact runs as personal and standard fleets, and that source reuse does not imply shared capacity or a single deployment.

## Demonstration sequence

| Scenario                   | Run                                                        | What to inspect                                                               | What it establishes                                                                |
| -------------------------- | ---------------------------------------------------------- | ----------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| Shared capabilities        | `npm run demo -- personal`, then `room`, then `group`      | Explicit workflows, shared activity names, room inputs and group branches     | Reuse without one giant branching workflow                                         |
| Transient failure          | `npm run demo -- retry`                                    | Provision node retries; earlier successful activities remain completed        | Retry scope belongs to the activity boundary                                       |
| Lost response after commit | `npm run demo -- idempotency`                              | Failure/retry and persisted configured state                                  | External operations must converge after uncertain outcomes                         |
| Partial business failure   | `npm run demo -- failure`                                  | Red configuration node alongside successful group branch                      | Failure classification and independent branch visibility                           |
| Operator recovery          | `npm run demo:recovery`; repair JSON; Reset in Temporal UI | Old Failed run, new Run ID, reused badges and configuration-only re-execution | Recovery after an external issue is repaired without custom waiting workflow logic |
| Capacity isolation         | `npm run demo:isolation`                                   | Standard backlog while personal work completes; queue/pool counters           | Independent worker capacity even with shared implementation                        |
| Bounded throughput         | `npm run demo -- batch 10`                                 | Queued activities and configured concurrent slots                             | Capacity is supplied by workers, not by queue names                                |
| Live operations view       | `npm run demo:viewer`                                      | Stable topology, durable availability waits, retries, input/output            | Operational visibility without a growing history graph                             |

Run recovery after the others when explaining failure semantics. The terminal prints the repair command and exact reset event ID. Its expected initial exit code is 1. The repair changes dependency state only; Reset creates a new execution run. Source-run links preserve access to the failed run while Temporal retains its history.

`latencyMs` slows simulated provider calls; `propagationMs` controls when a created mailbox becomes readable. They are test controls, not production request fields. Recovery uses 1500 ms provider calls so the retried configuration is visible.

## Two-client security boundary

Run the [mTLS matrix](MTLS_DEMO.md) after showing the centralized start API. Both clients use the same secure endpoint but present separate certificates. Client A starts personal workflows; Client B starts room workflows. Show denied cross-start/read attempts in the gateway audit log and the two allowed executions in the viewer. Explain authentication versus authorization and why denied starts produce no workflow history.

The gateway is an additional deployable ingress, not an activity or workflow. Its policy is distinct from worker capacity isolation. The native local backend is loopback-only and bypassable by another trusted local process; in a real deployment clients must not reach it directly. Do not present this as native per-workflow RBAC or native dev-server TLS.

## Explain how changes are released

- A new workflow can reuse already-deployed activities if its required names/contracts exist. Deploy the workflow host only.
- A compatible adapter/service fix can deploy through the activity host without rebuilding workflow behavior.
- A dedicated pool requires consumers of that queue; naming a queue alone does not deploy capacity.
- A contract change is a compatibility rollout across independently running producers/consumers. A source package version is not a substitute for wire/versioning policy.
- Existing workflow histories constrain orchestration changes. Reset recovery is not an excuse to disregard replay compatibility.

## Evidence and limits

The real integration tests verify retries, post-commit convergence, failure with successful sibling work, dedicated capacity, native server restart persistence and reset call counts. The reset test proves prepare/provision/readiness execute once and configuration twice, checks the failed history is still accessible, and validates reused-node provenance against real server events.

Selective reset for arbitrary parallel histories is not promised: reset uses a chronological point. Domain provider integration, SSO/TLS, secrets, production health/telemetry, version-routing policy and autoscaling remain environment-specific work. Native development Temporal and the single-process JSON simulator are local tooling. Schedule-triggered starts are a native Temporal capability but are not currently a scripted presentation scenario in this repository. Keep those distinctions explicit rather than presenting the POC as a complete production platform.
