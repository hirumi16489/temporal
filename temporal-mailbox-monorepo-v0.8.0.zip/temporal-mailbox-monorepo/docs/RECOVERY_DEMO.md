# Failed execution → dependency repair → UI reset

This demo shows native Temporal reset of a **closed, failed workflow**. The workflow has no intervention state, signal handler or custom retry loop. The repair command changes only a simulator JSON file. Recovery is triggered from Temporal UI.

## 1. Start the local stack

```sh
npm ci
npm run dev
```

Keep it running. In another terminal, from the repository root:

```sh
npm run demo:recovery
```

This starts a personal mailbox workflow with configuration permission denied. Prepare, provision and readiness succeed. `configureMailbox` receives a simulated 403, mapped to a non-retryable permission failure. The workflow becomes **Failed**; it is not parked or automatically retried. The command intentionally exits with status 1.

The terminal prints the **Workflow ID** and the exact **workflow-task finish event ID** to use for reset. Keep those values. It also prints the repair command.

Open http://localhost:7531 to inspect the original run: earlier steps are green and configuration is red. Temporal UI at http://localhost:8233 exposes the native reset action.

## 2. Repair only the simulated dependency

Use the exact Workflow ID printed above:

```sh
npm run demo:repair -- mailbox-<printed-request-id>
```

The command changes `.data/mailbox-permissions.json` to grant configuration permission for this request. `MAILBOX_TEST_PERMISSIONS_FILE` overrides the path; the launcher and commands load `.env`. The configuration endpoint rereads the file on every call, so no simulator or worker restart is needed.

The file contains, for example:

```json
{
  "configuration": {
    "<printed-request-id>": "ALLOWED"
  }
}
```

You can edit that entry manually instead. File state is per request, not a global switch. `DENIED` makes it fail again. Entries persist through simulator restart. The file is test-only and is separate from persisted mailbox resource state. The local repair utility assumes a single operator writer.

**At this point the workflow remains Failed.** The command does not invoke Temporal, reset an execution, replay a workflow or change workflow state.

## 3. Reset from Temporal UI

1. At http://localhost:8233 open namespace `default` (or your configured namespace) and find the printed Workflow ID.
2. Open the failed run and choose **Reset** in the execution actions.
3. Choose the custom event/reset-point option and enter the **workflow-task finish event ID printed by the command**. This is the Workflow Task that scheduled `configureMailbox`, before the failed configuration attempt. Do not choose a later point that already retains the permission failure.
4. Enter a reason such as `Configuration permission repaired` and confirm.
5. Follow the new run linked by Temporal UI. The Workflow ID is unchanged; the Run ID is new.

If your installed Temporal UI labels reset options differently, use its event history to locate that exact Workflow Task completion event. The demo reports the numeric ID so the selection is explicit.

Open the new run in the graph viewer at http://localhost:7531. The prior completed steps retain their successful history and show dashed green borders with **Reused from previous run** badges. Their details include a source-run link, so you can reopen the original failed run. Configuration runs again and turns green. The execution completes successfully.

## What actually executes

| Capability        | Before repair/reset                              | After reset                                    |
| ----------------- | ------------------------------------------------ | ---------------------------------------------- |
| Prepare           | Executes successfully                            | Recorded result reused                         |
| Provision mailbox | Executes successfully                            | Recorded result reused; no second create call  |
| Check readiness   | Executes successfully                            | Recorded result reused                         |
| Configure mailbox | Executes once and fails before applying settings | Executes again, settings and owner are applied |

Reset creates a new run using history up to the selected point. Workflow code can replay to reconstruct its state, but earlier completed activities are not called again. The recovery integration test counts actual worker invocations and simulator calls, rather than inferring this from the graph.

This is a sequential reset demonstration. The existing `demo -- failure` still demonstrates independent group-branch success alongside configuration failure. Resetting arbitrary parallel histories can also rerun activities after the chosen chronological point; this demo does not claim Step Functions-style selective redrive for every parallel layout.

## Automated evidence

`test/integration/workflow-reset.test.ts` uses a real Temporal server and production workflow bundle. It verifies a closed Failed execution, runs the actual repair command, checks persisted JSON and unchanged workflow status, invokes the same reset API used by Temporal UI, then verifies a new successful Run ID. Actual call counts remain prepare=1, provision=1, readiness=1 and configuration=2. Only `/configure` and `/owners` reach the simulator after reset.

```sh
npm run build
node --import tsx --test test/integration/workflow-reset.test.ts
```

The normal `npm run test:integration` / `npm run ci` include this test. Full browser interaction remains a target-environment check; the reset API and subsequent real execution are verified automatically.
