import { test } from 'node:test';
import assert from 'node:assert/strict';
import { WorkflowDiagrams } from '@automation/mailbox/diagrams';
import { MailboxActivityNames, WorkflowTypes } from '@automation/mailbox/contracts';
import { createDiagramRegistry } from '@automation/temporal-platform/visualization';
import * as workflows from '@hosts/mailbox-workflow-worker/workflows';

test('all mailbox descriptors use registered workflow exports and activity wire names', () => {
  const registry = createDiagramRegistry(WorkflowDiagrams);
  assert.deepEqual(Object.keys(registry).sort(), Object.values(WorkflowTypes).sort());
  const names = new Set<string>(Object.values(MailboxActivityNames));
  for (const [name, diagram] of Object.entries(registry)) {
    assert.equal(typeof workflows[name as keyof typeof workflows], 'function');
    for (const step of diagram.steps)
      for (const activity of step.activityTypes) assert.ok(names.has(activity), activity);
    const availability = diagram.steps.find((step) => step.id === 'availability');
    assert.equal(availability?.completionField, 'ready');
  }
});
