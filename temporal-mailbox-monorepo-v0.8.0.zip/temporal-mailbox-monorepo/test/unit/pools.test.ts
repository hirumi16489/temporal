import { poolKey } from '@automation/temporal-platform/task-queues';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  activityPool,
  dedicatedActivityPool,
  ActivityPools,
  IsolationKeys,
} from '@automation/mailbox/execution';
import { resolvedPools } from '@automation/mailbox/execution';
import { workerConfig } from '@automation/mailbox/execution/worker';

test('pool builders require declared constants at compile time and validate runtime input', () => {
  assert.equal(poolKey(activityPool(ActivityPools.MAILBOX)), 'mailbox-provisioning:shared');
  assert.equal(
    poolKey(dedicatedActivityPool(ActivityPools.MAILBOX, IsolationKeys.PERSONAL_MAILBOX)),
    'mailbox-provisioning:personal-mailbox',
  );
  assert.throws(() => {
    // @ts-expect-error Undeclared capability must not compile for consumers.
    activityPool('unregistered');
  }, /Undeclared activity pool/);
  assert.throws(() => {
    // @ts-expect-error Undeclared isolation key must not compile for consumers.
    dedicatedActivityPool(ActivityPools.MAILBOX, 'whatever');
  }, /Undeclared isolation key/);
  assert.notEqual(resolvedPools.personal, resolvedPools.standard);
});

test('bootstrap reuses dedicated queue identity; a new pool gets its own suffix', async () => {
  const { resolvePools } = await import('@automation/temporal-platform/task-queues/bootstrap');
  const defs = {
    personal: dedicatedActivityPool(ActivityPools.MAILBOX, IsolationKeys.PERSONAL_MAILBOX),
    standard: activityPool(ActivityPools.MAILBOX),
  };
  const first = resolvePools(defs);
  const restarted = resolvePools(defs, first.entries);
  assert.deepEqual(restarted, first);
  assert.notEqual(first.profiles.personal, resolvePools(defs).profiles.personal);
  assert.equal(first.profiles.standard, 'automation.v2.mailbox-provisioning.shared');
  assert.throws(
    () => resolvePools(defs, { 'mailbox-provisioning:shared': 'wrong' }),
    /Invalid stored queue/,
  );
});

test('capacity is configured per worker and invalid capacity fails before connecting', () => {
  const capacities = { personal: { concurrencyPerWorker: 4, replicas: 2 } };
  const config = workerConfig('personal', capacities, {});
  assert.equal(config.concurrency, 4);
  assert.equal(config.replicas, 2);
  assert.equal(config.taskQueue, resolvedPools.personal);
  assert.equal(workerConfig('personal', capacities, { ACTIVITY_CONCURRENCY: '8' }).concurrency, 8);
  assert.throws(() => workerConfig('unknown', capacities, {}), /Unknown pool/);
  assert.throws(
    () => workerConfig('personal', capacities, { ACTIVITY_CONCURRENCY: '0' }),
    /positive integer/,
  );
  assert.throws(() => workerConfig('personal', capacities, { ACTIVITY_RATE: '-1' }), /positive/);
});
