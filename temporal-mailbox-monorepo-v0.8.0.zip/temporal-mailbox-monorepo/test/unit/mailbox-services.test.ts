import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  createMailboxServices,
  type MailboxPorts,
  type OperationContext,
} from '@automation/mailbox/application';
import { DependencyUnavailable } from '@automation/mailbox/domain';
import { example } from '@test/mailbox-support/fixtures';
import { createEnterpriseMailboxPorts } from '@automation/mailbox/adapters/outbound';
test('configuration retries converge across mailbox and directory ports with stable operation keys', async () => {
  const calls: { operation: string; context: OperationContext }[] = [];
  let ownerFailure = true;
  const applied = new Set<string>();
  const ports: MailboxPorts = {
    mailboxes: {
      ensureMailbox: async () => 'CREATED',
      isReady: async () => true,
      configureSettings: async (_plan, context) => {
        calls.push({ operation: 'settings', context });
        applied.add(context.idempotencyKey);
      },
    },
    directory: {
      configureOwner: async (_plan, context) => {
        calls.push({ operation: 'owner', context });
        if (ownerFailure) {
          ownerFailure = false;
          throw new DependencyUnavailable('Directory unavailable');
        }
        applied.add(context.idempotencyKey);
      },
    },
    groups: { ensureDistributionGroup: async () => {} },
  };
  const services = createMailboxServices(ports),
    request = example('PERSONAL', 'configuration');
  await assert.rejects(
    services.configuration.configure(request, { attempt: 1 }),
    /Directory unavailable/,
  );
  assert.equal(
    (await services.configuration.configure(request, { attempt: 2 })).status,
    'CONFIGURED',
  );
  assert.deepEqual(
    calls.map((call) => call.operation),
    ['settings', 'owner', 'settings', 'owner'],
  );
  assert.equal(calls[0].context.idempotencyKey, calls[2].context.idempotencyKey);
  assert.notEqual(calls[0].context.idempotencyKey, calls[1].context.idempotencyKey);
  assert.equal(applied.size, 2);
  assert.equal(calls[2].context.attempt, 2);
  assert.deepEqual(await services.readiness.check(request, { attempt: 1 }), {
    identity: request.identity,
    ready: true,
  });
});
test('production composition refuses unconfigured external adapters instead of selecting mocks', () => {
  assert.throws(
    () => createEnterpriseMailboxPorts(),
    (error: any) => error.code === 'ExternalAdapterNotConfigured' && error.retryable === false,
  );
});
