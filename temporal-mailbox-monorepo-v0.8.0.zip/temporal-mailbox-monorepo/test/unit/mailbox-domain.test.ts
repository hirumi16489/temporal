import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createProvisioningPlan, InvalidMailboxRequest } from '@automation/mailbox/domain';
import { example } from '@test/mailbox-support/fixtures';
import { mapMailboxFailure } from '@automation/mailbox/adapters/inbound/temporal';
import type { ProvisioningRequest } from '@automation/mailbox/contracts';
test('domain creates an immutable plan and enforces mailbox-specific invariants without Temporal', () => {
  const room = example('ROOM', 'room');
  const plan = createProvisioningPlan(room);
  assert.ok(Object.isFrozen(plan));
  assert.ok(Object.isFrozen(plan.configuration.aliases));
  assert.equal(plan.room?.capacity, 8);
  assert.throws(
    () => createProvisioningPlan({ ...room, room: { ...room.room, capacity: -1 } }),
    InvalidMailboxRequest,
  );
  assert.throws(
    () =>
      createProvisioningPlan({ ...example('PERSONAL', 'p'), room: { capacity: 3, location: 'A' } }),
    /Only room/,
  );
  assert.throws(
    () =>
      createProvisioningPlan({
        ...example('GROUP', 'g'),
        group: { identity: 'g', members: [null] },
      }),
    /member/,
  );
  assert.throws(
    () => createProvisioningPlan({ ...example('PERSONAL', 'p'), demo: { latencyMs: 100 } }),
    /Unknown mailbox request field/,
  );
  assert.throws(
    () =>
      createProvisioningPlan({
        ...example('PERSONAL', 'p'),
        configuration: { aliases: [], owner: 'owner', retention: 'standard', unknown: true },
      }),
    /Unknown configuration field/,
  );
  assert.throws(
    () =>
      createProvisioningPlan({ ...example('PERSONAL', 'p'), kind: { toString: () => 'PERSONAL' } }),
    /Unknown mailbox kind/,
  );
  const request: ProvisioningRequest = example('PERSONAL', 'typed');
  // @ts-expect-error Simulation flags do not belong to the production API.
  void request.demo;
});
test('activity boundary classifies invalid input as non-retryable while domain errors remain framework-free', () => {
  const error = new InvalidMailboxRequest('Invalid room');
  assert.equal((error as any).nonRetryable, undefined);
  assert.throws(
    () => mapMailboxFailure(error),
    (failure: any) => failure.nonRetryable === true && failure.type === 'InvalidMailboxRequest',
  );
});
