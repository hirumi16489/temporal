import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  validateAccessPolicy,
  authorizeWorkflowAccess,
  principalForCertificate,
} from '@automation/temporal-platform/access';
import { temporalConnectionSettings } from '@automation/temporal-platform/connection';
const source = {
  namespace: 'default',
  workflowTaskQueue: 'workflow-q',
  clients: [
    {
      id: 'client-a',
      certificateFingerprints: ['AA'.repeat(32)],
      workflowTypes: ['Personal'],
      workflowIdPrefix: 'mailbox-client-a-',
    },
    {
      id: 'client-b',
      certificateFingerprints: ['BB'.repeat(32)],
      workflowTypes: ['Room'],
      workflowIdPrefix: 'mailbox-client-b-',
    },
  ],
};
test('certificate policy scopes workflow types, namespace, queue and execution ownership independently of metadata', () => {
  const policy = validateAccessPolicy(source),
    a = principalForCertificate(policy, 'AA:'.repeat(31) + 'AA')!;
  const target = {
    operation: 'start' as const,
    namespace: 'default',
    workflowId: 'mailbox-client-a-1',
    workflowType: 'Personal',
    taskQueue: 'workflow-q',
  };
  assert.equal(a.id, 'client-a');
  assert.equal(principalForCertificate(policy, 'CC'.repeat(32)), undefined);
  assert.equal(authorizeWorkflowAccess(policy, a, target), true);
  for (const change of [
    { workflowType: 'Room' },
    { namespace: 'other' },
    { taskQueue: 'other' },
    { workflowId: 'mailbox-client-b-1' },
  ])
    assert.equal(authorizeWorkflowAccess(policy, a, { ...target, ...change }), false);
  assert.equal(
    authorizeWorkflowAccess(policy, a, { ...target, operation: 'read', workflowType: undefined }),
    true,
  );
  assert.throws(
    () =>
      validateAccessPolicy({
        ...source,
        clients: [
          source.clients[0],
          { ...source.clients[1], workflowIdPrefix: 'mailbox-client-a-' },
        ],
      }),
    /disjoint/,
  );
  assert.throws(
    () =>
      validateAccessPolicy({
        ...source,
        clients: [
          source.clients[0],
          {
            ...source.clients[1],
            certificateFingerprints: source.clients[0].certificateFingerprints,
          },
        ],
      }),
    /multiple clients/,
  );
  assert.throws(() => validateAccessPolicy({ ...source, clients: [] }), /requires/);
  assert.ok(Object.isFrozen(policy.clients[0].workflowTypes));
});
test('TLS connection configuration refuses incomplete identities and silent plaintext fallback', () => {
  assert.equal(temporalConnectionSettings({}).tls, undefined);
  assert.throws(
    () => temporalConnectionSettings({ TEMPORAL_TLS_CLIENT_CERT_FILE: 'a.crt' }),
    /together/,
  );
  assert.throws(
    () =>
      temporalConnectionSettings({ TEMPORAL_TLS_ENABLED: 'false', TEMPORAL_TLS_CA_FILE: 'ca.crt' }),
    /disabled/,
  );
  assert.throws(() => temporalConnectionSettings({ TEMPORAL_TLS_ENABLED: 'yes' }), /true or false/);
  assert.throws(
    () => temporalConnectionSettings({ TEMPORAL_TLS_CA_FILE: '/missing/ca.crt' }),
    /Cannot read/,
  );
  assert.throws(() => temporalConnectionSettings({ TEMPORAL_NAMESPACE: ' ' }), /empty/);
});
