import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { localServerOptions } from '../../scripts/temporal.mjs';

test('native server accepts a portable executable path and keeps persistent loopback configuration', () => {
  const config = localServerOptions({
    TEMPORAL_CLI_PATH: 'C:/Tools with spaces/temporal.exe',
    TEMPORAL_ADDRESS: '127.0.0.1:17233',
    TEMPORAL_UI_PORT: '18233',
    TEMPORAL_NAMESPACE: 'poc',
  });
  assert.equal(config.executable, 'C:/Tools with spaces/temporal.exe');
  assert.equal(config.args[config.args.indexOf('--namespace') + 1], 'poc');
  assert.equal(config.args[config.args.indexOf('--port') + 1], '17233');
  assert.equal(config.args[config.args.indexOf('--ui-ip') + 1], '127.0.0.1');
  assert.ok(config.database.endsWith('temporal.db'));
  assert.throws(() => localServerOptions({ TEMPORAL_ADDRESS: 'remote:7233' }), /external/);
  assert.throws(() => localServerOptions({ TEMPORAL_UI_PORT: '7233' }), /differ/);
});

test(
  'missing CLI exits the normal launcher with an actionable error',
  { timeout: 10_000 },
  async () => {
    const child = spawn(process.execPath, ['scripts/dev.mjs'], {
      env: { ...process.env, TEMPORAL_CLI_PATH: '/missing/mailbox/temporal' },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let logs = '';
    child.stdout.on('data', (data) => {
      logs += data;
    });
    child.stderr.on('data', (data) => {
      logs += data;
    });
    const code = await new Promise((done) => child.once('exit', done));
    assert.equal(code, 1);
    assert.match(logs, /TEMPORAL_CLI_PATH/);
  },
);
