import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, existsSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

test('release staging separates runnable hosts from libraries and excludes test implementation', () => {
  const directory = mkdtempSync(join(tmpdir(), 'mailbox-releases-'));
  function stage(role) {
    const destination = join(directory, role);
    const result = spawnSync(process.execPath, ['scripts/stage-release.mjs', role, destination], {
      encoding: 'utf8',
    });
    assert.equal(result.status, 0, result.stderr);
    return {
      destination,
      metadata: JSON.parse(readFileSync(join(destination, 'release.json'), 'utf8')),
    };
  }
  try {
    for (const role of ['workflow-worker', 'activity-worker']) {
      const { destination, metadata } = stage(role);
      assert.ok(existsSync(join(destination, metadata.entry)));
      assert.deepEqual(
        JSON.parse(readFileSync(join(destination, 'package.json'), 'utf8')).scripts,
        { start: 'node ' + metadata.entry },
      );
      assert.ok(
        existsSync(join(destination, 'packages/mailbox/dist/application/contracts/index.js')),
      );
      assert.ok(
        existsSync(join(destination, 'packages/mailbox/dist/adapters/inbound/temporal/index.js')),
      );
      assert.equal(existsSync(join(destination, 'test/support/dist')), false);
      assert.equal(existsSync(join(destination, 'test/support/src')), false);
      assert.ok(
        existsSync(join(destination, 'test/support/package.json')),
        'Only the manifest is retained for lockfile consistency',
      );
      const other = role === 'workflow-worker' ? 'activity-worker' : 'workflow-worker';
      assert.equal(existsSync(join(destination, 'apps/mailbox-' + other + '/dist')), false);
      assert.doesNotMatch(metadata.install, /@test\//);
      const repeated = spawnSync(
        process.execPath,
        ['scripts/stage-release.mjs', role, destination],
        { encoding: 'utf8' },
      );
      assert.notEqual(repeated.status, 0);
      assert.match(repeated.stderr, /Destination must not exist/);
    }
    const gateway = stage('access-gateway');
    assert.ok(existsSync(join(gateway.destination, gateway.metadata.entry)));
    assert.ok(
      existsSync(join(gateway.destination, 'packages/temporal-platform/dist/access/index.js')),
    );
    assert.equal(existsSync(join(gateway.destination, 'packages/mailbox/dist')), false);
    assert.equal(existsSync(join(gateway.destination, '.data')), false);
    assert.equal(existsSync(join(gateway.destination, 'test/support/dist')), false);
    const { destination, metadata } = stage('viewer');
    assert.equal(metadata.install, null);
    assert.deepEqual(metadata.workspaces, ['@platform/workflow-viewer']);
    assert.ok(existsSync(join(destination, 'dist/index.html')));
    assert.ok(existsSync(join(destination, 'server.mjs')));
    assert.equal(existsSync(join(destination, 'node_modules')), false);
    const forbidden = spawnSync(
      process.execPath,
      ['scripts/stage-release.mjs', 'viewer', resolve('apps')],
      { encoding: 'utf8' },
    );
    assert.notEqual(forbidden.status, 0);
    assert.match(forbidden.stderr, /Stage outside the source tree/);
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});
