import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

test('architecture guard enforces internal folders as well as production/test and sandbox boundaries', () => {
  const directory = mkdtempSync(join(tmpdir(), 'architecture-'));
  function write(path, value) {
    const target = join(directory, path);
    mkdirSync(join(target, '..'), { recursive: true });
    writeFileSync(target, typeof value === 'string' ? value : JSON.stringify(value));
  }
  function check() {
    return spawnSync(process.execPath, [resolve('scripts/check-boundaries.mjs')], {
      cwd: directory,
      encoding: 'utf8',
    });
  }
  try {
    write('packages/mailbox/package.json', {
      name: '@automation/mailbox',
      exports: {
        './contracts': { default: './dist/application/contracts/index.js' },
        './adapters/outbound': { default: './dist/adapters/outbound/index.js' },
      },
      architecture: { context: 'mailbox', layer: 'capability', owner: 'mailbox', production: true },
    });
    write('packages/mailbox/src/domain/model.ts', 'export const identity = "example";');
    write(
      'packages/mailbox/src/application/contracts/index.ts',
      'export interface Input { identity: string; }',
    );
    write('packages/mailbox/src/application/service.ts', "import '../domain/model';");
    write('packages/mailbox/src/adapters/outbound/index.ts', "import '../../application/service';");
    write('apps/workflow/package.json', {
      name: '@hosts/workflow',
      dependencies: { '@automation/mailbox': '0.7.0' },
      exports: {},
      architecture: {
        context: 'mailbox',
        layer: 'workflow-host',
        owner: 'mailbox',
        production: true,
      },
    });
    write('apps/workflow/src/workflows/example.ts', "import '@automation/mailbox/contracts';");
    mkdirSync(join(directory, 'test/support'), { recursive: true });
    assert.equal(
      check().status,
      0,
      'Ordinary internal folders with valid dependency direction pass',
    );
    write('test/support/package.json', {
      name: '@test/fake',
      exports: { '.': { default: './dist/index.js' } },
      architecture: { context: 'test', layer: 'test-support', owner: 'mailbox', production: false },
    });
    write(
      'packages/mailbox/src/domain/invalid.ts',
      "import '@test/fake';\nimport { readFileSync } from 'node:fs';\nfetch('https://invalid.example');\nimport '../adapters/outbound/index';\n",
    );
    write(
      'apps/workflow/src/workflows/example.ts',
      "import '@automation/mailbox/adapters/outbound';",
    );
    const result = check();
    assert.equal(result.status, 1);
    assert.match(result.stderr, /Production.*test support/);
    assert.match(result.stderr, /Node IO is forbidden/);
    assert.match(result.stderr, /External IO must go through/);
    assert.match(result.stderr, /Forbidden layer domain -> outbound-adapter/);
    assert.match(result.stderr, /Forbidden layer workflows -> outbound-adapter/);
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});
