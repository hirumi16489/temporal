import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';

test('enterprise activity host refuses missing adapters before connecting or polling', () => {
  const result = spawnSync(
    process.execPath,
    ['apps/mailbox-activity-worker/dist/main.js', 'personal'],
    {
      encoding: 'utf8',
      timeout: 10000,
      env: { ...process.env, TEMPORAL_ADDRESS: 'invalid:1' },
    },
  );
  assert.equal(result.status, 1);
  assert.match(result.stderr, /ExternalAdapterNotConfigured/);
  assert.doesNotMatch(result.stderr, /ECONNREFUSED|ENOTFOUND/);
});
