import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { once } from 'node:events';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TestWorkflowEnvironment } from '@temporalio/testing';
import { WorkflowTypes } from '@automation/mailbox/contracts';
import { WorkflowQueue } from '@automation/mailbox/execution';
import { configureScenario, example } from '@test/mailbox-support/fixtures';

test(
  'dev launcher runs separate processes, reloads capacity changes and shuts down cleanly',
  { timeout: 120_000 },
  async () => {
    const reservation = createServer();
    reservation.listen(0, '127.0.0.1');
    await once(reservation, 'listening');
    const port = (reservation.address() as any).port;
    await new Promise<void>((resolve) => reservation.close(() => resolve()));
    const viewerReservation = createServer();
    viewerReservation.listen(0, '127.0.0.1');
    await once(viewerReservation, 'listening');
    const viewerPort = (viewerReservation.address() as any).port;
    await new Promise<void>((resolve) => viewerReservation.close(() => resolve()));
    const directory = await mkdtemp(join(tmpdir(), 'mailbox-dev-test-'));
    const capacityFile = join(directory, 'capacity.json');
    const capacities = {
      personal: { concurrencyPerWorker: 4, replicas: 1 },
      standard: { concurrencyPerWorker: 2, replicas: 1 },
    };
    await writeFile(capacityFile, JSON.stringify(capacities));
    const env = await TestWorkflowEnvironment.createLocal();
    const runner = spawn(process.execPath, ['scripts/dev.mjs', '--external-temporal'], {
      env: {
        ...process.env,
        TEMPORAL_ADDRESS: env.address,
        MAILBOX_TEST_PORT: String(port),
        MAILBOX_TEST_BACKEND_URL: `http://127.0.0.1:${port}`,
        MAILBOX_TEST_STATE_FILE: join(directory, 'state.json'),
        CAPACITY_FILE: capacityFile,
        VIEWER_PORT: String(viewerPort),
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let logs = '';
    runner.stdout.on('data', (data) => {
      logs += data;
    });
    runner.stderr.on('data', (data) => {
      logs += data;
    });
    const exited = new Promise<number | null>((resolve) => runner.once('exit', resolve));
    async function waitUntil(predicate: () => boolean) {
      const deadline = Date.now() + 40_000;
      while (!predicate()) {
        if (runner.exitCode !== null || Date.now() > deadline)
          throw new Error('Dev runner readiness failed:\n' + logs);
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
    }
    try {
      await waitUntil(
        () =>
          (logs.match(/Activity worker ready/g) ?? []).length >= 2 &&
          logs.includes('Workflow worker ready'),
      );
      const first = example('PERSONAL', 'dev-first');
      await configureScenario('http://127.0.0.1:' + port, first.requestId, {
        latencyMs: 0,
        propagationMs: 0,
      });
      const result = await env.client.workflow.execute(WorkflowTypes.PERSONAL, {
        args: [first],
        taskQueue: WorkflowQueue,
        workflowId: first.requestId,
      });
      assert.equal(result.status, 'READY');
      capacities.personal.concurrencyPerWorker = 2;
      await writeFile(capacityFile, JSON.stringify(capacities));
      await waitUntil(
        () =>
          (logs.match(/Activity worker ready/g) ?? []).length >= 4 &&
          (logs.match(/Workflow worker ready/g) ?? []).length >= 2,
      );
      const second = example('ROOM', 'dev-second');
      await configureScenario('http://127.0.0.1:' + port, second.requestId, {
        latencyMs: 0,
        propagationMs: 0,
      });
      assert.equal(
        (
          await env.client.workflow.execute(WorkflowTypes.ROOM, {
            args: [second],
            taskQueue: WorkflowQueue,
            workflowId: second.requestId,
          })
        ).status,
        'READY',
      );
      runner.kill('SIGTERM');
      assert.equal(await exited, 0);
    } finally {
      runner.kill('SIGTERM');
      const timeout = setTimeout(() => runner.kill('SIGKILL'), 15_000);
      timeout.unref();
      await exited;
      clearTimeout(timeout);
      await env.teardown();
      await rm(directory, { recursive: true });
    }
  },
);
