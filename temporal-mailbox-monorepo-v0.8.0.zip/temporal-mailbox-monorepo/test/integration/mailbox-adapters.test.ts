import { test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createMailboxTestServer } from '@test/mailbox-support/simulator';
import { createMailboxTestPorts } from '@test/mailbox-support/adapters';
import { createMailboxServices } from '@automation/mailbox/application';
import { example } from '@test/mailbox-support/fixtures';
test('port-backed services converge after a committed response is lost and reject conflicting identities after restart', async () => {
  const directory = mkdtempSync(join(tmpdir(), 'mailbox-adapter-test-'));
  const path = join(directory, 'state.json');
  let server = createMailboxTestServer(path);
  async function listen() {
    server.listen(0, '127.0.0.1');
    await once(server, 'listening');
    return createMailboxServices(
      createMailboxTestPorts('http://127.0.0.1:' + (server.address() as any).port),
    );
  }
  let services = await listen();
  const request = example('PERSONAL', 'persisted');
  server.setScenario(request.requestId, {
    propagationMs: 0,
    latencyMs: 0,
    failAfterConfigurationCommit: true,
  });
  try {
    await services.provisioning.provision(request, { attempt: 1 });
    await assert.rejects(
      services.configuration.configure(request, { attempt: 1 }),
      /lost response/,
    );
    await services.configuration.configure(request, { attempt: 2 });
    await new Promise<void>((done) => server.close(() => done()));
    server = createMailboxTestServer(path);
    services = await listen();
    assert.equal((await services.readiness.check(request, { attempt: 1 })).ready, true);
    assert.equal(
      (await services.provisioning.provision(request, { attempt: 2 })).status,
      'EXISTING',
    );
    await assert.rejects(
      services.provisioning.provision({ ...request, requestId: 'other' }, { attempt: 1 }),
      /different request/,
    );
    await assert.rejects(
      services.provisioning.provision({ ...request, displayName: 'changed' }, { attempt: 1 }),
      /different request/,
    );
  } finally {
    await new Promise<void>((done) => server.close(() => done()));
    rmSync(directory, { recursive: true });
  }
});
