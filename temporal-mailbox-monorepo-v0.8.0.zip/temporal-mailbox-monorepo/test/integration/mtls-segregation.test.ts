import { test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { TestWorkflowEnvironment } from '@temporalio/testing';
import { Worker, NativeConnection } from '@temporalio/worker';
import { startAccessGateway, type AccessAudit } from '@hosts/temporal-access-gateway';
import { createSecurityCertificates, runSecurityMatrix } from '@test/mailbox-support/security';
import { createMailboxTestServer } from '@test/mailbox-support/simulator';
import { createTestMailboxActivities } from '@test/mailbox-support/adapters';
import { WorkflowQueue, resolvedPools } from '@automation/mailbox/execution';
import { validateAccessPolicy } from '@automation/temporal-platform/access';

test(
  'real mTLS gateway segregates two Temporal SDK clients and blocks credential, routing and API bypasses',
  { timeout: 120_000 },
  async () => {
    const parent = mkdtempSync(join(tmpdir(), 'mailbox-mtls-')),
      directory = join(parent, 'pki');
    const files = createSecurityCertificates(directory);
    const policy = validateAccessPolicy(JSON.parse(readFileSync(files.policyFile, 'utf8')));
    const audits: AccessAudit[] = [];
    const backend = createMailboxTestServer();
    backend.listen(0, '127.0.0.1');
    await once(backend, 'listening');
    const endpoint = 'http://127.0.0.1:' + (backend.address() as any).port;
    let env: TestWorkflowEnvironment | undefined,
      gateway: Awaited<ReturnType<typeof startAccessGateway>> | undefined;
    try {
      env = await TestWorkflowEnvironment.createLocal();
      gateway = await startAccessGateway({
        address: '127.0.0.1:0',
        backend: env.connection,
        policy,
        caFile: join(directory, 'ca.crt'),
        certificateFile: join(directory, 'server.crt'),
        privateKeyFile: join(directory, 'server.key'),
        audit: (event) => audits.push(event),
      });
      const address = '127.0.0.1:' + gateway.port;
      const workflow = await Worker.create({
        connection: env.nativeConnection,
        taskQueue: WorkflowQueue,
        workflowBundle: {
          codePath: resolve('apps/mailbox-workflow-worker/dist/workflow-bundle.js'),
        },
      });
      const personal = await Worker.create({
        connection: env.nativeConnection,
        taskQueue: resolvedPools.personal,
        activities: createTestMailboxActivities(endpoint, resolvedPools.personal),
      });
      const standard = await Worker.create({
        connection: env.nativeConnection,
        taskQueue: resolvedPools.standard,
        activities: createTestMailboxActivities(endpoint, resolvedPools.standard),
      });
      const runs = await workflow.runUntil(() =>
        personal.runUntil(() =>
          standard.runUntil(() => runSecurityMatrix(directory, address, 'default')),
        ),
      );
      assert.equal(runs.length, 2);
      const state = (await (await fetch(endpoint + '/state')).json()) as any;
      assert.equal(
        Object.keys(state.mailboxes).length,
        2,
        'Denied starts produced no mailbox side effect',
      );
      assert.ok(
        audits.some(
          (event) =>
            event.principal === 'client-a' &&
            event.method === 'StartWorkflowExecution' &&
            event.decision === 'DENY',
        ),
      );
      assert.ok(
        audits.some(
          (event) =>
            event.principal === 'client-b' &&
            event.method === 'StartWorkflowExecution' &&
            event.decision === 'DENY',
        ),
      );
      assert.ok(
        audits.some(
          (event) => event.principal === 'unrecognized-certificate' && event.decision === 'DENY',
        ),
      );
      // SDK native worker transport supports the same certificate configuration, independently of the JS client transport.
      for (const denied of audits.filter(
        (event) =>
          event.method === 'StartWorkflowExecution' &&
          event.decision === 'DENY' &&
          event.namespace === 'default',
      )) {
        await assert.rejects(
          env.client.workflow.getHandle(denied.workflowId!).describe(),
          (error: any) => error.name === 'WorkflowNotFoundError',
        );
      }
      const native = await NativeConnection.connect({
        address,
        tls: {
          serverNameOverride: 'localhost',
          serverRootCACertificate: readFileSync(join(directory, 'ca.crt')),
          clientCertPair: {
            crt: readFileSync(join(directory, 'client-a.crt')),
            key: readFileSync(join(directory, 'client-a.key')),
          },
        },
      });
      await native.close();
      console.log(
        'MTLS PROOF: two certificate identities, two allowed executions, denied starts/read/mutation attempts, and rejected missing/untrusted/unregistered certificates.',
      );
    } finally {
      await gateway?.close();
      await env?.teardown();
      backend.closeAllConnections();
      await new Promise<void>((done) => backend.close(() => done()));
      rmSync(parent, { recursive: true, force: true });
    }
  },
);
