import { test } from 'node:test';
import { pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { TestWorkflowEnvironment } from '@temporalio/testing';
import { Worker } from '@temporalio/worker';
import { WorkflowTypes } from '@automation/mailbox/contracts';
import { WorkflowQueue, resolvedPools } from '@automation/mailbox/execution';
import {
  createMailboxTestServer,
  setConfigurationPermission,
} from '@test/mailbox-support/simulator';
import { createTestMailboxActivities } from '@test/mailbox-support/adapters';
import { example } from '@test/mailbox-support/fixtures';

test(
  'failed workflow resets after a local JSON permission repair and reruns only configuration',
  { timeout: 90_000 },
  async () => {
    const directory = mkdtempSync(join(tmpdir(), 'mailbox-reset-'));
    const permissionFile = join(directory, 'permissions.json');
    const input = example('PERSONAL', randomUUID());
    const workflowId = 'mailbox-' + input.requestId;
    setConfigurationPermission(permissionFile, input.requestId, 'DENIED');
    const server = createMailboxTestServer(join(directory, 'backend.json'), {}, permissionFile);
    server.setScenario(input.requestId, { latencyMs: 0, propagationMs: 0 });
    server.listen(0, '127.0.0.1');
    await once(server, 'listening');
    const url = 'http://127.0.0.1:' + (server.address() as any).port;
    let environment: TestWorkflowEnvironment | undefined;
    try {
      environment = await TestWorkflowEnvironment.createLocal();
      const env = environment;
      const original = createTestMailboxActivities(url, resolvedPools.personal);
      const calls = { prepare: 0, provision: 0, check: 0, configure: 0 };
      const activityWorker = await Worker.create({
        connection: env.nativeConnection,
        taskQueue: resolvedPools.personal,
        activities: {
          ...original,
          prepareMailboxProvisioning: async (
            request: Parameters<typeof original.prepareMailboxProvisioning>[0],
          ) => {
            calls.prepare++;
            return original.prepareMailboxProvisioning(request);
          },
          provisionMailbox: async (request: Parameters<typeof original.provisionMailbox>[0]) => {
            calls.provision++;
            return original.provisionMailbox(request);
          },
          checkMailboxReadiness: async (
            request: Parameters<typeof original.checkMailboxReadiness>[0],
          ) => {
            calls.check++;
            return original.checkMailboxReadiness(request);
          },
          configureMailbox: async (request: Parameters<typeof original.configureMailbox>[0]) => {
            calls.configure++;
            return original.configureMailbox(request);
          },
        },
      });
      const workflowWorker = await Worker.create({
        connection: env.nativeConnection,
        taskQueue: WorkflowQueue,
        workflowBundle: {
          codePath: resolve('apps/mailbox-workflow-worker/dist/workflow-bundle.js'),
        },
      });
      await workflowWorker.runUntil(() =>
        activityWorker.runUntil(async () => {
          const handle = await env.client.workflow.start(WorkflowTypes.PERSONAL, {
            workflowId,
            taskQueue: WorkflowQueue,
            args: [input],
          });
          await assert.rejects(
            handle.result(),
            (error: any) => error.cause?.cause?.type === 'PermissionDenied',
          );
          assert.equal((await handle.describe()).status.name, 'FAILED');
          assert.deepEqual(calls, { prepare: 1, provision: 1, check: 1, configure: 1 });
          const events = (await handle.fetchHistory()).events!;
          const scheduled = events.find(
            (event) =>
              event.activityTaskScheduledEventAttributes?.activityType?.name === 'configureMailbox',
          )!;
          const resetPoint = events
            .filter(
              (event) =>
                event.workflowTaskCompletedEventAttributes &&
                Number(event.eventId) < Number(scheduled.eventId),
            )
            .at(-1)!;
          assert.ok(resetPoint);
          const repair = spawnSync(
            process.execPath,
            ['test/support/dist/runtime/repair.js', workflowId],
            {
              env: { ...process.env, MAILBOX_TEST_PERMISSIONS_FILE: permissionFile },
              encoding: 'utf8',
              timeout: 10_000,
            },
          );
          assert.equal(repair.status, 0, repair.stderr);
          assert.equal(
            JSON.parse(readFileSync(permissionFile, 'utf8')).configuration[input.requestId],
            'ALLOWED',
          );
          assert.equal(
            (await handle.describe()).status.name,
            'FAILED',
            'Repair does not restart or signal the workflow',
          );
          const beforeReset = (await (await fetch(url + '/state')).json()) as any;
          const reset = await env.client.workflowService.resetWorkflowExecution({
            namespace: 'default',
            workflowExecution: { workflowId, runId: handle.firstExecutionRunId },
            workflowTaskFinishEventId: resetPoint.eventId!,
            reason: 'Permission fixed outside Temporal',
            requestId: randomUUID(),
          });
          assert.notEqual(reset.runId, handle.firstExecutionRunId);
          const recovered = env.client.workflow.getHandle(workflowId, reset.runId);
          assert.equal(((await recovered.result()) as { status: string }).status, 'READY');
          assert.deepEqual(calls, { prepare: 1, provision: 1, check: 1, configure: 2 });
          const newHistory = await recovered.fetchHistory();
          const graphEvents = newHistory.events!.map((event) => {
            const attribute = Object.keys(event).find((key) => key.endsWith('EventAttributes'))!;
            return {
              ...JSON.parse(JSON.stringify(event)),
              eventId: String(event.eventId),
              eventType:
                'EVENT_TYPE_' +
                attribute
                  .replace('EventAttributes', '')
                  .replace(/[A-Z]/g, (char) => '_' + char)
                  .toUpperCase(),
            };
          });
          // Load the browser transformer with tsx at runtime; its own bundler tsconfig checks it.
          const { buildFixedGraph } = await import(
            pathToFileURL(resolve('apps/workflow-viewer/src/lib/fixed-graph.ts')).href
          );
          const graph = buildFixedGraph({
            events: graphEvents,
            description: {
              workflowExecutionInfo: {
                type: { name: WorkflowTypes.PERSONAL },
                status: 'COMPLETED',
              },
            },
          } as any)!;
          for (const id of ['prepare', 'provision', 'availability']) {
            assert.ok(
              graph.nodes.find((node: any) => node.id === id)?.data.reused,
              id + ' must be reused',
            );
          }
          assert.equal(
            graph.nodes.find((node: any) => node.id === 'prepare')?.data.reused.sourceRunId,
            handle.firstExecutionRunId,
          );
          assert.equal(
            graph.nodes.find((node: any) => node.id === 'configure')?.data.reused,
            undefined,
          );
          assert.equal(
            (await handle.fetchHistory()).events!.at(-1)?.workflowExecutionFailedEventAttributes !==
              undefined,
            true,
            'Original failed run history remains available after reset',
          );
          const afterReset = (await (await fetch(url + '/state')).json()) as any;
          assert.deepEqual(
            afterReset.events.slice(beforeReset.events.length).map((event: any) => event.path),
            ['/configure', '/owners'],
          );
          assert.equal(afterReset.mailboxes[input.identity].configured, true);
          assert.equal(
            afterReset.mailboxes[input.identity].appliedOwner,
            input.configuration.owner,
          );
          console.log(
            'RESET PROOF:',
            JSON.stringify({
              previousRun: handle.firstExecutionRunId,
              recoveredRun: reset.runId,
              resetEventId: String(resetPoint.eventId),
              actualActivityCalls: calls,
            }),
          );
        }),
      );
    } finally {
      await environment?.teardown();
      await new Promise<void>((done) => server.close(() => done()));
      rmSync(directory, { recursive: true, force: true });
    }
  },
);
