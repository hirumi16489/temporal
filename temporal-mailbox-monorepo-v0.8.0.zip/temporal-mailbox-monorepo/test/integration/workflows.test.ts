import { test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { resolve } from 'node:path';
import { TestWorkflowEnvironment } from '@temporalio/testing';
import { Worker } from '@temporalio/worker';
import { WorkflowTypes } from '@automation/mailbox/contracts';
import { resolvedPools, WorkflowQueue } from '@automation/mailbox/execution';
import { createTestMailboxActivities } from '@test/mailbox-support/adapters';
import { createMailboxTestServer } from '@test/mailbox-support/simulator';
import { example } from '@test/mailbox-support/fixtures';

test(
  'real Temporal executes all workflows, retries safely and reserves personal capacity during standard saturation',
  { timeout: 180_000 },
  async () => {
    let gateEnabled = false,
      arrivals = 0;
    let releaseGate!: () => void;
    let occupied!: () => void;
    const gate = new Promise<void>((resolve) => {
      releaseGate = resolve;
    });
    const standardOccupied = new Promise<void>((resolve) => {
      occupied = resolve;
    });
    const server = createMailboxTestServer(undefined, {
      async beforeOperation({ pool, path }) {
        if (gateEnabled && pool === resolvedPools.standard && path === '/mailboxes') {
          arrivals++;
          if (arrivals === 2) occupied();
          await gate;
        }
      },
    });
    server.listen(0, '127.0.0.1');
    await once(server, 'listening');
    const url = 'http://127.0.0.1:' + (server.address() as any).port;
    let env: TestWorkflowEnvironment | undefined;
    try {
      env = await TestWorkflowEnvironment.createLocal();
      const common = { connection: env.nativeConnection };
      const workflows = await Worker.create({
        ...common,
        taskQueue: WorkflowQueue,
        workflowBundle: {
          codePath: resolve('apps/mailbox-workflow-worker/dist/workflow-bundle.js'),
        },
      });
      const personal = await Worker.create({
        ...common,
        taskQueue: resolvedPools.personal,
        activities: createTestMailboxActivities(url, resolvedPools.personal),
        maxConcurrentActivityTaskExecutions: 4,
      });
      const standard = await Worker.create({
        ...common,
        taskQueue: resolvedPools.standard,
        activities: createTestMailboxActivities(url, resolvedPools.standard),
        maxConcurrentActivityTaskExecutions: 2,
      });
      await workflows.runUntil(() =>
        personal.runUntil(() =>
          standard.runUntil(async () => {
            for (const kind of ['PERSONAL', 'ROOM', 'GROUP'] as const) {
              const input = example(kind, 'test-' + kind);
              server.setScenario(input.requestId, { latencyMs: 5, propagationMs: 100 });
              const result = await env!.client.workflow.execute(WorkflowTypes[kind], {
                args: [input],
                taskQueue: WorkflowQueue,
                workflowId: input.requestId,
              });
              assert.equal(result.status, 'READY');
            }
            const retry = example('PERSONAL', 'retry');
            server.setScenario(retry.requestId, {
              latencyMs: 5,
              propagationMs: 0,
              failProvisionAttempts: 2,
            });
            await env!.client.workflow.execute(WorkflowTypes.PERSONAL, {
              args: [retry],
              taskQueue: WorkflowQueue,
              workflowId: retry.requestId,
            });
            const lost = example('PERSONAL', 'lost');
            server.setScenario(lost.requestId, {
              latencyMs: 5,
              propagationMs: 0,
              failAfterConfigurationCommit: true,
            });
            await env!.client.workflow.execute(WorkflowTypes.PERSONAL, {
              args: [lost],
              taskQueue: WorkflowQueue,
              workflowId: lost.requestId,
            });
            const failure = example('GROUP', 'failure');
            server.setScenario(failure.requestId, {
              latencyMs: 5,
              propagationMs: 0,
              failConfiguration: true,
            });
            await assert.rejects(
              env!.client.workflow.execute(WorkflowTypes.GROUP, {
                args: [failure],
                taskQueue: WorkflowQueue,
                workflowId: failure.requestId,
              }),
            );
            const status = await env!.client.workflow
              .getHandle(failure.requestId)
              .query<any>('provisioningStatus');
            assert.equal(status.phase, 'FAILED');
            assert.equal(status.groupProvisioned, true);
            let state = (await (await fetch(url + '/state')).json()) as any;
            assert.deepEqual(
              state.events
                .filter((e: any) => e.identity === retry.identity && e.path === '/mailboxes')
                .map((e: any) => e.attempt),
              [1, 2, 3],
            );
            assert.equal(
              state.events.filter(
                (e: any) => e.identity === failure.identity && e.path === '/configure',
              ).length,
              1,
            );
            assert.equal(state.mailboxes[lost.identity].configured, true);
            assert.deepEqual(state.mailboxes['test-ROOM@example.invalid'].appliedRoom, {
              location: 'Example office',
              capacity: 8,
            });
            assert.ok(state.groups[failure.group!.identity]);
            // Hold BOTH standard Activity slots at the HTTP boundary; personal must still complete.
            gateEnabled = true;
            const bulk = await Promise.all(
              [0, 1].map(async (index) => {
                const input = example('ROOM', 'saturated-' + index);
                server.setScenario(input.requestId, { latencyMs: 0, propagationMs: 0 });
                return env!.client.workflow.start(WorkflowTypes.ROOM, {
                  args: [input],
                  taskQueue: WorkflowQueue,
                  workflowId: input.requestId,
                });
              }),
            );
            const deadline = new Promise<never>((_, reject) => {
              const timer = setTimeout(
                () => reject(new Error('Standard slots did not fill')),
                10_000,
              );
              timer.unref();
            });
            await Promise.race([standardOccupied, deadline]);
            const urgent = example('PERSONAL', 'urgent');
            server.setScenario(urgent.requestId, { latencyMs: 0, propagationMs: 0 });
            const urgentResult = await env!.client.workflow.execute(WorkflowTypes.PERSONAL, {
              args: [urgent],
              taskQueue: WorkflowQueue,
              workflowId: urgent.requestId,
            });
            assert.equal(urgentResult.status, 'READY');
            state = (await (await fetch(url + '/state')).json()) as any;
            assert.equal(
              state.activeByPool[resolvedPools.standard],
              2,
              'standard slots remain occupied while urgent work completes',
            );
            assert.equal(state.mailboxes['saturated-0@example.invalid'], undefined);
            releaseGate();
            gateEnabled = false;
            await Promise.all(bulk.map((handle) => handle.result()));
            // Burst uses the same pool for every personal execution, without exceeding 4 slots.
            await Promise.all(
              Array.from({ length: 10 }, (_, index) => {
                const input = example('PERSONAL', 'burst-' + index);
                server.setScenario(input.requestId, { latencyMs: 30, propagationMs: 0 });
                return env!.client.workflow.execute(WorkflowTypes.PERSONAL, {
                  args: [input],
                  taskQueue: WorkflowQueue,
                  workflowId: input.requestId,
                });
              }),
            );
            state = (await (await fetch(url + '/state')).json()) as any;
            assert.ok(state.peakByPool[resolvedPools.personal] <= 4);
            assert.equal(state.peakByPool[resolvedPools.standard], 2);
            assert.equal(Object.keys(state.mailboxes).length, 19);
          }),
        ),
      );
    } finally {
      releaseGate();
      await env?.teardown();
      await new Promise<void>((resolve) => server.close(() => resolve()));
    }
  },
);
