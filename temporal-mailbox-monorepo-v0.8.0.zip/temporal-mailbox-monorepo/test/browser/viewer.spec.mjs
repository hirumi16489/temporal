import { test, expect } from '@playwright/test';
import { WorkflowTypes } from '@automation/mailbox/contracts';
import { WorkflowQueue } from '@automation/mailbox/execution';
import { example } from '@test/mailbox-support/fixtures';
import { viewerFixture } from '../viewer/fixture.mjs';
test('browser follows real execution, pauses/resumes, updates selected activity payloads and stops polling when closed', async ({
  page,
}, testInfo) => {
  let releaseProvision;
  const provisionGate = new Promise((done) => {
    releaseProvision = done;
  });
  const fixture = await viewerFixture({
    hooks: {
      async beforeOperation({ path }) {
        if (path === '/mailboxes') await provisionGate;
      },
    },
  });
  const { env, viewerUrl } = fixture;
  try {
    const input = example('GROUP', 'browser-live');
    fixture.backend.setScenario(input.requestId, {
      propagationMs: 6000,
      latencyMs: 1600,
      failProvisionAttempts: 1,
    });
    const handle = await env.client.workflow.start(WorkflowTypes.GROUP, {
      args: [input],
      taskQueue: WorkflowQueue,
      workflowId: 'mailbox-' + input.requestId,
    });
    let requests = 0;
    const errors = [];
    page.on('pageerror', (error) => errors.push(error.message));
    page.on('request', (request) => {
      if (request.url().includes('/api/workflow?')) requests++;
    });
    await page.goto(viewerUrl);
    await expect(page.getByText(handle.workflowId, { exact: true })).toBeVisible();
    await page.getByText(handle.workflowId, { exact: true }).click();
    await expect(page.getByTestId('workflow-status')).toHaveText('RUNNING');
    await expect(page.locator('.react-flow__node')).toHaveCount(7);
    const provision = page.locator('.react-flow__node').filter({ hasText: 'provisionMailbox' });
    await expect(provision).toBeVisible();
    await provision.click();
    await expect(page.getByTestId('node-details')).toContainText('browser-live@example.invalid');
    await expect(page.getByTestId('node-details')).toContainText('Waiting for completion');
    releaseProvision();
    await expect(page.getByTestId('node-details')).toContainText('CREATED');
    await page.getByRole('button', { name: 'Close', exact: true }).click();
    await page.getByRole('button', { name: 'Pause live' }).click();
    await page.waitForTimeout(350);
    const paused = requests;
    await page.waitForTimeout(2400);
    expect(requests).toBe(paused);
    await page.getByRole('button', { name: 'Resume live' }).click();
    await expect(page.getByTestId('workflow-status')).toHaveText('COMPLETED');
    expect((await handle.result()).status).toBe('READY');
    const configuration = page.locator('.react-flow__node').filter({ hasText: 'configureMailbox' });
    const group = page
      .locator('.react-flow__node')
      .filter({ hasText: 'provisionMailboxDistributionGroup' });
    await expect(configuration).toBeVisible();
    await expect(group).toBeVisible();
    const configurationId = await configuration.getAttribute('data-id'),
      groupId = await group.getAttribute('data-id');
    await expect(page.locator(`[data-id="e-${configurationId}-${groupId}"]`)).toHaveCount(0);
    await configuration.click();
    await expect(page.getByTestId('node-details')).toContainText('demo-owner');
    await expect(page.getByTestId('node-details')).toContainText('CONFIGURED');
    await page.getByRole('button', { name: 'Close', exact: true }).click();
    await expect(page.locator('.react-flow__node')).toHaveCount(7);
    const completed = requests;
    await page.waitForTimeout(4500);
    expect(requests).toBe(completed);
    expect(errors).toEqual([]);
    await page.screenshot({ path: testInfo.outputPath('completed-graph.png'), fullPage: true });
    // Read-only viewer does not expose mutation endpoints.
    expect((await page.request.post(viewerUrl + '/api/workflow')).status()).toBe(405);
  } finally {
    releaseProvision();
    await fixture.close();
  }
});
