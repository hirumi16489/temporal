import { once } from 'node:events';
import { createServer } from 'node:net';
import { resolve } from 'node:path';
import { TestWorkflowEnvironment } from '@temporalio/testing';
import { Worker } from '@temporalio/worker';
import { WorkflowQueue, resolvedPools } from '@automation/mailbox/execution';
import { createTestMailboxActivities } from '@test/mailbox-support/adapters';
import { createMailboxTestServer } from '@test/mailbox-support/simulator';
import { createViewerServer } from '../../apps/workflow-viewer/server-lib.mjs';

export async function freePort() {
  const server = createServer();
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const port = server.address().port;
  await new Promise((done) => server.close(done));
  return port;
}
export async function viewerFixture({ hooks, viewerPort = 0 } = {}) {
  const uiPort = await freePort();
  const env = await TestWorkflowEnvironment.createLocal({ server: { uiPort, ui: true } });
  for (let i = 0; i < 100; i++) {
    try {
      if ((await fetch(`http://127.0.0.1:${uiPort}/api/v1/namespaces/default`)).ok) break;
    } catch {
      /* UI may still be starting. */
    }
    if (i === 99) {
      await env.teardown();
      throw new Error('Temporal UI not ready');
    }
    await new Promise((done) => setTimeout(done, 100));
  }
  const backend = createMailboxTestServer(undefined, hooks);
  backend.listen(0, '127.0.0.1');
  await once(backend, 'listening');
  const backendUrl = 'http://127.0.0.1:' + backend.address().port;
  const viewer = createViewerServer({ endpoint: `http://127.0.0.1:${uiPort}` });
  viewer.listen(viewerPort, '127.0.0.1');
  await once(viewer, 'listening');
  const viewerUrl = 'http://127.0.0.1:' + viewer.address().port;
  const workers = [],
    running = [];
  async function close() {
    for (const worker of workers) worker.shutdown();
    await Promise.allSettled(running);
    viewer.closeAllConnections();
    await new Promise((done) => viewer.close(done));
    backend.closeAllConnections();
    await new Promise((done) => backend.close(done));
    await env.teardown();
  }
  try {
    workers.push(
      await Worker.create({
        connection: env.nativeConnection,
        taskQueue: WorkflowQueue,
        workflowBundle: {
          codePath: resolve('apps/mailbox-workflow-worker/dist/workflow-bundle.js'),
        },
      }),
    );
    for (const profile of ['standard', 'personal'])
      workers.push(
        await Worker.create({
          connection: env.nativeConnection,
          taskQueue: resolvedPools[profile],
          activities: createTestMailboxActivities(backendUrl, resolvedPools[profile]),
          maxConcurrentActivityTaskExecutions: profile === 'standard' ? 2 : 4,
        }),
      );
    for (const worker of workers) running.push(worker.run());
    return { env, backend, viewer, viewerUrl, close };
  } catch (error) {
    await close();
    throw error;
  }
}
