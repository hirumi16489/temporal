import { test } from 'node:test';
import assert from 'node:assert/strict';
import { WorkflowTypes } from '@automation/mailbox/contracts';
import { WorkflowDiagrams } from '@automation/mailbox/diagrams';
import { buildFixedGraph } from '../../apps/workflow-viewer/src/lib/fixed-graph.ts';
import { liveInterval, workflowStatus } from '../../apps/workflow-viewer/src/lib/live.ts';
import { inspectPayloads } from '../../apps/workflow-viewer/src/lib/payloads.ts';
const payload = (value) => ({
  metadata: { encoding: Buffer.from('json/plain').toString('base64') },
  data: Buffer.from(JSON.stringify(value)).toString('base64'),
});
const event = (id, eventType, attr, data = {}) => ({
  eventId: String(id),
  eventType: 'EVENT_TYPE_' + eventType,
  eventTime: new Date(1700000000000 + id * 100).toISOString(),
  ...(attr ? { [attr]: data } : {}),
});
const start = event(1, 'WORKFLOW_EXECUTION_STARTED', 'workflowExecutionStartedEventAttributes', {
  workflowType: { name: WorkflowTypes.GROUP },
});
const scheduled = (id, name, activityId = String(id)) =>
  event(id, 'ACTIVITY_TASK_SCHEDULED', 'activityTaskScheduledEventAttributes', {
    activityId,
    activityType: { name },
    input: { payloads: [payload('demo@example.invalid')] },
  });
const completed = (id, scheduledEventId, result) =>
  event(id, 'ACTIVITY_TASK_COMPLETED', 'activityTaskCompletedEventAttributes', {
    scheduledEventId: String(scheduledEventId),
    result: {
      payloads: [
        payload(
          typeof result === 'boolean'
            ? { identity: 'demo@example.invalid', ready: result }
            : result,
        ),
      ],
    },
  });
const snapshot = (
  events,
  pendingActivities = [],
  status = 'RUNNING',
  name = WorkflowTypes.GROUP,
) => ({
  events,
  description: {
    workflowExecutionInfo: { type: { name }, status: 'WORKFLOW_EXECUTION_STATUS_' + status },
    pendingActivities,
  },
});
const topology = (graph) => ({
  nodes: graph.nodes.map(({ id, position }) => ({ id, position })),
  edges: graph.edges.map(({ source, target }) => ({ source, target })),
});
test('all three workflows have complete fixed graphs before any activity runs, including the group split/join', () => {
  for (const name of Object.values(WorkflowTypes)) {
    const graph = buildFixedGraph(snapshot([], [], 'RUNNING', name));
    assert.equal(graph.nodes.length, name === WorkflowTypes.GROUP ? 7 : 6);
    assert.ok(graph.nodes.every((node) => node.data.status === 'idle'));
  }
  const group = buildFixedGraph(snapshot([]));
  assert.ok(
    group.edges.some((edge) => edge.source === 'availability' && edge.target === 'configure'),
  );
  assert.ok(group.edges.some((edge) => edge.source === 'availability' && edge.target === 'group'));
  assert.ok(group.edges.some((edge) => edge.source === 'configure' && edge.target === 'finish'));
  assert.ok(group.edges.some((edge) => edge.source === 'group' && edge.target === 'finish'));
  assert.ok(!group.edges.some((edge) => edge.source === 'configure' && edge.target === 'group'));
  assert.equal(Object.keys(WorkflowDiagrams).length, 3);
});
test('many availability checks and durable timers update one node without moving or growing the graph', () => {
  const original = buildFixedGraph(snapshot([start]));
  const events = [start, scheduled(2, 'provisionMailbox'), completed(3, 2, { status: 'CREATED' })];
  for (let i = 0; i < 12; i++) {
    const id = 4 + i * 4;
    events.push(scheduled(id, 'checkMailboxReadiness'), completed(id + 1, id, false));
    events.push(
      event(id + 2, 'TIMER_STARTED', 'timerStartedEventAttributes', { timerId: 'wait-' + i }),
      event(id + 3, 'TIMER_FIRED', 'timerFiredEventAttributes', { startedEventId: String(id + 2) }),
    );
    const graph = buildFixedGraph(snapshot(events));
    assert.deepEqual(topology(graph), topology(original));
    assert.equal(graph.nodes.find((node) => node.id === 'availability').data.status, 'waiting');
    assert.equal(graph.nodes.find((node) => node.id === 'availability').data.checkCount, i + 1);
    assert.equal(graph.nodes.find((node) => node.id === 'configure').data.status, 'idle');
  }
  events.push(scheduled(60, 'checkMailboxReadiness'), completed(61, 60, true));
  const graph = buildFixedGraph(snapshot(events));
  const wait = graph.nodes.find((node) => node.id === 'availability');
  assert.equal(wait.data.status, 'completed');
  assert.deepEqual(inspectPayloads(wait.data.rawEvents).output, [
    { identity: 'demo@example.invalid', ready: true },
  ]);
  assert.equal(
    wait.data.rawEvents.filter((event) => event.eventType.endsWith('TIMER_STARTED')).length,
    12,
  );
  assert.deepEqual(topology(graph), topology(original));
});
test('retries, final failure and unvisited steps change state in place; unrelated branch can succeed', () => {
  const events = [start, scheduled(2, 'provisionMailbox', 'provision')];
  const initial = buildFixedGraph(snapshot(events));
  const retry = buildFixedGraph(
    snapshot(events, [
      {
        activityId: 'provision',
        state: 'PENDING_ACTIVITY_STATE_SCHEDULED',
        attempt: 2,
        lastFailure: { message: 'Network unavailable' },
      },
    ]),
  );
  assert.equal(retry.nodes.find((node) => node.id === 'provision').data.status, 'retrying');
  assert.equal(retry.nodes.find((node) => node.id === 'provision').data.attempt, 2);
  assert.deepEqual(topology(retry), topology(initial));
  const running = buildFixedGraph(
    snapshot(events, [
      {
        activityId: 'provision',
        state: 'PENDING_ACTIVITY_STATE_STARTED',
        attempt: 2,
        lastFailure: { message: 'Network unavailable' },
      },
    ]),
  );
  assert.equal(running.nodes.find((node) => node.id === 'provision').data.status, 'running');
  const failed = buildFixedGraph(
    snapshot([
      ...events,
      event(3, 'ACTIVITY_TASK_FAILED', 'activityTaskFailedEventAttributes', {
        scheduledEventId: '2',
        failure: { message: 'Denied' },
      }),
      event(4, 'WORKFLOW_EXECUTION_FAILED', 'workflowExecutionFailedEventAttributes', {
        failure: { message: 'Denied' },
      }),
    ]),
  );
  assert.equal(failed.nodes.find((node) => node.id === 'provision').data.status, 'failed');
  assert.equal(failed.nodes.find((node) => node.id === 'configure').data.status, 'not-run');
  assert.equal(failed.nodes.find((node) => node.id === 'finish').data.status, 'failed');
  assert.deepEqual(topology(failed), topology(initial));
  const parallel = buildFixedGraph(
    snapshot([
      start,
      scheduled(2, 'configureMailbox'),
      event(3, 'ACTIVITY_TASK_FAILED', 'activityTaskFailedEventAttributes', {
        scheduledEventId: '2',
      }),
      scheduled(4, 'provisionMailboxDistributionGroup'),
      completed(5, 4, { status: 'CREATED' }),
      event(6, 'WORKFLOW_EXECUTION_FAILED'),
    ]),
  );
  assert.equal(parallel.nodes.find((node) => node.id === 'configure').data.status, 'failed');
  assert.equal(parallel.nodes.find((node) => node.id === 'group').data.status, 'completed');
});
test('terminal history wins over stale Describe and an exhausted availability loop fails its wait step', () => {
  const events = [
    start,
    scheduled(2, 'checkMailboxReadiness'),
    completed(3, 2, false),
    event(4, 'WORKFLOW_EXECUTION_FAILED', 'workflowExecutionFailedEventAttributes', {
      failure: { message: 'Availability timeout' },
    }),
  ];
  const data = snapshot(events, [], 'RUNNING');
  assert.equal(workflowStatus(data), 'FAILED');
  assert.equal(liveInterval(data), false);
  assert.equal(
    buildFixedGraph(data).nodes.find((node) => node.id === 'availability').data.status,
    'failed',
  );
  assert.equal(
    buildFixedGraph(data).nodes.find((node) => node.id === 'finish').data.status,
    'failed',
  );
  const drift = buildFixedGraph(snapshot([start, scheduled(9, 'unknownFutureOperation')]));
  assert.deepEqual(drift.unmapped, ['unknownFutureOperation']);
  assert.equal(buildFixedGraph(snapshot([], [], 'RUNNING', 'unregisteredWorkflow')), undefined);
  assert.equal(buildFixedGraph(snapshot([], [], 'RUNNING', 'constructor')), undefined);
});

test('reset marks only successful results retained before the latest fork as reused', () => {
  const events = [
    start,
    scheduled(2, 'provisionMailbox'),
    completed(3, 2, { status: 'CREATED' }),
    scheduled(4, 'checkMailboxReadiness'),
    completed(5, 4, true),
    // An in-flight configuration was scheduled before reset but finishes in the new run.
    scheduled(6, 'configureMailbox'),
    event(7, 'WORKFLOW_TASK_FAILED', 'workflowTaskFailedEventAttributes', {
      cause: 'WORKFLOW_TASK_FAILED_CAUSE_RESET_WORKFLOW',
      baseRunId: 'failed-run',
    }),
    completed(8, 6, { status: 'CONFIGURED' }),
  ];
  const graph = buildFixedGraph(snapshot(events));
  for (const id of ['provision', 'availability']) {
    const node = graph.nodes.find((node) => node.id === id);
    assert.equal(node.data.status, 'completed');
    assert.deepEqual(node.data.reused, { sourceRunId: 'failed-run', resetEventId: '7' });
  }
  assert.equal(graph.nodes.find((node) => node.id === 'configure').data.reused, undefined);
  assert.equal(graph.nodes.find((node) => node.id === 'start').data.reused, undefined);
  assert.ok(
    buildFixedGraph(snapshot(events.filter((event) => event.eventId !== '7'))).nodes.every(
      (node) => !node.data.reused,
    ),
    'Ordinary successful execution has no reuse badge',
  );
  const secondReset = [
    ...events,
    event(9, 'WORKFLOW_TASK_FAILED', 'workflowTaskFailedEventAttributes', {
      cause: 20,
      baseRunId: 'second-run',
    }),
  ];
  assert.equal(
    buildFixedGraph(snapshot(secondReset)).nodes.find((node) => node.id === 'configure').data.reused
      .sourceRunId,
    'second-run',
  );
  const unrelatedFailure = events.map((item) =>
    item.eventId === '7'
      ? event(7, 'WORKFLOW_TASK_FAILED', 'workflowTaskFailedEventAttributes', {
          cause: 'WORKFLOW_TASK_FAILED_CAUSE_NON_DETERMINISTIC_ERROR',
        })
      : item,
  );
  assert.ok(buildFixedGraph(snapshot(unrelatedFailure)).nodes.every((node) => !node.data.reused));
});
