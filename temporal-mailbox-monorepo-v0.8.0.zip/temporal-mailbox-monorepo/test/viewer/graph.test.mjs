import { test } from 'node:test';
import assert from 'node:assert/strict';
import { transformEventsToGraph } from '../../apps/workflow-viewer/src/lib/graph-transformer.ts';
import { liveInterval } from '../../apps/workflow-viewer/src/lib/live.ts';
import { decodePayload } from '../../apps/workflow-viewer/src/lib/payloads.ts';
const event = (id, eventType, attribute, data = {}) => ({
  eventId: String(id),
  eventTime: new Date(1700000000000 + id * 100).toISOString(),
  eventType,
  ...(attribute ? { [attribute]: data } : {}),
});
test('history batches preserve parallel activities and recognize timed-out and pending activities', () => {
  const events = [
    event(1, 'WORKFLOW_EXECUTION_STARTED', 'workflowExecutionStartedEventAttributes', {
      workflowType: { name: 'Group' },
    }),
    event(2, 'WORKFLOW_TASK_STARTED'),
    event(3, 'WORKFLOW_TASK_COMPLETED', 'workflowTaskCompletedEventAttributes', {
      startedEventId: '2',
    }),
    event(4, 'ACTIVITY_TASK_SCHEDULED', 'activityTaskScheduledEventAttributes', {
      activityId: 'prepare',
      workflowTaskCompletedEventId: '3',
      activityType: { name: 'prepare' },
    }),
    event(5, 'ACTIVITY_TASK_COMPLETED', 'activityTaskCompletedEventAttributes', {
      scheduledEventId: '4',
    }),
    event(6, 'WORKFLOW_TASK_STARTED'),
    event(7, 'WORKFLOW_TASK_COMPLETED', 'workflowTaskCompletedEventAttributes', {
      startedEventId: '6',
    }),
    event(8, 'ACTIVITY_TASK_SCHEDULED', 'activityTaskScheduledEventAttributes', {
      activityId: 'configure',
      workflowTaskCompletedEventId: '7',
      activityType: { name: 'configure' },
    }),
    event(9, 'ACTIVITY_TASK_SCHEDULED', 'activityTaskScheduledEventAttributes', {
      activityId: 'group',
      workflowTaskCompletedEventId: '7',
      activityType: { name: 'group' },
    }),
    event(10, 'ACTIVITY_TASK_TIMED_OUT', 'activityTaskTimedOutEventAttributes', {
      scheduledEventId: '8',
      failure: { message: 'timeout' },
    }),
  ];
  const { nodes, edges } = transformEventsToGraph(events, [
    { activityId: 'group', state: 'ACTIVITY_STATE_STARTED', attempt: 2 },
  ]);
  assert.ok(edges.some((e) => e.source === 'activity-4' && e.target === 'activity-8'));
  assert.ok(edges.some((e) => e.source === 'activity-4' && e.target === 'activity-9'));
  assert.ok(!edges.some((e) => e.source === 'activity-8' && e.target === 'activity-9'));
  assert.equal(nodes.find((n) => n.id === 'activity-8').data.status, 'failed');
  assert.equal(nodes.find((n) => n.id === 'activity-9').data.status, 'running');
  assert.equal(nodes.find((n) => n.id === 'activity-9').data.attempt, 2);
});
test('live polling pauses and stops for every terminal status, retaining polling while a run is active', () => {
  const snapshot = (status) => ({ events: [], description: { workflowExecutionInfo: { status } } });
  assert.equal(liveInterval(snapshot('WORKFLOW_EXECUTION_STATUS_RUNNING')), 2000);
  assert.equal(liveInterval(snapshot('RUNNING'), false), false);
  for (const status of [
    'COMPLETED',
    'FAILED',
    'CANCELED',
    'TERMINATED',
    'TIMED_OUT',
    'CONTINUED_AS_NEW',
    2,
    3,
  ])
    assert.equal(liveInterval(snapshot(status)), false);
});
test('payloads decode default JSON without losing custom encoded payloads', () => {
  const metadata = { encoding: Buffer.from('json/plain').toString('base64') };
  assert.deepEqual(
    decodePayload({
      metadata,
      data: Buffer.from('{"owner":"demo","capacity":8}').toString('base64'),
    }),
    { owner: 'demo', capacity: 8 },
  );
  assert.equal(
    decodePayload({ metadata: { encoding: Buffer.from('binary/null').toString('base64') } }),
    null,
  );
  assert.equal(
    decodePayload({
      metadata: { encoding: Buffer.from('binary/encrypted').toString('base64') },
      data: 'AAAA',
    }).base64,
    'AAAA',
  );
});
