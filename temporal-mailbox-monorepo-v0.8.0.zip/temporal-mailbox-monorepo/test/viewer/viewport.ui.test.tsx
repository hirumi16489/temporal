import React, { useEffect } from 'react';
import { test, expect, vi, afterEach } from 'vitest';
import { render, waitFor, cleanup } from '@testing-library/react';
import { WorkflowGraph } from '../../apps/workflow-viewer/src/components/workflow/WorkflowGraph';
const { fitView } = vi.hoisted(() => ({ fitView: vi.fn() }));
vi.mock('reactflow', () => ({
  default: ({ onInit }: any) => {
    useEffect(() => {
      onInit({ fitView });
    }, [onInit]);
    return <div>Canvas</div>;
  },
  Background: () => null,
  Controls: () => null,
  MiniMap: () => null,
  Handle: () => null,
  Position: { Top: 'top', Bottom: 'bottom' },
}));
afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  fitView.mockClear();
});
test('status refreshes preserve the viewport instead of repeatedly fitting or moving it', async () => {
  vi.stubGlobal('requestAnimationFrame', (callback: () => void) => setTimeout(callback, 0));
  vi.stubGlobal('cancelAnimationFrame', (id: ReturnType<typeof setTimeout>) => clearTimeout(id));
  const node = { id: 'provision', position: { x: 200, y: 280 }, data: { status: 'idle' } };
  const { rerender } = render(<WorkflowGraph nodes={[node]} edges={[]} onNodeClick={() => {}} />);
  await waitFor(() => expect(fitView).toHaveBeenCalledTimes(1));
  for (const status of ['running', 'retrying', 'completed'])
    rerender(
      <WorkflowGraph nodes={[{ ...node, data: { status } }]} edges={[]} onNodeClick={() => {}} />,
    );
  await new Promise((done) => setTimeout(done, 30));
  expect(fitView).toHaveBeenCalledTimes(1);
});
