import React from 'react';
import { afterEach, expect, test, vi } from 'vitest';
import { render, screen, waitFor, cleanup } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import WorkflowDetail from '../../apps/workflow-viewer/src/pages/WorkflowDetail';
// Canvas geometry needs a real browser. Exercise the actual detail page and polling here
// with only its graph drawing replaced by selectable nodes; graph edges have separate tests.
vi.mock('../../apps/workflow-viewer/src/components/workflow/WorkflowGraph', () => ({
  WorkflowGraph: ({ nodes, onNodeClick }: any) => (
    <div>
      {nodes.map((node: any) => (
        <button key={node.id} onClick={() => onNodeClick({}, node)}>
          {node.data.label}
        </button>
      ))}
    </div>
  ),
}));
const payload = (data: unknown) => ({
  metadata: { encoding: btoa('json/plain') },
  data: btoa(JSON.stringify(data)),
});
const event = (id: number, eventType: string, attribute?: string, data: unknown = {}) => ({
  eventId: String(id),
  eventType,
  eventTime: new Date(1700000000000 + id * 100).toISOString(),
  ...(attribute ? { [attribute]: data } : {}),
});
const clients: QueryClient[] = [];
afterEach(() => {
  cleanup();
  for (const client of clients) client.clear();
  clients.length = 0;
  vi.unstubAllGlobals();
});
test('detail view updates selected input/output live, supports pause/resume, and stops fetching after completion', async () => {
  const events = [
    event(1, 'EVENT_TYPE_WORKFLOW_EXECUTION_STARTED', 'workflowExecutionStartedEventAttributes', {
      workflowType: { name: 'provisionPersonalMailboxWorkflow' },
    }),
    event(2, 'EVENT_TYPE_WORKFLOW_TASK_STARTED'),
    event(3, 'EVENT_TYPE_WORKFLOW_TASK_COMPLETED', 'workflowTaskCompletedEventAttributes', {
      startedEventId: '2',
    }),
    event(4, 'EVENT_TYPE_ACTIVITY_TASK_SCHEDULED', 'activityTaskScheduledEventAttributes', {
      activityId: 'activity',
      activityType: { name: 'provisionMailbox' },
      workflowTaskCompletedEventId: '3',
      input: { payloads: [payload({ identity: 'demo@example.invalid' })] },
    }),
  ];
  let snapshot: any = {
    events,
    description: {
      workflowExecutionInfo: { status: 'WORKFLOW_EXECUTION_STATUS_RUNNING' },
      pendingActivities: [{ activityId: 'activity', state: 'PENDING_ACTIVITY_STATE_STARTED' }],
    },
  };
  let unavailable = false;
  const fetcher = vi.fn(async () =>
    unavailable
      ? Response.json({ error: 'Backend temporarily unavailable' }, { status: 502 })
      : Response.json(snapshot),
  );
  vi.stubGlobal('fetch', fetcher);
  const client = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: 0 } } });
  clients.push(client);
  render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={['/workflow/default/demo/run']}>
        <Routes>
          <Route path="/workflow/:namespace/:workflowId/:runId" element={<WorkflowDetail />} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>,
  );
  const user = userEvent.setup();
  await screen.findByRole('button', { name: 'Configure mailbox' });
  expect(screen.getByRole('button', { name: 'Wait for mailbox availability' })).toBeTruthy();
  await user.click(await screen.findByRole('button', { name: 'Provision mailbox' }));
  expect(screen.getByTestId('node-details').textContent).toContain('demo@example.invalid');
  expect(screen.getByTestId('node-details').textContent).toContain('Waiting for completion');
  snapshot = {
    ...snapshot,
    events: [
      ...events,
      event(5, 'EVENT_TYPE_ACTIVITY_TASK_COMPLETED', 'activityTaskCompletedEventAttributes', {
        scheduledEventId: '4',
        result: { payloads: [payload({ status: 'CREATED' })] },
      }),
    ],
  };
  await waitFor(() => expect(screen.getByTestId('node-details').textContent).toContain('CREATED'), {
    timeout: 5000,
  });
  await user.click(screen.getByRole('button', { name: 'Close' }));
  await user.click(screen.getByRole('button', { name: 'Pause live' }));
  const paused = fetcher.mock.calls.length;
  await new Promise((done) => setTimeout(done, 2300));
  expect(fetcher.mock.calls.length).toBe(paused);
  snapshot = {
    events: [...snapshot.events, event(6, 'EVENT_TYPE_WORKFLOW_EXECUTION_COMPLETED')],
    description: { workflowExecutionInfo: { status: 'WORKFLOW_EXECUTION_STATUS_COMPLETED' } },
  };
  unavailable = true;
  await user.click(screen.getByRole('button', { name: 'Resume live' }));
  await screen.findByRole('alert', {}, { timeout: 5000 });
  expect(screen.getByRole('button', { name: 'Provision mailbox' })).toBeTruthy();
  unavailable = false;
  await waitFor(() => expect(screen.getByTestId('workflow-status').textContent).toBe('COMPLETED'), {
    timeout: 5000,
  });
  const finished = fetcher.mock.calls.length;
  await new Promise((done) => setTimeout(done, 2300));
  expect(fetcher.mock.calls.length).toBe(finished);
  expect(
    screen.getByRole('button', { name: 'Finished · refresh stopped' }).hasAttribute('disabled'),
  ).toBe(true);
});

test('reused activity details explain replay and link to the source run', async () => {
  const snapshot = {
    events: [
      event(1, 'EVENT_TYPE_WORKFLOW_EXECUTION_STARTED', 'workflowExecutionStartedEventAttributes', {
        workflowType: { name: 'provisionPersonalMailboxWorkflow' },
      }),
      event(2, 'EVENT_TYPE_ACTIVITY_TASK_SCHEDULED', 'activityTaskScheduledEventAttributes', {
        activityId: 'prepare',
        activityType: { name: 'prepareMailboxProvisioning' },
      }),
      event(3, 'EVENT_TYPE_ACTIVITY_TASK_COMPLETED', 'activityTaskCompletedEventAttributes', {
        scheduledEventId: '2',
        result: { payloads: [payload({ identity: 'retained@example.invalid' })] },
      }),
      event(4, 'EVENT_TYPE_WORKFLOW_TASK_FAILED', 'workflowTaskFailedEventAttributes', {
        cause: 'WORKFLOW_TASK_FAILED_CAUSE_RESET_WORKFLOW',
        baseRunId: 'original-failed-run',
      }),
    ],
    description: { workflowExecutionInfo: { status: 'COMPLETED' } },
  };
  vi.stubGlobal(
    'fetch',
    vi.fn(async () => Response.json(snapshot)),
  );
  const client = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: 0 } } });
  clients.push(client);
  render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={['/workflow/default/demo/new-run']}>
        <Routes>
          <Route path="/workflow/:namespace/:workflowId/:runId" element={<WorkflowDetail />} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>,
  );
  await userEvent
    .setup()
    .click(await screen.findByRole('button', { name: 'Prepare provisioning' }));
  expect(screen.getByTestId('reused-result').textContent).toContain('did not execute again');
  expect(screen.getByRole('link', { name: 'original-failed-run' }).getAttribute('href')).toBe(
    '/workflow/default/demo/original-failed-run',
  );
  expect(screen.getByTestId('node-details').textContent).toContain('retained@example.invalid');
});
