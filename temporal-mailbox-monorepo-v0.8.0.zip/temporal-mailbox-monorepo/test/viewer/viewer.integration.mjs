import { test } from 'node:test';
import assert from 'node:assert/strict';
import { WorkflowQueue } from '@automation/mailbox/execution';
import { WorkflowTypes } from '@automation/mailbox/contracts';
import { example } from '@test/mailbox-support/fixtures';
import { buildFixedGraph } from '../../apps/workflow-viewer/src/lib/fixed-graph.ts';
import { viewerFixture } from './fixture.mjs';
test(
  'web viewer serves built assets and exposes real running activity input/output and terminal history',
  { timeout: 90_000 },
  async () => {
    let release;
    const gate = new Promise((done) => {
      release = done;
    });
    const fixture = await viewerFixture({
      hooks: {
        async beforeOperation({ path }) {
          if (path === '/mailboxes') await gate;
        },
      },
    });
    try {
      assert.match(await (await fetch(fixture.viewerUrl)).text(), /Temporal execution viewer/);
      const input = example('GROUP', 'viewer-integration');
      fixture.backend.setScenario(input.requestId, {
        latencyMs: 100,
        propagationMs: 0,
        failProvisionAttempts: 1,
      });
      const handle = await fixture.env.client.workflow.start(WorkflowTypes.GROUP, {
        args: [input],
        workflowId: 'mailbox-viewer-integration',
        taskQueue: WorkflowQueue,
      });
      const endpoint =
        fixture.viewerUrl +
        '/api/workflow?' +
        new URLSearchParams({
          namespace: 'default',
          id: handle.workflowId,
          runId: handle.firstExecutionRunId,
        });
      let snapshot;
      for (let i = 0; i < 50; i++) {
        const response = await fetch(endpoint);
        assert.equal(response.status, 200, await response.clone().text());
        snapshot = await response.json();
        if (snapshot.description.pendingActivities?.length) break;
        await new Promise((done) => setTimeout(done, 100));
      }
      assert.match(snapshot.description.workflowExecutionInfo.status, /RUNNING/);
      const scheduled = snapshot.events.find(
        (event) =>
          event.activityTaskScheduledEventAttributes?.activityType?.name === 'provisionMailbox',
      );
      assert.ok(scheduled?.activityTaskScheduledEventAttributes.input.payloads.length);
      const initialGraph = buildFixedGraph(snapshot);
      assert.equal(initialGraph.nodes.length, 7);
      assert.equal(initialGraph.nodes.find((node) => node.id === 'configure').data.status, 'idle');
      release();
      let retrySeen = false;
      for (let i = 0; i < 100; i++) {
        const retrySnapshot = await (await fetch(endpoint)).json();
        const node = buildFixedGraph(retrySnapshot).nodes.find((node) => node.id === 'provision');
        if (node.data.status === 'retrying') {
          retrySeen = true;
          break;
        }
        await new Promise((done) => setTimeout(done, 40));
      }
      assert.ok(
        retrySeen,
        'Transient Activity failure must appear as retrying on the existing provision node',
      );
      assert.equal((await handle.result()).status, 'READY');
      snapshot = await (await fetch(endpoint)).json();
      assert.match(snapshot.description.workflowExecutionInfo.status, /COMPLETED/);
      const finalGraph = buildFixedGraph(snapshot);
      assert.equal(finalGraph.nodes.length, initialGraph.nodes.length);
      assert.ok(finalGraph.nodes.every((node) => node.data.status === 'completed'));
      assert.deepEqual(
        finalGraph.nodes.map(({ id, position }) => ({ id, position })),
        initialGraph.nodes.map(({ id, position }) => ({ id, position })),
      );
      assert.deepEqual(finalGraph.unmapped, []);
      assert.ok(
        snapshot.events.some(
          (event) => event.workflowExecutionCompletedEventAttributes?.result?.payloads?.length,
        ),
      );
      const completed = snapshot.events.find(
        (event) =>
          String(event.activityTaskCompletedEventAttributes?.scheduledEventId) ===
          String(scheduled.eventId),
      );
      assert.ok(completed?.activityTaskCompletedEventAttributes.result.payloads.length);
      assert.equal(
        (
          await fetch(
            fixture.viewerUrl +
              '/api/search?' +
              new URLSearchParams({
                namespace: 'default',
                query: "WorkflowId = 'mailbox-viewer-integration'",
              }),
          )
        ).status,
        200,
      );
    } finally {
      release();
      await fixture.close();
    }
  },
);
