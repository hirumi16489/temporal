import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { once } from 'node:events';
import { mkdtemp, readdir, stat, rm, mkdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TestWorkflowEnvironment } from '@temporalio/testing';
import { Client, Connection } from '@temporalio/client';
import { WorkflowTypes } from '@automation/mailbox/contracts';
import { WorkflowQueue } from '@automation/mailbox/execution';
import { configureScenario, example } from '@test/mailbox-support/fixtures';

async function freePort() {
  const server = createServer();
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const port = server.address().port;
  await new Promise((done) => server.close(done));
  return port;
}

test(
  'normal launcher owns a native server and preserves completed execution history across restart',
  { timeout: 180_000 },
  async () => {
    const directory = await mkdtemp(join(tmpdir(), 'mailbox-native-'));
    let runner,
      exited,
      logs = '',
      connection;
    async function stop() {
      if (!runner || runner.exitCode !== null) return;
      runner.kill('SIGTERM');
      const timeout = setTimeout(() => runner.kill('SIGKILL'), 15_000);
      try {
        assert.equal(await exited, 0, logs);
      } finally {
        clearTimeout(timeout);
      }
    }
    try {
      // Let the official SDK download its supported native CLI for this platform.
      const cliDirectory = join(tmpdir(), 'mailbox-native-cli-test-cache');
      await mkdir(cliDirectory, { recursive: true });
      const bootstrap = await TestWorkflowEnvironment.createLocal({
        server: { executable: { type: 'cached-download', downloadDir: cliDirectory } },
      });
      await bootstrap.teardown();
      const executable = (await readdir(cliDirectory)).find((name) => name.startsWith('temporal-'));
      assert.ok(executable, 'SDK native CLI download must be present');
      const port = await freePort(),
        uiPort = await freePort(),
        backendPort = await freePort(),
        viewerPort = await freePort();
      const address = `127.0.0.1:${port}`;
      const environment = {
        ...process.env,
        TEMPORAL_CLI_PATH: join(cliDirectory, executable),
        TEMPORAL_ADDRESS: address,
        TEMPORAL_UI_PORT: String(uiPort),
        TEMPORAL_UI_URL: `http://127.0.0.1:${uiPort}`,
        VIEWER_PORT: String(viewerPort),
        TEMPORAL_NAMESPACE: 'default',
        TEMPORAL_DB_FILE: join(directory, 'history.db'),
        MAILBOX_TEST_PORT: String(backendPort),
        MAILBOX_TEST_BACKEND_URL: `http://127.0.0.1:${backendPort}`,
        MAILBOX_TEST_STATE_FILE: join(directory, 'resources.json'),
      };
      async function launch() {
        logs = '';
        runner = spawn(process.execPath, ['scripts/dev.mjs', '--no-watch'], {
          env: environment,
          stdio: ['ignore', 'pipe', 'pipe'],
        });
        exited = new Promise((done) => runner.once('exit', done));
        for (const stream of [runner.stdout, runner.stderr])
          stream.on('data', (data) => {
            logs += data;
          });
        const deadline = Date.now() + 45_000;
        while (
          !logs.includes('Browser viewer ready') ||
          !logs.includes('Workflow worker ready') ||
          (logs.match(/Activity worker ready/g) ?? []).length < 2
        ) {
          if (runner.exitCode !== null || Date.now() > deadline) throw new Error(logs);
          await new Promise((done) => setTimeout(done, 100));
        }
        connection = await Connection.connect({ address });
        return new Client({ connection });
      }
      const client = await launch();
      assert.equal((await fetch(`http://127.0.0.1:${uiPort}`)).status, 200);
      const request = example('PERSONAL', 'native-persistence');
      await configureScenario(environment.MAILBOX_TEST_BACKEND_URL, request.requestId, {
        latencyMs: 0,
        propagationMs: 0,
      });
      assert.equal(
        (
          await client.workflow.execute(WorkflowTypes.PERSONAL, {
            args: [request],
            taskQueue: WorkflowQueue,
            workflowId: request.requestId,
          })
        ).status,
        'READY',
      );
      await connection.close();
      connection = undefined;
      await stop();
      assert.ok((await stat(environment.TEMPORAL_DB_FILE)).size > 0);
      await assert.rejects(Connection.connect({ address, connectTimeout: '1 second' }));
      const restarted = await launch();
      assert.equal(
        (await restarted.workflow.getHandle(request.requestId).result()).status,
        'READY',
      );
      await connection.close();
      connection = undefined;
      await stop();
    } finally {
      await connection?.close();
      await stop();
      await rm(directory, { recursive: true, force: true });
    }
  },
);
