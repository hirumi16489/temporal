import React from 'react';
import { test, expect, vi, afterEach } from 'vitest';
import { render, screen, cleanup } from '@testing-library/react';
import { WorkflowNode } from '../../apps/workflow-viewer/src/components/workflow/WorkflowNode';
vi.mock('reactflow', () => ({ Handle: () => null, Position: { Top: 'top', Bottom: 'bottom' } }));
afterEach(cleanup);
test('retained success has a reuse badge and dashed border, freshly executed success does not', () => {
  const data = {
    id: 'prepare',
    label: 'Prepare',
    type: 'activity',
    status: 'completed',
    startTime: '',
    rawEvents: [],
  };
  const { container, rerender } = render(
    <WorkflowNode
      {...({ data: { ...data, reused: { sourceRunId: 'old-run', resetEventId: '22' } } } as any)}
    />,
  );
  expect(screen.getByText('Reused from previous run')).toBeTruthy();
  expect(container.querySelector('.border-dashed')).toBeTruthy();
  expect(container.querySelector('[data-execution-origin="reused"]')).toBeTruthy();
  rerender(<WorkflowNode {...({ data } as any)} />);
  expect(screen.queryByText('Reused from previous run')).toBeNull();
  expect(screen.getByText('Succeeded')).toBeTruthy();
});
