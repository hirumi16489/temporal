import { test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { createViewerServer } from '../../apps/workflow-viewer/server-lib.mjs';
test('viewer encodes identifiers, follows paginated history and exposes only read operations', async () => {
  const paths = [];
  const server = createViewerServer({
    endpoint: 'http://127.0.0.1:8233',
    namespace: 'custom',
    request: async (url) => {
      paths.push(url);
      if (url.pathname.endsWith('/history'))
        return Response.json(
          url.searchParams.get('nextPageToken')
            ? { history: { events: [{ eventId: '2' }] } }
            : { history: { events: [{ eventId: '1' }] }, nextPageToken: '+/token=' },
        );
      return Response.json({
        workflowExecutionInfo: { status: 'WORKFLOW_EXECUTION_STATUS_COMPLETED' },
      });
    },
  });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = 'http://127.0.0.1:' + server.address().port;
  try {
    assert.equal((await (await fetch(base + '/api/config')).json()).namespace, 'custom');
    const response = await fetch(
      base +
        '/api/workflow?' +
        new URLSearchParams({ id: 'mailbox/a?b', runId: 'run', namespace: 'ns/name' }),
    );
    assert.equal(response.status, 200);
    assert.deepEqual(
      (await response.json()).events.map((e) => e.eventId),
      ['1', '2'],
    );
    assert.match(paths[0].pathname, /ns%2Fname\/workflows\/mailbox%2Fa%3Fb$/);
    assert.equal(paths[2].searchParams.get('nextPageToken'), '+/token=');
    assert.equal((await fetch(base + '/api/workflow')).status, 400);
    assert.equal((await fetch(base + '/api/search', { method: 'POST' })).status, 405);
    assert.equal((await fetch(base + '/api/missing')).status, 404);
    assert.equal((await fetch(base + '/workflow/default/id/run')).status, 200);
  } finally {
    server.closeAllConnections();
    await new Promise((done) => server.close(done));
  }
});
