import { existsSync, readFileSync, mkdirSync, writeFileSync, renameSync } from 'node:fs';
import { dirname } from 'node:path';
export type ConfigurationPermission = 'DENIED' | 'ALLOWED';
interface PermissionState {
  configuration: Record<string, ConfigurationPermission>;
}
function readPermissions(path: string): PermissionState {
  if (!existsSync(path)) return { configuration: {} };
  const value: unknown = JSON.parse(readFileSync(path, 'utf8'));
  if (!value || typeof value !== 'object' || !('configuration' in value))
    throw new Error('Invalid simulator permission file');
  const configuration = value.configuration;
  if (!configuration || typeof configuration !== 'object' || Array.isArray(configuration))
    throw new Error('Invalid simulator configuration permissions');
  for (const permission of Object.values(configuration))
    if (permission !== 'DENIED' && permission !== 'ALLOWED')
      throw new Error('Permission must be DENIED or ALLOWED');
  return value as PermissionState;
}
export function configurationPermission(
  path: string,
  requestId: string,
): ConfigurationPermission | undefined {
  const state = readPermissions(path);
  return Object.hasOwn(state.configuration, requestId) ? state.configuration[requestId] : undefined;
}
export function setConfigurationPermission(
  path: string,
  requestId: string,
  permission: ConfigurationPermission,
) {
  if (!requestId.trim()) throw new Error('A request ID is required');
  if (permission !== 'DENIED' && permission !== 'ALLOWED') throw new Error('Invalid permission');
  const state = readPermissions(path);
  state.configuration = { ...state.configuration, [requestId]: permission };
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path + '.tmp', JSON.stringify(state, null, 2) + '\n');
  renameSync(path + '.tmp', path);
}
