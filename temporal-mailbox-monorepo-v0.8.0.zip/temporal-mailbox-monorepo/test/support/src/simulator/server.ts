import { createServer } from 'node:http';
import { existsSync, readFileSync, mkdirSync, writeFileSync, renameSync } from 'node:fs';
import { dirname } from 'node:path';
import type { ProvisioningRequest } from '@automation/mailbox/contracts';
import type { MailboxTestScenario } from '../fixtures/index';
import { configurationPermission } from './permissions';
type RecordData = {
  request: ProvisioningRequest;
  availableAt: number;
  configured: boolean;
  appliedOwner?: string;
  appliedConfiguration?: ProvisioningRequest['configuration'];
  appliedRoom?: ProvisioningRequest['room'];
};
interface State {
  mailboxes: Record<string, RecordData>;
  groups: Record<string, { mailbox: string; members: readonly string[] }>;
}
export interface BackendHooks {
  beforeOperation?: (event: {
    pool: string;
    path: string;
    input?: ProvisioningRequest;
  }) => Promise<void>;
}
export function createMailboxTestServer(
  stateFile?: string,
  hooks: BackendHooks = {},
  permissionsFile?: string,
) {
  const state: State =
    stateFile && existsSync(stateFile)
      ? JSON.parse(readFileSync(stateFile, 'utf8'))
      : { mailboxes: {}, groups: {} };
  Object.setPrototypeOf(state.mailboxes, null);
  Object.setPrototypeOf(state.groups, null);
  let active = 0,
    peak = 0;
  const activeByPool: Record<string, number> = {};
  const peakByPool: Record<string, number> = {};
  const events: unknown[] = [];
  function save() {
    if (!stateFile) return;
    mkdirSync(dirname(stateFile), { recursive: true });
    writeFileSync(stateFile + '.tmp', JSON.stringify(state, null, 2));
    renameSync(stateFile + '.tmp', stateFile);
  }
  const scenarios = new Map<string, MailboxTestScenario>();
  const server = createServer(async (req, res) => {
    const reply = (status: number, data: unknown) => {
      res.writeHead(status, { 'content-type': 'application/json' });
      res.end(JSON.stringify(data));
    };
    let counted = false;
    const pool = String(req.headers['x-activity-pool'] ?? 'unassigned');
    try {
      const path = new URL(req.url!, 'http://localhost').pathname;
      if (req.method === 'GET' && path === '/health') return reply(200, { status: 'ok' });
      if (req.method === 'GET' && path === '/state')
        return reply(200, { ...state, active, peak, activeByPool, peakByPool, events });
      let body: any = {};
      if (req.method === 'POST') {
        let data = '';
        for await (const chunk of req) {
          data += chunk;
          if (data.length > 100_000) return reply(413, { error: 'Request too large' });
        }
        body = JSON.parse(data);
      }
      if (req.method === 'POST' && path.startsWith('/test/scenarios/')) {
        scenarios.set(decodeURIComponent(path.slice('/test/scenarios/'.length)), body);
        return reply(200, { status: 'configured' });
      }
      active++;
      counted = true;
      peak = Math.max(peak, active);
      activeByPool[pool] = (activeByPool[pool] ?? 0) + 1;
      peakByPool[pool] = Math.max(peakByPool[pool] ?? 0, activeByPool[pool]);
      const input = body.input as ProvisioningRequest | undefined;
      const recordIdentity = path.startsWith('/mailboxes/')
        ? decodeURIComponent(path.slice('/mailboxes/'.length))
        : undefined;
      const scenario =
        scenarios.get(
          input?.requestId ??
            (recordIdentity ? state.mailboxes[recordIdentity]?.request.requestId : '') ??
            '',
        ) ?? {};
      events.push({
        at: new Date().toISOString(),
        path,
        pool,
        identity: input?.identity,
        attempt: body.attempt,
        active,
      });
      if (events.length > 1000) events.shift();
      await hooks.beforeOperation?.({ pool, path, input });
      await new Promise((resolve) => setTimeout(resolve, scenario.latencyMs ?? 100));
      if (req.method === 'GET' && path.startsWith('/mailboxes/')) {
        const record = state.mailboxes[decodeURIComponent(path.slice('/mailboxes/'.length))];
        return reply(200, { available: !!record && Date.now() >= record.availableAt });
      }
      if (!input?.identity || !input.requestId)
        return reply(400, { error: 'identity and requestId required' });
      if (req.method === 'POST' && path === '/mailboxes') {
        if (body.attempt <= (scenario.failProvisionAttempts ?? 0))
          return reply(503, { error: 'Simulated transient provisioning failure' });
        const existing = state.mailboxes[input.identity];
        if (
          existing &&
          (existing.request.requestId !== input.requestId ||
            JSON.stringify(existing.request) !== JSON.stringify(input))
        )
          return reply(409, { error: 'Identity exists with a different request' });
        if (!existing) {
          state.mailboxes[input.identity] = {
            request: input,
            availableAt: Date.now() + (scenario.propagationMs ?? 3000),
            configured: false,
          };
          save();
        }
        return reply(200, { status: existing ? 'EXISTING' : 'CREATED' });
      }
      if (req.method === 'POST' && path === '/configure') {
        const record = state.mailboxes[input.identity];
        if (!record || Date.now() < record.availableAt)
          return reply(503, { error: 'Mailbox unavailable' });
        if (record.request.requestId !== input.requestId)
          return reply(409, { error: 'Request does not own mailbox' });
        const permission = permissionsFile
          ? configurationPermission(permissionsFile, input.requestId)
          : undefined;
        if (permission === 'DENIED' || (permission === undefined && scenario.failConfiguration))
          return reply(403, { error: 'Simulated permanent permission failure' });
        record.appliedConfiguration = structuredClone(input.configuration);
        if (input.kind === 'ROOM') record.appliedRoom = structuredClone(input.room);
        record.configured = true;
        save();
        if (scenario.failAfterConfigurationCommit && body.attempt === 1)
          return reply(503, { error: 'Simulated lost response after configuration committed' });
        return reply(200, { status: 'CONFIGURED' });
      }
      if (req.method === 'POST' && path === '/owners') {
        const record = state.mailboxes[input.identity];
        if (!record || record.request.requestId !== input.requestId)
          return reply(409, { error: 'Owner request does not own mailbox' });
        record.appliedOwner = input.configuration.owner;
        save();
        return reply(200, { status: 'CONFIGURED' });
      }
      if (req.method === 'POST' && path === '/groups') {
        if (!input.group) return reply(400, { error: 'Group details required' });
        const mailbox = state.mailboxes[input.identity];
        if (!mailbox || Date.now() < mailbox.availableAt)
          return reply(503, { error: 'Mailbox unavailable' });
        if (mailbox.request.requestId !== input.requestId)
          return reply(409, { error: 'Request does not own mailbox' });
        const desired = { mailbox: input.identity, members: input.group.members };
        const existing = state.groups[input.group.identity];
        if (existing && JSON.stringify(existing) !== JSON.stringify(desired))
          return reply(409, { error: 'Group identity conflict' });
        state.groups[input.group.identity] = desired;
        save();
        return reply(200, { status: 'CONFIGURED' });
      }
      reply(404, { error: 'Unknown operation' });
    } catch (error) {
      reply(400, { error: String(error) });
    } finally {
      if (counted) {
        active--;
        activeByPool[pool]--;
      }
    }
  });
  return Object.assign(server, {
    setScenario(requestId: string, scenario: MailboxTestScenario) {
      scenarios.set(requestId, scenario);
    },
  });
}
