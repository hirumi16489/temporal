import { createMailboxTestServer } from './server';
const server = createMailboxTestServer(
  process.env.MAILBOX_TEST_STATE_FILE ?? '.data/backend.json',
  {},
  process.env.MAILBOX_TEST_PERMISSIONS_FILE ?? '.data/mailbox-permissions.json',
);
server.listen(
  Number(process.env.MAILBOX_TEST_PORT ?? 3001),
  process.env.MAILBOX_TEST_HOST ?? '127.0.0.1',
  () => console.log('Mock backend: http://127.0.0.1:' + (process.env.MAILBOX_TEST_PORT ?? 3001)),
);
for (const signal of ['SIGINT', 'SIGTERM'] as const) process.once(signal, () => server.close());
