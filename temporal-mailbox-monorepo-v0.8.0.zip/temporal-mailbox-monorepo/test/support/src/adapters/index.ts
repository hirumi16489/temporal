import {
  createMailboxServices,
  type MailboxPorts,
  type OperationContext,
} from '@automation/mailbox/application';
import { createMailboxActivityHandlers } from '@automation/mailbox/adapters/inbound/temporal';
import {
  DependencyUnavailable,
  PermissionDenied,
  IdentityConflict,
  InvalidMailboxRequest,
} from '@automation/mailbox/domain';
export function createMailboxTestPorts(url: string, pool = 'unassigned'): MailboxPorts {
  async function call(path: string, context: OperationContext, input?: unknown): Promise<any> {
    let response: Response;
    try {
      response = await fetch(url + path, {
        method: input === undefined ? 'GET' : 'POST',
        headers: {
          'content-type': 'application/json',
          'x-activity-pool': pool,
          'idempotency-key': context.idempotencyKey,
        },
        body: input === undefined ? undefined : JSON.stringify({ input, attempt: context.attempt }),
        signal: context.signal
          ? AbortSignal.any([context.signal, AbortSignal.timeout(10_000)])
          : AbortSignal.timeout(10_000),
      });
    } catch (error) {
      if (context.signal?.aborted) throw error;
      throw new DependencyUnavailable('Mailbox test backend unavailable', { cause: error });
    }
    const data = (await response.json()) as any;
    if (!response.ok) {
      if (response.status === 403 || response.status === 401)
        throw new PermissionDenied(data.error);
      if (response.status === 409) throw new IdentityConflict(data.error);
      if (response.status >= 400 && response.status < 500 && response.status !== 429)
        throw new InvalidMailboxRequest(data.error);
      throw new DependencyUnavailable(data.error ?? 'Test dependency failed');
    }
    return data;
  }
  return {
    mailboxes: {
      ensureMailbox: async (plan, context) => (await call('/mailboxes', context, plan)).status,
      isReady: async (identity, _requestId, context) =>
        (await call('/mailboxes/' + encodeURIComponent(identity), context)).available,
      configureSettings: async (plan, context) => {
        await call('/configure', context, plan);
      },
    },
    directory: {
      configureOwner: async (plan, context) => {
        await call('/owners', context, plan);
      },
    },
    groups: {
      ensureDistributionGroup: async (plan, context) => {
        await call('/groups', context, plan);
      },
    },
  };
}
export const createTestMailboxActivities = (url: string, pool?: string) =>
  createMailboxActivityHandlers(createMailboxServices(createMailboxTestPorts(url, pool)));
