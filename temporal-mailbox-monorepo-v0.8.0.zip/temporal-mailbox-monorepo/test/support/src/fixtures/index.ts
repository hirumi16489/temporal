import type {
  ProvisioningRequest,
  MailboxKind,
  PersonalMailboxRequest,
  RoomMailboxRequest,
  GroupMailboxRequest,
} from '@automation/mailbox/contracts';
export function example(kind: 'PERSONAL', id: string): PersonalMailboxRequest;
export function example(kind: 'ROOM', id: string): RoomMailboxRequest;
export function example(kind: 'GROUP', id: string): GroupMailboxRequest;
export function example(kind: MailboxKind, id: string): ProvisioningRequest;
export function example(kind: MailboxKind, id: string): ProvisioningRequest {
  const common = {
    requestId: id,
    identity: id + '@example.invalid',
    displayName: 'Example ' + kind,
    configuration: { aliases: [], retention: 'standard', owner: 'demo-owner' },
  };
  if (kind === 'ROOM')
    return { ...common, kind, room: { location: 'Example office', capacity: 8 } };
  if (kind === 'GROUP')
    return { ...common, kind, group: { identity: 'group-' + id, members: ['demo-member'] } };
  return { ...common, kind };
}
export interface MailboxTestScenario {
  latencyMs?: number;
  propagationMs?: number;
  failProvisionAttempts?: number;
  failConfiguration?: boolean;
  failAfterConfigurationCommit?: boolean;
}
export async function configureScenario(
  endpoint: string,
  requestId: string,
  scenario: MailboxTestScenario,
) {
  const response = await fetch(endpoint + '/test/scenarios/' + encodeURIComponent(requestId), {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(scenario),
  });
  if (!response.ok) throw new Error('Could not configure mailbox simulation: ' + response.status);
}
