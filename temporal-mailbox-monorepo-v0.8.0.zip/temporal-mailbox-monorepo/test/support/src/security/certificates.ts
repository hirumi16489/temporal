import { spawnSync } from 'node:child_process';
import { mkdirSync, existsSync, readFileSync, writeFileSync, chmodSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { X509Certificate } from 'node:crypto';
import { WorkflowTypes } from '@automation/mailbox/contracts';
import { WorkflowQueue } from '@automation/mailbox/execution';
import { validateAccessPolicy } from '@automation/temporal-platform/access';
export function createSecurityCertificates(directory: string) {
  directory = resolve(directory);
  const policyFile = join(directory, 'policy.json');
  if (existsSync(policyFile)) {
    const policy = validateAccessPolicy(JSON.parse(readFileSync(policyFile, 'utf8')));
    for (const id of ['server', 'client-a', 'client-b', 'unknown-client', 'rogue-client']) {
      const certificate = new X509Certificate(readFileSync(join(directory, id + '.crt')));
      if (Date.parse(certificate.validTo) <= Date.now())
        throw new Error('Local security certificate expired; generate a new demo directory');
      if (
        id.startsWith('client-') &&
        !policy.clients
          .find((client) => client.id === id)
          ?.certificateFingerprints.includes(certificate.fingerprint256.replaceAll(':', ''))
      )
        throw new Error('Certificate and policy disagree');
      if (!existsSync(join(directory, id + '.key')))
        throw new Error('Local demo private key is missing');
    }
    return { directory, policyFile };
  }
  if (existsSync(directory))
    throw new Error(
      'Security certificate directory already exists without a complete policy; choose a new directory',
    );
  mkdirSync(directory, { recursive: true, mode: 0o700 });
  const executable = process.env.OPENSSL_PATH || 'openssl';
  function openssl(args: string[]) {
    const result = spawnSync(executable, args, { cwd: directory, encoding: 'utf8' });
    if (result.error)
      throw new Error('OpenSSL is required; install it on PATH or set OPENSSL_PATH');
    if (result.status !== 0)
      throw new Error('OpenSSL certificate generation failed: ' + result.stderr);
  }
  openssl([
    'req',
    '-x509',
    '-newkey',
    'rsa:2048',
    '-sha256',
    '-nodes',
    '-days',
    '7',
    '-subj',
    '/CN=Mailbox Local Demo CA',
    '-keyout',
    'ca.key',
    '-out',
    'ca.crt',
    '-addext',
    'basicConstraints=critical,CA:TRUE',
    '-addext',
    'keyUsage=critical,keyCertSign,cRLSign',
  ]);
  for (const id of ['server', 'client-a', 'client-b', 'unknown-client']) {
    writeFileSync(
      join(directory, id + '.ext'),
      'basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=' +
        (id === 'server' ? 'serverAuth' : 'clientAuth') +
        '\nsubjectAltName=' +
        (id === 'server' ? 'DNS:localhost,IP:127.0.0.1' : 'URI:spiffe://mailbox-demo/' + id) +
        '\n',
    );
    openssl([
      'req',
      '-new',
      '-newkey',
      'rsa:2048',
      '-nodes',
      '-subj',
      '/CN=' + id,
      '-keyout',
      id + '.key',
      '-out',
      id + '.csr',
    ]);
    openssl([
      'x509',
      '-req',
      '-in',
      id + '.csr',
      '-CA',
      'ca.crt',
      '-CAkey',
      'ca.key',
      '-CAcreateserial',
      '-days',
      '7',
      '-sha256',
      '-extfile',
      id + '.ext',
      '-out',
      id + '.crt',
    ]);
  }
  // Deliberately untrusted, self-signed client for the negative handshake case.
  openssl([
    'req',
    '-x509',
    '-newkey',
    'rsa:2048',
    '-sha256',
    '-nodes',
    '-days',
    '7',
    '-subj',
    '/CN=untrusted-client',
    '-keyout',
    'rogue-client.key',
    '-out',
    'rogue-client.crt',
    '-addext',
    'extendedKeyUsage=clientAuth',
  ]);
  for (const id of ['ca', 'server', 'client-a', 'client-b', 'unknown-client', 'rogue-client'])
    chmodSync(join(directory, id + '.key'), 0o600);
  const clients = ['client-a', 'client-b'].map((id, index) => ({
    id,
    certificateFingerprints: [
      new X509Certificate(readFileSync(join(directory, id + '.crt'))).fingerprint256.replaceAll(
        ':',
        '',
      ),
    ],
    workflowTypes: [index === 0 ? WorkflowTypes.PERSONAL : WorkflowTypes.ROOM],
    workflowIdPrefix: 'mailbox-' + id + '-',
  }));
  const policy = validateAccessPolicy({
    namespace: process.env.TEMPORAL_NAMESPACE ?? 'default',
    workflowTaskQueue: WorkflowQueue,
    clients,
  });
  writeFileSync(policyFile, JSON.stringify(policy, null, 2) + '\n');
  return { directory, policyFile };
}
