import { resolve } from 'node:path';
import { connectSecurityClient, runSecurityMatrix, startSecurityWorkflow } from './client';
async function main() {
  const directory = resolve(process.env.SECURITY_DEMO_DIR ?? '.data/security'),
    address = process.env.GATEWAY_ADDRESS ?? '127.0.0.1:7443',
    namespace = process.env.TEMPORAL_NAMESPACE ?? 'default';
  const [identity = 'matrix', kind] = process.argv.slice(2);
  if (identity === 'matrix') {
    const runs = await runSecurityMatrix(directory, address, namespace);
    console.table(runs);
    console.log(
      'View the two allowed executions at ' +
        (process.env.VIEWER_URL ?? 'http://localhost:7531') +
        '. Denied starts create no execution.',
    );
    return;
  }
  if (
    !['client-a', 'client-b'].includes(identity) ||
    !['personal', 'room', 'group'].includes(kind ?? '')
  )
    throw new Error(
      'Usage: npm run demo:security [-- matrix | client-a|client-b personal|room|group]',
    );
  const connection = await connectSecurityClient(directory, identity, address);
  try {
    const handle = await startSecurityWorkflow(
      connection,
      identity,
      kind.toUpperCase() as 'PERSONAL' | 'ROOM' | 'GROUP',
      namespace,
    );
    console.log('Started ' + handle.workflowId + ' · Run ' + handle.firstExecutionRunId);
    console.log(await handle.result());
  } finally {
    await connection.close();
  }
}
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
