import { Connection, Client } from '@temporalio/client';
import { temporalConnectionSettings } from '@automation/temporal-platform/connection';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { WorkflowTypes, type MailboxKind } from '@automation/mailbox/contracts';
import { WorkflowQueue } from '@automation/mailbox/execution';
import { example } from '../fixtures/index';
export async function connectSecurityClient(
  directory: string,
  identity: string,
  address: string,
  metadata?: Record<string, string>,
  verification: { serverName?: string; caFile?: string } = {},
) {
  const settings = temporalConnectionSettings({
    TEMPORAL_ADDRESS: address,
    TEMPORAL_TLS_ENABLED: 'true',
    TEMPORAL_TLS_CA_FILE: join(directory, verification.caFile ?? 'ca.crt'),
    TEMPORAL_TLS_SERVER_NAME: verification.serverName ?? 'localhost',
    ...(identity === 'no-certificate'
      ? {}
      : {
          TEMPORAL_TLS_CLIENT_CERT_FILE: join(directory, identity + '.crt'),
          TEMPORAL_TLS_CLIENT_KEY_FILE: join(directory, identity + '.key'),
        }),
  });
  return Connection.connect({
    address: settings.address,
    tls: settings.tls,
    connectTimeout: '2 seconds',
    metadata,
  });
}
export async function startSecurityWorkflow(
  connection: Connection,
  identity: string,
  kind: MailboxKind,
  namespace: string,
  options: { workflowId?: string; taskQueue?: string } = {},
) {
  const input = example(kind, randomUUID());
  const workflowId = options.workflowId ?? 'mailbox-' + identity + '-' + input.requestId;
  const client = new Client({ connection, namespace });
  return client.workflow.start(WorkflowTypes[kind], {
    args: [input],
    workflowId,
    taskQueue: options.taskQueue ?? WorkflowQueue,
  });
}
export async function runSecurityMatrix(
  directory: string,
  address: string,
  namespace: string,
  report: (message: string) => void = console.log,
) {
  const a = await connectSecurityClient(directory, 'client-a', address),
    b = await connectSecurityClient(directory, 'client-b', address);
  const runs: { client: string; workflowId: string; runId: string }[] = [];
  try {
    for (const [identity, connection, kind] of [
      ['client-a', a, 'PERSONAL'],
      ['client-b', b, 'ROOM'],
    ] as const) {
      const handle = await startSecurityWorkflow(connection, identity, kind, namespace);
      const result = (await handle.result()) as { status: string };
      if (result.status !== 'READY') throw new Error('Allowed workflow did not complete');
      runs.push({
        client: identity,
        workflowId: handle.workflowId,
        runId: handle.firstExecutionRunId,
      });
      report('PASS ALLOW ' + identity + ' → ' + kind + ' → READY · ' + handle.workflowId);
    }
    async function denied(label: string, task: () => Promise<unknown>, code = 7) {
      try {
        await task();
      } catch (error) {
        let cause: any = error;
        for (let depth = 0; cause && depth < 8 && typeof cause.code !== 'number'; depth++)
          cause = cause.cause;
        if (cause?.code === code) {
          report('PASS DENY ' + label + ' · gRPC ' + code);
          return;
        }
        throw error;
      }
      throw new Error('Authorization bypass: ' + label);
    }
    await denied('client-a → ROOM', () => startSecurityWorkflow(a, 'client-a', 'ROOM', namespace));
    await denied('client-b → PERSONAL', () =>
      startSecurityWorkflow(b, 'client-b', 'PERSONAL', namespace),
    );
    await denied('client-a → client-b history', () =>
      new Client({ connection: a, namespace }).workflow
        .getHandle(runs[1].workflowId, runs[1].runId)
        .fetchHistory(),
    );
    await denied('client-a → different namespace', () =>
      startSecurityWorkflow(a, 'client-a', 'PERSONAL', namespace + '-forbidden'),
    );
    await denied('client-a → different task queue', () =>
      startSecurityWorkflow(a, 'client-a', 'PERSONAL', namespace, {
        taskQueue: 'unauthorized-queue',
      }),
    );
    await denied('client-a → client-b workflow ID', () =>
      startSecurityWorkflow(a, 'client-a', 'PERSONAL', namespace, {
        workflowId: 'mailbox-client-b-' + randomUUID(),
      }),
    );
    await denied('client-b spoofing a client-a header', () =>
      b.withMetadata({ 'x-client-id': 'client-a' }, () =>
        startSecurityWorkflow(b, 'client-a', 'PERSONAL', namespace),
      ),
    );
    await denied(
      'client-a → unexposed mutation API',
      () =>
        a.workflowService.terminateWorkflowExecution({
          namespace,
          workflowExecution: { workflowId: runs[0].workflowId },
          reason: 'Must be blocked',
        }),
      12,
    );
    for (const identity of ['no-certificate', 'rogue-client', 'unknown-client']) {
      let rejected = false;
      try {
        const connection = await connectSecurityClient(directory, identity, address);
        await connection.close();
      } catch {
        rejected = true;
      }
      if (!rejected) throw new Error('Unauthenticated client reached the gateway: ' + identity);
      report(
        'PASS REJECT ' +
          identity +
          (identity === 'unknown-client'
            ? ' · trusted certificate without policy identity'
            : ' · TLS handshake'),
      );
    }
    for (const [label, verification] of [
      ['wrong server name', { serverName: 'not-localhost.invalid' }],
      ['untrusted server CA', { caFile: 'rogue-client.crt' }],
    ] as const) {
      let rejected = false;
      try {
        const connection = await connectSecurityClient(
          directory,
          'client-a',
          address,
          undefined,
          verification,
        );
        await connection.close();
      } catch {
        rejected = true;
      }
      if (!rejected) throw new Error('Server certificate verification bypass: ' + label);
      report('PASS REJECT ' + label + ' · client verifies server identity');
    }
    return runs;
  } finally {
    await a.close();
    await b.close();
  }
}
