import { resolve } from 'node:path';
import { createSecurityCertificates } from './certificates';
try {
  const result = createSecurityCertificates(
    resolve(process.env.SECURITY_DEMO_DIR ?? '.data/security'),
  );
  console.log('Local demo certificates and client policy ready: ' + result.directory);
  console.log('Client A: personal mailbox only. Client B: room mailbox only.');
  console.log('Start npm run start:gateway, then npm run demo:security');
} catch (error) {
  console.error(error);
  process.exitCode = 1;
}
