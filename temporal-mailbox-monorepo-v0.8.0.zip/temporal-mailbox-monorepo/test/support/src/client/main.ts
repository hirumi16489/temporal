import { temporalConnectionSettings } from '@automation/temporal-platform/connection';
import { readFileSync } from 'node:fs';
import { Client, Connection } from '@temporalio/client';
import { WorkflowTypes, MailboxQueries } from '@automation/mailbox/contracts';
import { WorkflowQueue } from '@automation/mailbox/execution';
import { createProvisioningPlan } from '@automation/mailbox/domain';
import { toPreparedCommand } from '@automation/mailbox/application';
export async function main(args = process.argv.slice(2)) {
  const [command, value] = args;
  if (!['start', 'status'].includes(command) || !value)
    throw new Error('Usage: npm run mailbox -- start <request.json> | status <workflow-id>');
  const settings = temporalConnectionSettings();
  const connection = await Connection.connect({ address: settings.address, tls: settings.tls });
  try {
    const client = new Client({
      connection,
      namespace: settings.namespace,
    });
    if (command === 'status') {
      console.log(await client.workflow.getHandle(value).query(MailboxQueries.STATUS));
      return;
    }
    const request = toPreparedCommand(
      createProvisioningPlan(JSON.parse(readFileSync(value, 'utf8'))),
    );
    const handle = await client.workflow.start(WorkflowTypes[request.kind], {
      args: [request],
      taskQueue: WorkflowQueue,
      workflowId: 'mailbox-' + request.requestId,
    });
    console.log('Started', handle.workflowId, 'run', handle.firstExecutionRunId);
  } finally {
    await connection.close();
  }
}
if (require.main === module)
  main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
