import { temporalConnectionSettings } from '@automation/temporal-platform/connection';
import { MailboxQueries } from '@automation/mailbox/contracts';
import { Client, Connection } from '@temporalio/client';
async function main() {
  if (!process.argv[2]) throw new Error('Usage: npm run status -- <workflow-id>');
  const settings = temporalConnectionSettings();
  const connection = await Connection.connect({ address: settings.address, tls: settings.tls });
  try {
    const client = new Client({
      connection,
      namespace: settings.namespace,
    });
    console.log(await client.workflow.getHandle(process.argv[2]).query(MailboxQueries.STATUS));
  } finally {
    await connection.close();
  }
}
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
