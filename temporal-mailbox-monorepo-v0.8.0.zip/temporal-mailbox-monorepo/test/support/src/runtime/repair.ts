import { resolve } from 'node:path';
import { setConfigurationPermission } from '../simulator/index';
export function repairPermission(workflowId: string, path: string) {
  if (!workflowId.startsWith('mailbox-') || workflowId.length <= 'mailbox-'.length)
    throw new Error('Supply the mailbox-... Workflow ID printed by demo:recovery');
  const requestId = workflowId.slice('mailbox-'.length);
  setConfigurationPermission(path, requestId, 'ALLOWED');
  return requestId;
}
if (require.main === module) {
  try {
    const path = resolve(
      process.env.MAILBOX_TEST_PERMISSIONS_FILE ?? '.data/mailbox-permissions.json',
    );
    repairPermission(process.argv[2] ?? '', path);
    console.log('Configuration permission granted in ' + path);
    console.log(
      'The workflow is still FAILED. Reset it from Temporal UI to run configuration again.',
    );
  } catch (error) {
    console.error(error);
    process.exitCode = 1;
  }
}
