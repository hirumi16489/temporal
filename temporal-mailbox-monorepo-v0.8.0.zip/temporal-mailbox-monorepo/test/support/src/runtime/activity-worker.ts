import { runWorkerHost } from '@automation/temporal-platform/worker-runtime';
import { createMailboxActivityWorker } from '@hosts/mailbox-activity-worker';
import { createTestMailboxActivities } from '../adapters/index';
import { resolvedPools, type PoolProfile } from '@automation/mailbox/execution';
const profile = process.argv[2] ?? 'standard';
if (!Object.hasOwn(resolvedPools, profile)) throw new Error('Unknown mailbox pool profile');
runWorkerHost((connection, namespace) =>
  createMailboxActivityWorker(
    connection,
    namespace,
    createTestMailboxActivities(
      process.env.MAILBOX_TEST_BACKEND_URL ?? 'http://127.0.0.1:3001',
      resolvedPools[profile as PoolProfile],
    ),
    profile,
  ),
).catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
