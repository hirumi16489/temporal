import { temporalConnectionSettings } from '@automation/temporal-platform/connection';
import { Client, Connection } from '@temporalio/client';
import { randomUUID } from 'node:crypto';
import { readFileSync } from 'node:fs';
import type { ProvisioningRequest, MailboxKind } from '@automation/mailbox/contracts';
import { WorkflowTypes } from '@automation/mailbox/contracts';
import { WorkflowQueue } from '@automation/mailbox/execution';
import { setConfigurationPermission } from '../simulator/index';
import { example, configureScenario } from '../fixtures/index';
async function isolationDemo(client: Client) {
  const backendUrl = process.env.MAILBOX_TEST_BACKEND_URL ?? 'http://127.0.0.1:3001';
  const baseline = (await (await fetch(backendUrl + '/state')).json()) as any;
  const startIndex = baseline.events.length;
  const handles = await Promise.all(
    Array.from({ length: 10 }, async () => {
      const input = example('ROOM', randomUUID());
      await configureScenario(backendUrl, input.requestId, { latencyMs: 1500, propagationMs: 0 });
      return client.workflow.start(WorkflowTypes.ROOM, {
        args: [input],
        taskQueue: WorkflowQueue,
        workflowId: 'mailbox-' + input.requestId,
      });
    }),
  );
  console.log('Started 10 standard requests. Waiting until standard backend work is active...');
  let active = false;
  for (let check = 0; check < 200; check++) {
    const state = (await (await fetch(backendUrl + '/state')).json()) as any;
    if (state.events.length > startIndex && state.active > 0) {
      active = true;
      break;
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  if (!active) throw new Error('No activity observed. Check both activity workers are running.');
  const input = example('PERSONAL', randomUUID());
  await configureScenario(backendUrl, input.requestId, { latencyMs: 5, propagationMs: 0 });
  const started = Date.now();
  const personal = await client.workflow.start(WorkflowTypes.PERSONAL, {
    args: [input],
    taskQueue: WorkflowQueue,
    workflowId: 'mailbox-' + input.requestId,
  });
  console.log('Personal Workflow ID:', personal.workflowId);
  console.log('Personal result:', await personal.result(), 'elapsed ms:', Date.now() - started);
  const state = (await (await fetch(backendUrl + '/state')).json()) as any;
  console.log('Backend peak calls per pool:', state.peakByPool);
  console.log('Standard workflows continue using their own pool...');
  await Promise.all(handles.map((handle) => handle.result()));
  console.log('All standard workflows completed.');
}

async function main() {
  const scenario = process.argv[2] ?? 'personal';
  const valid = [
    'personal',
    'room',
    'group',
    'retry',
    'failure',
    'recovery',
    'idempotency',
    'batch',
    'file',
    'viewer',
    'isolation',
  ];
  if (!valid.includes(scenario)) throw new Error('Scenario must be: ' + valid.join(', '));
  const settings = temporalConnectionSettings();
  const connection = await Connection.connect({ address: settings.address, tls: settings.tls });
  try {
    const client = new Client({
      connection,
      namespace: settings.namespace,
    });
    if (scenario === 'isolation') {
      await isolationDemo(client);
      return;
    }
    const count = scenario === 'batch' ? Number(process.argv[3] ?? 10) : 1;
    if (!Number.isInteger(count) || count < 1 || count > 1000)
      throw new Error('Batch size must be 1..1000');
    const handles = await Promise.all(
      Array.from({ length: count }, async () => {
        const kind: MailboxKind =
          scenario === 'room'
            ? 'ROOM'
            : scenario === 'group' || scenario === 'failure' || scenario === 'viewer'
              ? 'GROUP'
              : 'PERSONAL';
        const input: ProvisioningRequest =
          scenario === 'file'
            ? JSON.parse(readFileSync(process.argv[3], 'utf8'))
            : example(kind, randomUUID());
        const simulation: import('../fixtures/index').MailboxTestScenario = {};
        if (scenario === 'retry') simulation.failProvisionAttempts = 2;
        if (scenario === 'failure') simulation.failConfiguration = true;
        if (scenario === 'recovery') {
          setConfigurationPermission(
            process.env.MAILBOX_TEST_PERMISSIONS_FILE ?? '.data/mailbox-permissions.json',
            input.requestId,
            'DENIED',
          );
          Object.assign(simulation, { latencyMs: 1500, propagationMs: 0 });
        }
        if (scenario === 'idempotency') simulation.failAfterConfigurationCommit = true;
        if (scenario === 'viewer')
          Object.assign(simulation, {
            propagationMs: 15000,
            latencyMs: 600,
            failProvisionAttempts: 1,
          });
        if (scenario === 'batch') simulation.latencyMs = 800;
        await configureScenario(
          process.env.MAILBOX_TEST_BACKEND_URL ?? 'http://127.0.0.1:3001',
          input.requestId,
          simulation,
        );
        const workflowType = WorkflowTypes[input.kind];
        if (!workflowType) throw new Error('Invalid kind');
        const handle = await client.workflow.start(workflowType, {
          args: [input],
          workflowId: 'mailbox-' + input.requestId,
          taskQueue: WorkflowQueue,
        });
        console.log('Started', handle.workflowId);
        console.log(
          'Browser graph: open',
          process.env.VIEWER_URL ?? 'http://localhost:7531',
          'and search this Workflow ID.',
        );
        return handle;
      }),
    );
    const results = await Promise.allSettled(handles.map((h) => h.result()));
    for (let i = 0; i < results.length; i++) console.log(handles[i].workflowId, results[i]);
    if (scenario === 'recovery') {
      const handle = handles[0];
      const history = await handle.fetchHistory();
      const permissionFailure = history.events?.some(
        (event) =>
          event.activityTaskFailedEventAttributes?.failure?.applicationFailureInfo?.type ===
          'PermissionDenied',
      );
      if (!permissionFailure)
        throw new Error(
          'Recovery scenario did not reach the expected permission failure; inspect the execution history.',
        );
      const scheduled = history.events?.find(
        (event) =>
          event.activityTaskScheduledEventAttributes?.activityType?.name === 'configureMailbox',
      );
      const resetPoint = history.events
        ?.filter(
          (event) =>
            event.workflowTaskCompletedEventAttributes &&
            Number(event.eventId) < Number(scheduled?.eventId),
        )
        .at(-1);
      if (!resetPoint) throw new Error('No safe configuration reset point found');
      console.log('Expected permission failure. The workflow is closed as FAILED.');
      console.log('Repair dependency: npm run demo:repair -- ' + handle.workflowId);
      console.log(
        'Then open Temporal UI: ' + (process.env.TEMPORAL_UI_URL ?? 'http://localhost:8233'),
      );
      console.log(
        'Select this failed execution → Reset → workflow-task finish event ' +
          resetPoint?.eventId +
          ' (before configureMailbox).',
      );
      console.log(
        'Reset creates a new run. Only configureMailbox should execute again. Watch the new run in the graph viewer.',
      );
    }
    if (results.some((r) => r.status === 'rejected')) process.exitCode = 1;
  } finally {
    await connection.close();
  }
}
if (require.main === module)
  main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
