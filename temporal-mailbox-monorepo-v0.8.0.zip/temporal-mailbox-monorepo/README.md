# Temporal automation monorepo — 0.8.0

A production-oriented organization for mailbox orchestration, with executable scenarios demonstrating deployment isolation, retries, idempotency and operator recovery. Domain/application/adapters are **folders inside one mailbox library**, not individual packages. Workflow and activity workers are separate deployable applications.

Real provider integrations remain unconfigured because their contracts are unknown. The enterprise activity host refuses to poll until approved adapters are supplied. Local demonstrations compose the same handlers/services with test adapters; production never falls back to the simulator.

## Start locally, without Docker

Use Node.js 22.14+ (Node 24 recommended), npm and the native Temporal CLI on PATH, or set `TEMPORAL_CLI_PATH` to its executable. From the repository root:

```sh
npm ci
npm run dev
```

This builds the repository, manages a native Temporal development server and starts separate workflow-worker, activity-worker, simulator and viewer processes. Source/capacity changes rebuild and restart applications. Ctrl+C stops the owned processes; Temporal history persists under `.data`. `npm start` runs the local stack without source watching. `dev:external` / `start:external` connect to an existing service without owning it.

Open the [graph viewer](http://localhost:7531) and [Temporal UI](http://localhost:8233). Native Temporal is infrastructure; its executable is not one of our npm packages.

## What is a package, an application or a folder?

| Location                       | Kind                          | Responsibility                                                                                      |
| ------------------------------ | ----------------------------- | --------------------------------------------------------------------------------------------------- |
| `apps/mailbox-workflow-worker` | Deployable app                | Hosts three workflow definitions and polls the workflow queue                                       |
| `apps/mailbox-activity-worker` | Deployable app                | Composes and registers activity handlers, then polls a selected activity queue                      |
| `apps/temporal-access-gateway` | Deployable app                | Optional mTLS gRPC ingress enforcing client/workflow policy                                         |
| `apps/workflow-viewer`         | Deployable app                | Browser UI and read-only HTTP/static server                                                         |
| `packages/mailbox`             | Shared capability library     | Mailbox domain, application, inbound/outbound adapters, execution declarations and diagram metadata |
| `packages/temporal-platform`   | Shared infrastructure library | Queue builders, worker lifecycle and diagram interfaces                                             |
| `test/support`                 | One private tooling package   | Fixtures, simulator, test adapters, local workers and request/repair clients                        |

There are **seven workspaces** with the optional access gateway. Libraries do not run as servers. Each compiled workspace has one `src`/`dist` pair. Test suites live in `test/unit`, `test/integration`, `test/viewer`, `test/browser` and `test/tooling`; they are not packages.

## Inside the mailbox library

| Folder                           | Role                                                                                       |
| -------------------------------- | ------------------------------------------------------------------------------------------ |
| `src/domain`                     | Business models, value objects, invariants and domain errors                               |
| `src/application/contracts`      | Inbound capability interfaces, request/result DTOs, workflow/activity names                |
| `src/application/services`       | Business capabilities, independent of Temporal                                             |
| `src/application/ports/outbound` | Interfaces required from mailbox, directory and group dependencies                         |
| `src/adapters/inbound/temporal`  | Activity handlers: receive input, call services, map Temporal attempts/cancellation/errors |
| `src/adapters/outbound`          | Enterprise gateway implementations/composition; currently explicitly unconfigured          |
| `src/execution`                  | Queue/pool identities and sandbox-safe routing; worker-only capacity readers in `worker/`  |
| `src/presentation`               | Fixed graph descriptors, independent of workflow implementations                           |

Internal code uses ordinary relative imports. Other apps use explicit exports such as `@automation/mailbox/contracts` or `@automation/mailbox/adapters/inbound/temporal`. There is no root export importing everything. The workflow bundle uses contracts/execution definitions and never imports services or adapters.

An activity handler is the inbound adapter/entry point, not the worker process. `createMailboxActivityHandlers` connects services to Temporal. The activity host assembles outbound adapters → services → handlers and registers the handlers with the SDK Worker.

## Workflow definitions and capabilities

Definitions live under `apps/mailbox-workflow-worker/src/workflows`:

| Workflow                           | Behavior                                                                                          |
| ---------------------------------- | ------------------------------------------------------------------------------------------------- |
| `provisionPersonalMailboxWorkflow` | Prepare → provision → await availability → configure; dedicated personal activity pool            |
| `provisionRoomMailboxWorkflow`     | Same orchestration, with room-specific settings; standard activity pool                           |
| `provisionGroupMailboxWorkflow`    | After availability, configure mailbox and provision distribution group in parallel; wait for both |

Five cohesive handlers are registered: `prepareMailboxProvisioning`, `provisionMailbox`, `checkMailboxReadiness`, `configureMailbox`, `provisionMailboxDistributionGroup`. Configuration can call several ordinary services/ports; it is one activity/retry boundary. The real group dependency must be confirmed before connecting providers.

Readiness uses short check activities and workflow-owned durable timers. The viewer groups them into one stable availability node. Activities are invoked through Temporal task queues, not as direct implementation imports from workflow code.

## Presentation scenarios

Run these in another terminal while `npm run dev` is active. All executions appear in the viewer.

| Command                                       | Operational behavior demonstrated                                                              |
| --------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| `npm run demo -- personal` / `room` / `group` | Three explicit business processes sharing capabilities                                         |
| `npm run demo -- retry`                       | Transient provisioning error; automatic retry without redoing earlier completed activities     |
| `npm run demo -- idempotency`                 | Settings committed before a lost response; retry converges without duplicate resource creation |
| `npm run demo -- failure`                     | Non-retryable configuration failure; independent group branch succeeds                         |
| `npm run demo:isolation`                      | Standard pool backlog does not consume dedicated personal activity slots                       |
| `npm run demo -- batch 10`                    | Concurrent executions constrained by configured worker capacity                                |
| `npm run demo:recovery`                       | Workflow closes Failed, dependency is repaired, then native UI reset reruns configuration only |
| `npm run demo:viewer`                         | Slower group run, propagation waits and a transient retry for visual inspection                |
| `npm run demo -- file examples/room.json`     | Request submission from an explicit input contract                                             |

For recovery, run `npm run demo:repair -- <printed-workflow-id>`, then Reset in Temporal UI using the printed event ID. The original failed Run ID remains inspectable. Reused results have dashed green borders and a **Reused from previous run** badge linking to the source run. Configuration executes again. No intervention loop or signal was added to the production workflow. Recovery latency defaults to 1500 ms per simulated call so execution is visible.

The [presentation guide](docs/PRESENTATION.md) explains the demonstration order, evidence and limitations. The [recovery walkthrough](docs/RECOVERY_DEMO.md) gives exact UI steps.

## mTLS and two-client workflow segregation

With the normal stack running, use a second terminal:

```sh
npm run demo:security:setup
npm run start:gateway
```

Then in a third terminal:

```sh
npm run demo:security
```

OpenSSL is required for local certificate generation. Client A is allowed personal workflows; Client B is allowed room workflows. The matrix verifies allowed executions and rejected cross-client starts/reads, routing and identity spoofing, and missing/untrusted/unregistered certificates. It also verifies clients reject the wrong server identity.

**Enforcement is in an mTLS gRPC gateway**, because the native development CLI does not expose TLS/custom-authorizer listener options. The backend/workers remain trusted loopback processes; direct backend/admin access must be restricted in deployment. This is not a native Temporal server authorization-plugin demo. See [MTLS_DEMO.md](docs/MTLS_DEMO.md) for exact boundaries, individual client commands and native deployment options.

## Deployment boundaries

The same activity-worker artifact can run on different hosts with different profiles:

```sh
node apps/mailbox-activity-worker/dist/main.js personal
node apps/mailbox-activity-worker/dist/main.js standard
```

Those are separate fleets polling separate queues, not separate implementations. Capacity lives in `config/mailbox/capacity.json`; the production supervisor controls replicas. Queue names alone supply no capacity. Personal defaults to four slots per process, standard to two. The local supervisor applies the JSON replica counts.

Build and stage independent release directories:

```sh
npm run build:production
npm run release:stage -- workflow-worker /absolute/new/workflow-release
npm run release:stage -- activity-worker /absolute/new/activity-release
npm run release:stage -- viewer /absolute/new/viewer-release
```

Each directory contains `RELEASE.md` and `release.json` with its install/start commands. Worker stages contain the selected runtime code and library dependency closure, queue/capacity config and lockfile-consistent workspace manifests. Nonselected/test workspaces have manifests only; no test implementation is staged. Runtime dependencies are installed on the target host, including its platform-native Temporal components. Viewer stages are standalone and need no npm install. Staging refuses existing destinations and never overwrites a deployed release.

The enterprise activity host currently exits with `ExternalAdapterNotConfigured`; provider composition must be implemented before it can execute real operations. The native dev server is not a production Temporal deployment. See [DEPLOYMENT.md](docs/DEPLOYMENT.md).

## Maintainability and changes

| Change                                      | Location / deployment consequence                                                       |
| ------------------------------------------- | --------------------------------------------------------------------------------------- |
| Add/reorder orchestration steps             | Workflow definitions; deploy workflow host with replay/versioning review                |
| Change capability behavior                  | Application services/domain; deploy activity host if public contracts remain compatible |
| Add an external integration                 | Outbound adapter implementing application ports; deploy activity host                   |
| Change activity/workflow DTOs or wire names | Application contracts; coordinate compatible producer/consumer rollout                  |
| Add personal capacity                       | Supervisor replicas/concurrency; no workflow rewrite                                    |
| Declare another dedicated pool              | Execution constants, committed queue lock, capacity and consumers before routing work   |
| Adjust fixed graph topology                 | Mailbox presentation metadata; rebuild/deploy viewer alongside orchestration changes    |
| Simulate faults or repair permissions       | `test/support/src`; production inputs contain no simulation fields                      |
| Add another business context/team           | Add one owned capability library and required hosts; keep internal layers as folders    |

Public subpaths, folder-aware AST rules and a framework-free core typecheck enforce dependencies within libraries as well as between packages. Production cannot import test support; workflows cannot import adapter implementations. Ownership metadata appears in `npm run workspace:catalog`.

```sh
npm test
npm run check
npm run test:integration
npm run ci
npm run test:browser
npm run architecture:check
```

`check` runs formatting, lint/boundary rules, TypeScript builds, unit and React DOM tests. Integration tests manage their own native Temporal services and local ports. Browser tests require a compatible Playwright Chromium installation. `.vscode` includes local runtime/debug configurations. See [TESTING.md](docs/TESTING.md) and [VALIDATION.md](VALIDATION.md) for verified scope.

v0.7 changed source/package organization without changing v0.6 workflow types, activity wire names or queue identities. See [migration](docs/MIGRATION_v0.7.md).
